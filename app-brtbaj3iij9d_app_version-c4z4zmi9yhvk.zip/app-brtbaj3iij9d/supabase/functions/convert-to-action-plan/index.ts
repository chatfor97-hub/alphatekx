import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { runFirewall, SECURITY_HEADERS as CORS, buildSecurityHeaders } from '../_shared/firewall.ts';

const XAI_URL      = 'https://api.x.ai/v1/chat/completions';
const MEDO_URL     =
  'https://app-brtbaj3iij9d-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse';

interface Task {
  title:       string;
  description: string;
  owner:       string;
  done:        boolean;
}

// ── Collect OpenAI-compatible SSE → plain text ──────────────────────────────
async function collectOpenAI(body: ReadableStream): Promise<string> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buf = '', full = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split('\n'); buf = lines.pop() ?? '';
    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      const js = line.slice(6).trim();
      if (!js || js === '[DONE]') continue;
      try { full += JSON.parse(js).choices?.[0]?.delta?.content ?? ''; } catch { /* skip */ }
    }
  }
  return full.trim();
}

// ── Collect Gemini SSE → plain text ─────────────────────────────────────────
async function collectGemini(body: ReadableStream): Promise<string> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buf = '', full = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split('\n'); buf = lines.pop() ?? '';
    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      const d = line.slice(6).trim();
      if (!d || d === '[DONE]') continue;
      try { full += JSON.parse(d)?.candidates?.[0]?.content?.parts?.[0]?.text ?? ''; } catch { /* skip */ }
    }
  }
  return full.trim();
}

serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: 'convert-to-action-plan', maxReqsPer60s: 15, skipBodyScan: true });
  if (blocked) return blocked;

  try {
    const { messageText } = await req.json() as { messageText: string };
    if (!messageText?.trim()) {
      return new Response(JSON.stringify({ error: 'messageText is required' }), {
        status: 400, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' },
      });
    }

    const xaiKey  = Deno.env.get('XAI_API_KEY')          ?? '';
    const medoKey = Deno.env.get('INTEGRATIONS_API_KEY')  ?? '';

    const prompt = `You are an expert project manager. Parse the following message and create a structured action plan with up to 5 clear, actionable steps.

Message: "${messageText}"

Respond ONLY with a valid JSON array (no markdown, no explanation) in this exact format:
[
  {
    "title": "Step title (short, max 8 words)",
    "description": "Brief description of what needs to be done (1-2 sentences)",
    "owner": "",
    "done": false
  }
]

Rules:
- Maximum 5 steps
- Each step must be concrete and actionable
- Keep titles concise
- Owner field should be empty string (will be filled by team)
- Return ONLY the JSON array, nothing else`;

    let fullText = '';

    // ── Provider #1: xAI Grok-3 ──────────────────────────────────────────────
    if (xaiKey) {
      const res = await fetch(XAI_URL, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${xaiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'grok-3',
          messages: [{ role: 'user', content: prompt }],
          stream: true, max_tokens: 2048,
        }),
        signal: AbortSignal.timeout(60_000),
      });
      if (res.ok && res.body) {
        fullText = await collectOpenAI(res.body);
        console.log(`convert-to-action-plan: xAI Grok-3, ${fullText.length} chars`);
      } else {
        console.error(`convert-to-action-plan: xAI failed ${res.status}`);
      }
    }

    // ── Provider #2: Medo / Gemini gateway ───────────────────────────────────
    if (!fullText && medoKey) {
      const res = await fetch(MEDO_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Gateway-Authorization': `Bearer ${medoKey}` },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }] }),
        signal: AbortSignal.timeout(60_000),
      });
      if (res.ok && res.body) {
        fullText = await collectGemini(res.body);
        console.log(`convert-to-action-plan: Medo/Gemini, ${fullText.length} chars`);
      } else {
        const errText = await res.text();
        return new Response(JSON.stringify({ error: `AI error: ${errText}` }), {
          status: 502, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' },
        });
      }
    }

    if (!fullText) {
      return new Response(JSON.stringify({ error: 'No AI provider available — please try again.' }), {
        status: 503, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' },
      });
    }

    // Extract JSON from response (strip any accidental markdown)
    const jsonMatch = fullText.match(/\[[\s\S]*\]/);
    if (!jsonMatch) {
      return new Response(JSON.stringify({ error: 'AI did not return valid JSON', raw: fullText }), {
        status: 502, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' },
      });
    }

    const tasks: Task[] = JSON.parse(jsonMatch[0]);

    return new Response(JSON.stringify({ tasks }), {
      status: 200, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' },
    });

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' },
    });
  }
});
