/**
 * AlphaTekx WAF (Web Application Firewall) Middleware
 * ─────────────────────────────────────────────────────
 * Drop this into every Edge Function before processing any request.
 *
 * Protections:
 *  1. IP-based rate limiting  (sliding 60s window, configurable max)
 *  2. SQL injection detection (OWASP Top-10 patterns)
 *  3. XSS / script injection detection
 *  4. Path traversal detection
 *  5. HTTP method enforcement
 *  6. Request size limit (default 64 KB)
 *  7. Malicious User-Agent blocking
 *  8. CORS origin enforcement
 *  9. Security response headers on every response
 * 10. Structured audit logging to firewall_logs table
 */

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ── Constants ──────────────────────────────────────────────────────────────────

/**
 * All domains that may call AlphaTekx Edge Functions.
 * Add new domains here — no redeployment of individual functions needed,
 * only this shared file needs updating.
 */
const ALLOWED_ORIGINS = new Set([
  "https://alphatekx.ai",          // primary production domain
  "https://www.alphatekx.ai",      // www variant
  "https://alphatekx.name.ng",     // Nigeria custom domain
  "https://www.alphatekx.name.ng", // www variant
  "https://alphatekx.mdo.pw",      // Medo preview / legacy
]);

/**
 * Resolve the correct Access-Control-Allow-Origin value for a given request.
 * Returns the matched origin if it is in the allowlist, otherwise falls back
 * to the primary production domain (never a wildcard).
 *
 * Also allows any *.medo.dev subdomain so the Medo preview/sandbox
 * environments (e.g. app-brtbaj3iij9d-vitesandbox.sandbox.medo.dev)
 * can call edge functions during development without CORS errors.
 */
function resolveAllowedOrigin(req: Request): string {
  const origin = req.headers.get("origin") ?? "";
  if (ALLOWED_ORIGINS.has(origin)) return origin;
  // Medo platform preview / sandbox / deploy environments
  if (origin.endsWith(".medo.dev") || origin.endsWith(".appmedo.com")) return origin;
  return "https://alphatekx.ai";
}

/** Security headers added to EVERY response.
 *  CORS origin is injected dynamically — use buildSecurityHeaders(req) instead
 *  of SECURITY_HEADERS directly whenever you have access to the Request object.
 */
export const SECURITY_HEADERS: Record<string, string> = {
  // Placeholder — overwritten by buildSecurityHeaders() at runtime.
  // Kept for backward-compat with call sites that don't have a Request ref.
  "Access-Control-Allow-Origin": "https://alphatekx.ai",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-alphatekx-token",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Vary": "Origin",
  // Prevent MIME-type sniffing
  "X-Content-Type-Options": "nosniff",
  // Block clickjacking
  "X-Frame-Options": "DENY",
  // Disable legacy XSS auditor (modern browsers ignore it, but belt+suspenders)
  "X-XSS-Protection": "1; mode=block",
  // Force HTTPS for 1 year, include subdomains
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
  // Referrer policy — don't leak paths to third parties
  "Referrer-Policy": "strict-origin-when-cross-origin",
  // Permissions policy — disable dangerous browser APIs
  "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=()",
  // Content type for JSON responses
  "Content-Type": "application/json",
};

/**
 * Build per-request security headers with the correct dynamic CORS origin.
 * Use this everywhere you have a Request object.
 */
export function buildSecurityHeaders(req: Request): Record<string, string> {
  return {
    ...SECURITY_HEADERS,
    "Access-Control-Allow-Origin": resolveAllowedOrigin(req),
  };
}

// ── Threat patterns ────────────────────────────────────────────────────────────

/** SQL injection patterns (OWASP CRS-inspired) */
const SQL_PATTERNS = [
  /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|TRUNCATE|REPLACE)\b)/i,
  /(--|;--|\/\*|\*\/|xp_|sp_|0x[0-9a-f]+)/i,
  /(\bOR\b\s+['"]?\d+['"]?\s*=\s*['"]?\d+['"]?)/i,
  /(\bAND\b\s+['"]?\d+['"]?\s*=\s*['"]?\d+['"]?)/i,
  /(SLEEP\s*\(|BENCHMARK\s*\(|WAITFOR\s+DELAY)/i,
  /(\bLOAD_FILE\b|\bINTO\s+OUTFILE\b|\bINTO\s+DUMPFILE\b)/i,
];

/** XSS patterns */
const XSS_PATTERNS = [
  /<script[\s>]/i,
  /<\/script>/i,
  /javascript\s*:/i,
  /on\w+\s*=/i,          // onclick=, onerror=, onload= etc.
  /data\s*:\s*text\/html/i,
  /vbscript\s*:/i,
  /<iframe[\s>]/i,
  /<object[\s>]/i,
  /<embed[\s>]/i,
  /expression\s*\(/i,
  /document\.cookie/i,
  /document\.location/i,
  /window\.location/i,
  /eval\s*\(/i,
];

/** Path traversal patterns */
const PATH_TRAVERSAL_PATTERNS = [
  /\.\.\//,
  /\.\.%2F/i,
  /%2e%2e%2f/i,
  /etc\/passwd/i,
  /etc\/shadow/i,
  /proc\/self/i,
  /\/\.\.\//,
];

/** Known malicious / scanner User-Agents */
const BLOCKED_USER_AGENTS = [
  /sqlmap/i,
  /nikto/i,
  /nmap/i,
  /masscan/i,
  /zgrab/i,
  /dirbuster/i,
  /burpsuite/i,
  /havij/i,
  /acunetix/i,
  /nessus/i,
  /openvas/i,
  /w3af/i,
  /python-requests\/[01]\./i,  // old automated scrapers
  /curl\/[0-6]\./i,             // very old curl (scanner bots)
  /go-http-client\/1\.0/i,
];

// ── IP hashing ─────────────────────────────────────────────────────────────────
/** One-way hash of IP — we never store raw IPs */
async function hashIP(ip: string): Promise<string> {
  const data   = new TextEncoder().encode(ip + "alphatekx-salt-v1");
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("")
    .slice(0, 32); // 32-char hex prefix is plenty
}

// ── Supabase admin client ──────────────────────────────────────────────────────
function getAdminClient() {
  const url = Deno.env.get("SUPABASE_URL")!;
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(url, key);
}

// ── Rate limiting ──────────────────────────────────────────────────────────────
/**
 * Sliding-window rate limiter.
 * @param ipHash   — hashed IP
 * @param fnKey    — unique function identifier (e.g. "alphatekx-chat")
 * @param maxReqs  — max requests allowed per window
 * @param windowSec — window size in seconds (default 60)
 */
async function checkRateLimit(
  ipHash: string,
  fnKey: string,
  maxReqs: number,
  windowSec = 60,
): Promise<{ allowed: boolean; count: number }> {
  const sb          = getAdminClient();
  const windowStart = new Date(Date.now() - windowSec * 1000).toISOString();

  // Count requests in current window
  const { count } = await sb
    .from("rate_limit_buckets")
    .select("*", { count: "exact", head: true })
    .eq("ip_hash", ipHash)
    .eq("function_key", fnKey)
    .gte("window_start", windowStart);

  const currentCount = count ?? 0;
  if (currentCount >= maxReqs) {
    return { allowed: false, count: currentCount };
  }

  // Record this request
  await sb.from("rate_limit_buckets").insert({
    ip_hash: ipHash, function_key: fnKey, req_count: 1,
  });

  // Async purge — doesn't block the response
  sb.rpc("purge_old_rate_limit_buckets").then(() => {});

  return { allowed: true, count: currentCount + 1 };
}

// ── Audit logging ──────────────────────────────────────────────────────────────
async function logBlock(
  ipHash:      string,
  fnKey:       string,
  blockReason: string,
  requestPath: string,
  userAgent:   string,
  payloadHint: string,
): Promise<void> {
  try {
    const sb = getAdminClient();
    await sb.from("firewall_logs").insert({
      ip_hash:      ipHash,
      function_key: fnKey,
      block_reason: blockReason,
      request_path: requestPath.slice(0, 500),
      user_agent:   userAgent.slice(0, 300),
      payload_hint: payloadHint.slice(0, 200),
    });
  } catch {
    // Logging failure must never break the request pipeline
  }
}

// ── Payload scanner ────────────────────────────────────────────────────────────
function scanForThreats(text: string): string | null {
  if (!text) return null;
  for (const p of SQL_PATTERNS)      if (p.test(text)) return "sql_injection";
  for (const p of XSS_PATTERNS)      if (p.test(text)) return "xss";
  for (const p of PATH_TRAVERSAL_PATTERNS) if (p.test(text)) return "path_traversal";
  return null;
}

// ── JSON body scanner ──────────────────────────────────────────────────────────
function scanObject(obj: unknown, depth = 0): string | null {
  if (depth > 8) return null; // cap recursion
  if (typeof obj === "string") return scanForThreats(obj);
  if (Array.isArray(obj)) {
    for (const v of obj) {
      const t = scanObject(v, depth + 1);
      if (t) return t;
    }
    return null;
  }
  if (obj && typeof obj === "object") {
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      if (scanForThreats(k))                   return "xss"; // malicious key
      const t = scanObject(v, depth + 1);
      if (t) return t;
    }
  }
  return null;
}

// ── Blocked response ───────────────────────────────────────────────────────────
function blockedResponse(status: number, message: string): Response {
  return new Response(
    JSON.stringify({ error: message, code: "FIREWALL_BLOCKED" }),
    { status, headers: SECURITY_HEADERS },
  );
}

// ── Main WAF function ──────────────────────────────────────────────────────────
export interface FirewallOptions {
  /** Identifying key for this function (used in logs & rate limiting) */
  functionKey: string;
  /** Max requests per IP per 60s window. Default: 30 */
  maxReqsPer60s?: number;
  /** Max request body size in bytes. Default: 65536 (64 KB) */
  maxBodyBytes?: number;
  /** Allowed HTTP methods. Default: ["POST", "OPTIONS"] */
  allowedMethods?: string[];
  /**
   * Skip body scanning — use for webhook endpoints that verify their own
   * payload signatures (e.g. Paystack HMAC-SHA512, Stripe webhooks).
   * All other checks (rate limit, UA, URL) still run.
   */
  skipBodyScan?: boolean;
}

/**
 * Run the full WAF pipeline.
 * Returns null if the request is clean, or a 4xx/5xx Response to return immediately.
 *
 * Usage in any Edge Function:
 * ```ts
 * const blocked = await runFirewall(req, { functionKey: "my-function" });
 * if (blocked) return blocked;
 * ```
 */
export async function runFirewall(
  req: Request,
  opts: FirewallOptions,
): Promise<Response | null> {
  const {
    functionKey,
    maxReqsPer60s  = 30,
    maxBodyBytes   = 65_536,
    allowedMethods = ["POST", "OPTIONS"],
    skipBodyScan   = false,
  } = opts;

  // 1. CORS preflight — respond immediately with dynamic origin header
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: buildSecurityHeaders(req) });
  }

  // 2. Method enforcement
  if (!allowedMethods.includes(req.method)) {
    return blockedResponse(405, "Method not allowed.");
  }

  const url       = new URL(req.url);
  const userAgent = req.headers.get("user-agent") ?? "";
  const rawIP     = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim()
                 ?? req.headers.get("x-real-ip")
                 ?? "unknown";
  const ipHash    = await hashIP(rawIP);

  // 3. Malicious User-Agent blocking
  for (const ua of BLOCKED_USER_AGENTS) {
    if (ua.test(userAgent)) {
      await logBlock(ipHash, functionKey, "blocked_user_agent", url.pathname, userAgent, userAgent.slice(0, 80));
      return blockedResponse(403, "Forbidden.");
    }
  }

  // 4. Path traversal in URL
  const fullUrl = url.pathname + url.search;
  const urlThreat = scanForThreats(fullUrl);
  if (urlThreat) {
    await logBlock(ipHash, functionKey, urlThreat, url.pathname, userAgent, fullUrl.slice(0, 100));
    return blockedResponse(400, "Bad request.");
  }

  // 5. Rate limiting
  const { allowed, count } = await checkRateLimit(ipHash, functionKey, maxReqsPer60s);
  if (!allowed) {
    await logBlock(ipHash, functionKey, "rate_limited", url.pathname, userAgent, `count=${count}`);
    return new Response(
      JSON.stringify({ error: "Too many requests. Please slow down.", code: "RATE_LIMITED" }),
      {
        status: 429,
        headers: {
          ...SECURITY_HEADERS,
          "Retry-After": "60",
          "X-RateLimit-Limit": String(maxReqsPer60s),
          "X-RateLimit-Remaining": "0",
        },
      },
    );
  }

  // 6. Content-Length / body size guard + body scanning
  //    Skipped for webhook endpoints that verify their own payload signatures.
  if (!skipBodyScan) {
    const contentLength = parseInt(req.headers.get("content-length") ?? "0", 10);
    if (contentLength > maxBodyBytes) {
      await logBlock(ipHash, functionKey, "body_too_large", url.pathname, userAgent, `bytes=${contentLength}`);
      return blockedResponse(413, "Request payload too large.");
    }

    // 7. Body scanning for injection payloads
    //    We clone the request so the caller can still read the body.
    try {
      const cloned   = req.clone();
      const bodyText = await cloned.text();

      if (bodyText.length > maxBodyBytes) {
        await logBlock(ipHash, functionKey, "body_too_large", url.pathname, userAgent, `actual_bytes=${bodyText.length}`);
        return blockedResponse(413, "Request payload too large.");
      }

      // Try to parse as JSON for deep scanning
      try {
        const parsed = JSON.parse(bodyText);
        const threat = scanObject(parsed);
        if (threat) {
          await logBlock(ipHash, functionKey, threat, url.pathname, userAgent, bodyText.slice(0, 120));
          return blockedResponse(400, "Bad request.");
        }
      } catch {
        // Not JSON — scan raw text
        const threat = scanForThreats(bodyText);
        if (threat) {
          await logBlock(ipHash, functionKey, threat, url.pathname, userAgent, bodyText.slice(0, 120));
          return blockedResponse(400, "Bad request.");
        }
      }
    } catch {
      // Body read failed — allow through, let handler deal with it
    }
  }

  // All checks passed ✓
  return null;
}

/** Wraps any Response with the full security headers. */
export function secureResponse(body: string, status = 200): Response {
  return new Response(body, { status, headers: SECURITY_HEADERS });
}
