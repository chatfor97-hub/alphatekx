/**
 * CSP Violation Report Endpoint
 * Browsers POST here automatically when a Content-Security-Policy rule is violated.
 * We log every violation to csp_violation_reports for admin review.
 */
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SECURITY_HEADERS } from "../_shared/firewall.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: SECURITY_HEADERS });
  }

  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405, headers: SECURITY_HEADERS });
  }

  try {
    const body = await req.json() as { "csp-report"?: Record<string, unknown> };
    const report = body["csp-report"] ?? body;

    const sb = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    await sb.from("csp_violation_reports").insert({
      document_uri:        String(report["document-uri"]        ?? ""),
      violated_directive:  String(report["violated-directive"]  ?? ""),
      blocked_uri:         String(report["blocked-uri"]         ?? ""),
      original_policy:     String(report["original-policy"]     ?? "").slice(0, 1000),
      source_file:         String(report["source-file"]         ?? ""),
      line_number:         Number(report["line-number"]         ?? 0),
      user_agent:          req.headers.get("user-agent")?.slice(0, 300) ?? "",
    });

    return new Response(null, { status: 204, headers: SECURITY_HEADERS });
  } catch (err) {
    console.error("csp-report-endpoint error:", err);
    return new Response(null, { status: 204, headers: SECURITY_HEADERS });
  }
});
