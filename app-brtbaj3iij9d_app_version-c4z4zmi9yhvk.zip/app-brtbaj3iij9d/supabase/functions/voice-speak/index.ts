import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { runFirewall, SECURITY_HEADERS as corsHeaders } from "../_shared/firewall.ts";

serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: "voice-speak", maxReqsPer60s: 20 });
  if (blocked) return blocked;

  try {
    const openaiKey = Deno.env.get("OPENAI_API_KEY") ?? "";
    if (!openaiKey) throw new Error("OpenAI key not configured.");

    const { text, voice = "nova" } = await req.json();
    if (!text?.trim()) throw new Error("No text provided.");

    const res = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "tts-1",
        input: text.slice(0, 1000),
        voice,
        response_format: "mp3",
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`TTS error ${res.status}: ${err}`);
    }

    // Stream the mp3 audio bytes back
    return new Response(res.body, {
      headers: {
        ...corsHeaders,
        "Content-Type": "audio/mpeg",
        "Cache-Control": "no-cache",
      },
    });
  } catch (e) {
    console.error("voice-speak error:", e);
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
