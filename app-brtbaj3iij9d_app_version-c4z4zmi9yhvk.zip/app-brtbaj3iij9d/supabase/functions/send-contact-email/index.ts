import 'jsr:@supabase/functions-js/edge-runtime.d.ts';
import { runFirewall, SECURITY_HEADERS as CORS } from '../_shared/firewall.ts';

Deno.serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: 'send-contact-email', maxReqsPer60s: 5 });
  if (blocked) return blocked;

  try {
    const { name, email, message } = await req.json();

    if (!name?.trim() || !email?.trim() || !message?.trim()) {
      return new Response(
        JSON.stringify({ error: 'All fields (name, email, message) are required.' }),
        { status: 400, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
      );
    }

    const apiKey = Deno.env.get('RESEND_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'Email service not configured. Please set RESEND_API_KEY.' }),
        { status: 500, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
      );
    }

    const emailBody = {
      from: 'AlphaTekx <onboarding@resend.dev>',
      to: ['alphatekxcompany@gmail.com'],
      reply_to: email.trim(),
      subject: `New Message from ${name.trim()} — AlphaTekx Build With Us`,
      html: `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; background: #f9fafb; border-radius: 12px;">
          <h2 style="color: #1e40af; margin: 0 0 4px;">New Contact Form Submission</h2>
          <p style="color: #6b7280; font-size: 13px; margin: 0 0 24px;">From the AlphaTekx "Build With Us" page</p>

          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151; width: 120px; font-size: 14px;">Name</td>
              <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #111827; font-size: 14px;">${name.trim()}</td>
            </tr>
            <tr>
              <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151; font-size: 14px;">Email</td>
              <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-size: 14px;"><a href="mailto:${email.trim()}" style="color: #1e40af;">${email.trim()}</a></td>
            </tr>
            <tr>
              <td style="padding: 12px 0 4px; font-weight: 600; color: #374151; vertical-align: top; font-size: 14px;">Message</td>
              <td style="padding: 12px 0 4px; font-size: 14px;"></td>
            </tr>
          </table>

          <div style="margin-top: 8px; padding: 16px; background: #fff; border: 1px solid #e5e7eb; border-radius: 8px; white-space: pre-wrap; color: #111827; font-size: 14px; line-height: 1.6;">
            ${message.trim().replace(/</g, '&lt;').replace(/>/g, '&gt;')}
          </div>

          <p style="color: #9ca3af; font-size: 12px; margin-top: 24px; border-top: 1px solid #e5e7eb; padding-top: 16px;">
            AlphaTekx AI Operating System · Sent via Build With Us contact form
          </p>
        </div>
      `,
    };

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailBody),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error('Resend error:', errText);
      return new Response(
        JSON.stringify({ error: 'Failed to send email. Please try again.' }),
        { status: 502, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
      );
    }

    return new Response(
      JSON.stringify({ success: true }),
      { status: 200, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
    );
  } catch (err) {
    console.error('send-contact-email error:', err);
    return new Response(
      JSON.stringify({ error: 'Internal server error.' }),
      { status: 500, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
    );
  }
});
