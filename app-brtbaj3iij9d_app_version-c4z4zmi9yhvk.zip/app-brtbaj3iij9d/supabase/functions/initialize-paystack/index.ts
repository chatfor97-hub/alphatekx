import { createClient } from "jsr:@supabase/supabase-js@2";
import { runFirewall, SECURITY_HEADERS as corsHeaders } from "../_shared/firewall.ts";

// ── Credit packs — Exchange rate: $1 USD = ₦1,373.42 (flat market rate) ──────
// Kobo is the NGN sub-unit: ₦1 = 100 kobo. Amount sent to Paystack MUST be
// a strict integer in kobo — hardcoded here to eliminate float rounding risk.
//
//  Tier 1  $1  →  ₦1,373.42  →      137,342 kobo  →    50 credits
//  Tier 2  $5  →  ₦6,867.10  →      686,710 kobo  →   300 credits
//  Tier 3  $10 →  ₦13,734.20 →    1,373,420 kobo  →   700 credits
//  Tier 4  $50 →  ₦68,671.00 →    6,867,100 kobo  → 3,500 credits
const CREDIT_PACKS: Record<string, { credits: number; amountNgn: number; amountKobo: number; usd: number }> = {
  starter: { credits:   50, usd:  1, amountNgn:  1_373.42, amountKobo:   137_342 },
  popular: { credits:  300, usd:  5, amountNgn:  6_867.10, amountKobo:   686_710 },
  pro:     { credits:  700, usd: 10, amountNgn: 13_734.20, amountKobo: 1_373_420 },
  elite:   { credits: 3500, usd: 50, amountNgn: 68_671.00, amountKobo: 6_867_100 },
};

function ok(data: unknown): Response {
  return new Response(JSON.stringify({ code: "SUCCESS", data }), {
    status: 200,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

function fail(msg: string, status = 400): Response {
  return new Response(JSON.stringify({ code: "FAIL", message: msg }), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

Deno.serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: "initialize-paystack", maxReqsPer60s: 10 });
  if (blocked) return blocked;

  try {
    const { email, packId, firebaseUid, callbackUrl } = await req.json();

    // ── 1. Validate all required fields ────────────────────────────────────
    if (!email || typeof email !== "string" || !email.includes("@")) {
      return fail("A valid email address is required.");
    }
    if (!packId || !firebaseUid || !callbackUrl) {
      return fail("Missing required fields: packId, firebaseUid, callbackUrl");
    }

    const pack = CREDIT_PACKS[packId];
    if (!pack) return fail(`Unknown pack: ${packId}`);

    // ── 2. Verify secret key — must be sk_live_... or sk_test_..., NOT pk_ ─
    const paystackSecretKey = Deno.env.get("PAYSTACK_SECRET_KEY") ?? "";
    if (!paystackSecretKey) {
      return fail("PAYSTACK_SECRET_KEY is not configured on the server.", 500);
    }
    if (paystackSecretKey.startsWith("pk_")) {
      console.error("PAYSTACK_SECRET_KEY is a PUBLIC key (pk_...). Must be the Secret Key (sk_...).");
      return fail("Server payment configuration error: wrong key type.", 500);
    }
    if (!paystackSecretKey.startsWith("sk_")) {
      console.error("PAYSTACK_SECRET_KEY does not look like a valid Paystack secret key.");
      return fail("Server payment configuration error: invalid key format.", 500);
    }

    // ── 3. Convert to kobo — use hardcoded integer, never derive via * 100 ──
    // Kobo values are hardcoded in CREDIT_PACKS to eliminate float rounding.
    // Math.round() kept as safety net but should always be a clean integer.
    const amountInKobo: number = pack.amountKobo; // e.g. 137342 for Tier 1

    // Safety floor — Paystack minimum is ₦50 (5,000 kobo)
    if (amountInKobo < 5_000) {
      return fail(`Amount too small: ${amountInKobo} kobo. Minimum is 5,000 kobo (₦50).`);
    }

    // ── 4. Build unique transaction reference ───────────────────────────────
    const reference = `atx_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;

    // ── 5. Append routing params to callback URL ────────────────────────────
    const cbUrl = new URL(callbackUrl);
    cbUrl.searchParams.set("packId", packId);
    cbUrl.searchParams.set("uid", firebaseUid);

    // ── 6. Build the Paystack payload ────────────────────────────────────────
    // currency is intentionally omitted → Paystack defaults to the account
    // currency (NGN for Nigerian merchant accounts).
    // Sending currency: "USD" on an NGN-only account returns HTTP 400.
    const paystackPayload = {
      email:        email.trim().toLowerCase(),
      amount:       amountInKobo,          // strict integer, in kobo
      reference,
      callback_url: cbUrl.toString(),
      metadata: {
        pack_id:      packId,
        firebase_uid: firebaseUid,
        credits:      pack.credits,
        ngn_amount:   pack.amountNgn,
        usd_amount:   pack.usd,
        kobo_amount:  pack.amountKobo,
        custom_fields: [
          { display_name: "Pack",    variable_name: "pack_id",  value: packId },
          { display_name: "Credits", variable_name: "credits",  value: String(pack.credits) },
          { display_name: "USD",     variable_name: "usd",      value: `$${pack.usd}` },
        ],
      },
    };

    console.log("Paystack init payload:", JSON.stringify({
      ...paystackPayload,
      // redact UID from logs but keep structure
      metadata: { ...paystackPayload.metadata, firebase_uid: "[redacted]" },
    }));

    // ── 7. Call Paystack initialization endpoint ────────────────────────────
    const initRes = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        // Authorization MUST use the Secret Key (sk_live_... or sk_test_...)
        Authorization:  `Bearer ${paystackSecretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(paystackPayload),
    });

    // ── 8. Parse response — always surface the real Paystack error ──────────
    const initData = await initRes.json().catch(() => null);

    if (!initRes.ok) {
      // Surface the actual Paystack error message to the caller
      const paystackMsg = initData?.message ?? `HTTP ${initRes.status}`;
      console.error("Paystack init failed:", initRes.status, JSON.stringify(initData));
      return fail(`Paystack error: ${paystackMsg}`, 502);
    }

    if (!initData?.status || !initData?.data?.authorization_url) {
      console.error("Paystack init unexpected response:", JSON.stringify(initData));
      return fail(`Paystack returned no payment URL. Response: ${JSON.stringify(initData)}`);
    }

    // ── 9. Record pending topup (non-fatal) ─────────────────────────────────
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    await supabase.from("credit_topups").insert({
      firebase_uid:  firebaseUid,
      pack_id:       packId,
      credits_added: 0,               // 0 until verify-paystack confirms success
      amount_usd:    pack.amountNgn,  // stored as NGN value
      paystack_ref:  reference,
      status:        "pending",
    });
    // Non-fatal — verify step will upsert on success

    console.log(`Paystack init success. ref=${reference}, amount=${amountInKobo} kobo`);

    return ok({
      authorization_url: initData.data.authorization_url,
      access_code:       initData.data.access_code,
      reference,
    });

  } catch (err) {
    console.error("initialize-paystack unexpected error:", err);
    return fail(err instanceof Error ? err.message : "Unexpected server error", 500);
  }
});
