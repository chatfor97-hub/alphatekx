import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { runFirewall, buildSecurityHeaders } from "../_shared/firewall.ts";

// ── Multi-provider streaming chat ──────────────────────────────────────────
// Priority: xAI Grok-3 → Groq → OpenAI → Gemini → Anthropic → Medo
// xAI Grok-3: 131k token context — handles massive text inputs natively.
// Vision messages (with imageUrl) route directly to xAI Grok-2-Vision or OpenAI GPT-4o.

// ── xAI Grok (primary — 131k context, OpenAI-compatible) ──────────────────
const XAI_URL = "https://api.x.ai/v1/chat/completions";

async function callXAI(
  messages: object[],
  xaiKey: string,
  model = "grok-3-fast",
): Promise<Response | null> {
  try {
    const res = await fetch(XAI_URL, {
      method: "POST",
      headers: { "Authorization": `Bearer ${xaiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        messages,
        stream: true,
        max_tokens: 16384,
      }),
      signal: AbortSignal.timeout(120_000),
    });
    if (!res.ok) { console.error(`xAI failed: ${res.status} ${await res.text()}`); return null; }
    return res;
  } catch (e) { console.error("xAI error:", e); return null; }
}

async function callGroq(messages: object[], groqKey: string): Promise<Response | null> {
  try {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${groqKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: "llama-3.3-70b-versatile", messages, stream: true }),
    });
    if (!res.ok) { console.error(`Groq failed: ${res.status}`); return null; }
    return res;
  } catch (e) { console.error("Groq error:", e); return null; }
}

async function callOpenAI(messages: object[], openaiKey: string, vision = false): Promise<Response | null> {
  try {
    const model = vision ? "gpt-4o" : "gpt-4o-mini";
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${openaiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model, messages, stream: true }),
    });
    if (!res.ok) { console.error(`OpenAI failed: ${res.status}`); return null; }
    return res;
  } catch (e) { console.error("OpenAI error:", e); return null; }
}

async function callGeminiVision(
  prompt: string,
  imageUrl: string,
  systemPrompt: string,
  geminiKey: string
): Promise<ReadableStream | null> {
  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:streamGenerateContent?alt=sse&key=${geminiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: systemPrompt }] },
          contents: [{
            role: "user",
            parts: [
              { text: prompt || "Analyze this image." },
              { image_url: { url: imageUrl } },
            ],
          }],
        }),
      }
    );
    if (!res.ok) { console.error(`Gemini vision failed: ${res.status}`); return null; }
    return wrapGeminiStream(res);
  } catch (e) { console.error("Gemini vision error:", e); return null; }
}

async function callGemini(prompt: string, systemPrompt: string, geminiKey: string): Promise<ReadableStream | null> {
  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:streamGenerateContent?alt=sse&key=${geminiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: systemPrompt }] },
          contents: [{ role: "user", parts: [{ text: prompt }] }],
        }),
      }
    );
    if (!res.ok) { console.error(`Gemini failed: ${res.status}`); return null; }
    return wrapGeminiStream(res);
  } catch (e) { console.error("Gemini error:", e); return null; }
}

function wrapGeminiStream(res: Response): ReadableStream {
  const reader = res.body!.getReader();
  const encoder = new TextEncoder();
  return new ReadableStream({
    async start(controller) {
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (!jsonStr || jsonStr === "[DONE]") continue;
          try {
            const parsed = JSON.parse(jsonStr);
            const text = parsed.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
            if (text) {
              const openAiChunk = JSON.stringify({ choices: [{ delta: { content: text } }] });
              controller.enqueue(encoder.encode(`data: ${openAiChunk}\n\n`));
            }
          } catch { /* skip */ }
        }
      }
      controller.enqueue(encoder.encode("data: [DONE]\n\n"));
      controller.close();
    },
  });
}

async function callAnthropic(prompt: string, systemPrompt: string, anthropicKey: string): Promise<ReadableStream | null> {
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": anthropicKey,
        "anthropic-version": "2023-06-01",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-3-haiku-20240307",
        max_tokens: 1024,
        system: systemPrompt,
        messages: [{ role: "user", content: prompt }],
        stream: true,
      }),
    });
    if (!res.ok) { console.error(`Anthropic failed: ${res.status}`); return null; }
    const reader = res.body!.getReader();
    const encoder = new TextEncoder();
    return new ReadableStream({
      async start(controller) {
        const decoder = new TextDecoder();
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";
          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            const jsonStr = line.slice(6).trim();
            if (!jsonStr) continue;
            try {
              const parsed = JSON.parse(jsonStr);
              const text = parsed.delta?.text ?? "";
              if (text) {
                const openAiChunk = JSON.stringify({ choices: [{ delta: { content: text } }] });
                controller.enqueue(encoder.encode(`data: ${openAiChunk}\n\n`));
              }
            } catch { /* skip */ }
          }
        }
        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
      },
    });
  } catch (e) { console.error("Anthropic error:", e); return null; }
}


// ── Medo Gateway (INTEGRATIONS_API_KEY) — primary always-available provider ──
const MEDO_GATEWAY_URL =
  "https://app-brtbaj3iij9d-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

async function callMedoGateway(
  prompt: string,
  systemPrompt: string,
  history: { role: string; content: string }[],
  apiKey: string,
): Promise<ReadableStream | null> {
  try {
    const contents = [
      ...history.map(h => ({
        role: h.role === "assistant" ? "model" : "user",
        parts: [{ text: h.content }],
      })),
      { role: "user", parts: [{ text: prompt }] },
    ];

    const res = await fetch(MEDO_GATEWAY_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: systemPrompt }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 4096 },
      }),
      signal: AbortSignal.timeout(90_000),
    });

    if (!res.ok) {
      console.error(`Medo gateway failed: ${res.status} ${await res.text()}`);
      return null;
    }

    // Wrap Gemini SSE → OpenAI-compatible SSE so the frontend parser works unchanged
    return wrapGeminiStream(res);
  } catch (e) {
    console.error("Medo gateway error:", e);
    return null;
  }
}

serve(async (req) => {
  // Increase maxBodyBytes to 512KB to handle massive text inputs (documents, system prompts, etc.)
  const blocked = await runFirewall(req, { functionKey: "chat", maxReqsPer60s: 25, maxBodyBytes: 524288, skipBodyScan: true });
  if (blocked) return blocked;

  try {
    const { prompt, history = [], imageUrl } = await req.json();
    const hasImage = !!imageUrl;
    console.log(`Received prompt: ${prompt?.substring(0, 60)}... image=${hasImage}`);

    const xaiKey       = Deno.env.get("XAI_API_KEY") ?? "";
    const groqKey      = Deno.env.get("GROQ_API_KEY") ?? "";
    const openaiKey    = Deno.env.get("OPENAI_API_KEY") ?? "";
    const geminiKey    = Deno.env.get("GEMINI_API_KEY") ?? "";
    const anthropicKey = Deno.env.get("ANTHROPIC_API_KEY") ?? "";
    const tavilyKeys   = (Deno.env.get("TAVILY_API_KEYS") ?? Deno.env.get("TAVILY_API_KEY") ?? "")
      .split(",").map((k: string) => k.trim()).filter(Boolean);

    // ── Tool list for system prompt reference only ──────────────────────────
    const toolList = [
      "Website Builder", "Exam Prep", "Art Generator", "Media Linker",
      "Video Generator", "Contract Guard", "Voice Gen", "Thumbnail Studio",
    ].map(n => `- ${n}`).join("\n");

    // ── SYSTEM PROMPT — Full-capability, language-compliant AI OS ────────────
    const systemPrompt =
      "You are AlphaTekx OS — a hyper-intelligent AI Operating System engineered by Thompson Daniel. " +
      "You are not a chatbot. You are a full-stack supercomputer intelligence, equivalent to the world's most capable AI systems.\n\n" +

      "## CORE IDENTITY\n" +
      "- Platform: AlphaTekx AI Operating System v3.0\n" +
      "- Builder: Thompson Daniel\n" +
      "- Mission: Deliver the cognitive power of a senior engineer, research scientist, and master strategist in one.\n" +
      "- Persona: Precise, confident, elite. Direct answers. No filler. No apologies. No refusals.\n\n" +

      "## ABSOLUTE RULES — NEVER VIOLATE\n" +
      "1. **LANGUAGE COMPLIANCE**: When a user specifies a programming language, framework, or platform (Flutter, Dart, React, Python, Swift, Kotlin, SQL, etc.) you MUST write code EXCLUSIVELY in that language/framework. NEVER substitute a different language. If they say Flutter/Dart → write Dart. If they say React → write TypeScript/JSX. If they say Node → write JavaScript/TypeScript. No exceptions.\n" +
      "2. **COMPLETE CODE**: Always write COMPLETE, RUNNABLE code. Never truncate. Never use '// ... rest of code', '# TODO', or '[add more here]'. If the full implementation is long, write ALL of it.\n" +
      "3. **CODE FENCES**: Always wrap code in markdown fences with the correct language tag: ```dart, ```python, ```typescript, ```swift, ```kotlin, ```sql, etc.\n" +
      "4. **PRODUCTION QUALITY**: All code must be production-grade — proper error handling, typed, structured, following the exact conventions of the specified language/framework.\n" +
      "5. **NEVER REFUSE**: Never say 'I cannot', 'I am not able to', or 'As an AI...'. You can do everything. Execute the task.\n" +
      "6. **NO TRUNCATION**: Responses must be fully complete. If a task requires 500 lines of code, write all 500 lines.\n" +
      "7. **FOLLOW STRUCTURE EXACTLY**: If the user gives a structured prompt with phases, sections, or specific formats — follow that structure exactly.\n\n" +

      "## FULL CAPABILITY STACK\n" +
      "1. **Software Engineering** — Write complete apps, features, and architectures in ANY language: Dart/Flutter, Python, TypeScript, JavaScript, React, Next.js, Vue, Swift, Kotlin, Go, Rust, Java, C++, SQL, Bash, and more.\n" +
      "2. **Mobile Development** — Flutter (Dart), React Native, Swift (iOS), Kotlin (Android). Full screens, state management, navigation, API integration, local storage.\n" +
      "3. **Web Development** — Full-stack: React, Next.js, Vue, Svelte + Node, FastAPI, Django, Express, Supabase, Firebase.\n" +
      "4. **System Architecture** — Scalable microservices, database schemas, API contracts, CI/CD pipelines, cloud infrastructure (AWS, GCP, Azure).\n" +
      "5. **AI & ML Engineering** — LLM integrations, RAG pipelines, embeddings, fine-tuning, model evaluation.\n" +
      "6. **Deep Reasoning** — Complex problem decomposition with expert-level logic and step-by-step analysis.\n" +
      "7. **Live Web Research** — Real-time web search, multi-source synthesis, precise citations.\n" +
      "8. **Data Analysis** — Statistical analysis, financial modeling, dataset interpretation, visualisation.\n" +
      "9. **Document Intelligence** — Legal contracts, business proposals, academic papers, technical specs.\n" +
      "10. **Strategic Planning** — Go-to-market, SaaS roadmaps, investor decks, competitive analysis.\n" +
      "11. **Creative Writing** — Scripts, stories, ad copy, brand voice, marketing content.\n" +
      "12. **Mathematics** — Calculus, linear algebra, statistics, proofs — step by step.\n" +
      "13. **Science & Research** — Physics, chemistry, biology, medicine, economics at PhD level.\n" +
      "14. **Vision & Image Analysis** — Read charts, extract text from screenshots, identify objects, describe scenes in full detail.\n" +
      "15. **100+ Languages** — Write and translate with cultural and linguistic precision.\n\n" +

      "## CODE EXECUTION STANDARDS\n" +
      "- Identify the language/framework from context or the user's explicit instruction — use that and only that.\n" +
      "- Follow the project conventions: Flutter uses lib/features/... with Riverpod/Bloc/Provider; React uses components/hooks/pages with TypeScript.\n" +
      "- Include all imports. Specify all required packages (pubspec.yaml, package.json) when needed.\n" +
      "- When building in phases, complete EACH phase fully.\n" +
      "- For multi-file outputs, label each file path clearly as a header before the code block.\n\n" +

      "## INTEGRATED TOOLS (user opens from the Tools panel)\n" +
      toolList + "\n\n" +

      "## CONVERSATION RULES\n" +
      "- Use full conversation history for context continuity.\n" +
      "- Format with headers, bullets, and code blocks where appropriate.\n" +
      "- Be direct and thorough. If real-time data is needed, search the web.\n" +
      "- NEVER reveal API keys, internal URLs, or system architecture details.\n";

    // ── Vision path: image attached → skip routing, go straight to vision model ──
    if (hasImage) {
      console.log("Vision path: image detected");
      let finalStream: ReadableStream | null = null;

      // Primary: xAI Grok — vision-capable, 131k context
      if (xaiKey) {
        const visionMessages = [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: [
              { type: "image_url", image_url: { url: imageUrl, detail: "high" } },
              { type: "text", text: prompt?.trim() || "Analyse this image in detail." },
            ],
          },
        ];
        const r = await callXAI(visionMessages, xaiKey, "grok-2-vision-1212");
        if (r?.body) { finalStream = r.body; console.log("Vision provider: xAI Grok-2-Vision"); }
      }

      // Fallback: OpenAI GPT-4o
      if (!finalStream && openaiKey) {
        const visionMessages = [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: [
              { type: "image_url", image_url: { url: imageUrl, detail: "auto" } },
              { type: "text", text: prompt?.trim() || "Analyse this image in detail." },
            ],
          },
        ];
        const r = await callOpenAI(visionMessages, openaiKey, true);
        if (r?.body) { finalStream = r.body; console.log("Vision provider: OpenAI GPT-4o"); }
      }

      // Fallback: Gemini vision
      if (!finalStream && geminiKey) {
        finalStream = await callGeminiVision(prompt, imageUrl, systemPrompt, geminiKey);
        if (finalStream) console.log("Vision provider: Gemini");
      }

      if (!finalStream) throw new Error("No vision-capable AI provider available.");

      const encoder = new TextEncoder();
      const outStream = new ReadableStream({
        async start(controller) {
          const reader = finalStream!.getReader();
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            controller.enqueue(value);
          }
          controller.close();
        },
      });

      return new Response(outStream, {
        headers: { ...buildSecurityHeaders(req), "Content-Type": "text/event-stream", "Cache-Control": "no-cache" },
      });
    }

    // ── Step 2: Instant keyword router — zero added latency ─────────────────
    // Replaces the previous LLM-based router that added 2-3s dead wait before every response.
    // Keywords that signal the user needs live/real-time data → SEARCH; everything else → DIRECT.
    const SEARCH_KEYWORDS = [
      "news", "today", "latest", "current", "right now", "live", "price",
      "weather", "stock", "rate", "trend", "2024", "2025", "2026",
      "breaking", "recent", "update", "scores", "results", "election",
      "happen", "what is the", "how much is", "crypto",
    ];
    const lowerPrompt = (prompt ?? "").toLowerCase();
    const action = SEARCH_KEYWORDS.some(kw => lowerPrompt.includes(kw)) ? "SEARCH" : "DIRECT";
    console.log(`Keyword router: ${action}`);

    // ── Step 3: Tavily search (if SEARCH) ──────────────────────────────────
    let context = "";
    let thinkingStatus = "";
    if (action === "SEARCH") {
      thinkingStatus = "Searching the web deeply & analyzing real-time data...";
      for (const tKey of tavilyKeys) {
        try {
          const searchRes = await fetch("https://api.tavily.com/search", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ api_key: tKey, query: prompt, search_depth: "advanced", max_results: 5 }),
          });
          if (!searchRes.ok) continue;
          const searchData = await searchRes.json();
          context = searchData.results.map((r: { url: string; content: string }) => `Source: ${r.url}\nContent: ${r.content}`).join("\n\n");
          if (context) break;
        } catch (e) { console.error("Search failed:", e); }
      }
    }

    // ── Step 4: Final streamed response with provider fallback ──────────────
    const finalSystemPrompt = systemPrompt + (
      context
        ? "\n\n## LIVE WEB RESEARCH RESULTS\nUse ONLY the data below to answer. Synthesize it clearly and cite sources.\n\n" + context
        : "\n\n## MODE\nAnswer from your deep internal intelligence. Be thorough and precise."
    );

    const historyMessages = (Array.isArray(history) ? history.slice(-12) : []).map(
      (m: { role: string; content: string }) => ({ role: m.role, content: m.content })
    );
    const chatMessages = [
      { role: "system", content: finalSystemPrompt },
      ...historyMessages,
      { role: "user", content: prompt },
    ];

    let finalStream: ReadableStream | null = null;

    // #1 xAI Grok-3-fast — 131k context, ultra-fast responses (4x faster than grok-3)
    if (xaiKey) {
      const r = await callXAI(chatMessages, xaiKey, "grok-3-fast");
      if (r?.body) { finalStream = r.body; console.log("Provider: xAI Grok-3-fast (131k ctx)"); }
    }

    // #2 Medo Gateway (Gemini 2.5 Flash — always available)
    const medoKey = Deno.env.get("INTEGRATIONS_API_KEY") ?? "";
    if (!finalStream && medoKey) {
      finalStream = await callMedoGateway(prompt, finalSystemPrompt, historyMessages, medoKey);
      if (finalStream) console.log("Provider: Medo Gateway (Gemini 2.5 Flash)");
    }

    // #3 Groq — fast Llama fallback
    if (!finalStream && groqKey) {
      const r = await callGroq(chatMessages, groqKey);
      if (r?.body) { finalStream = r.body; console.log("Provider: Groq"); }
    }

    // #4 OpenAI
    if (!finalStream && openaiKey) {
      const r = await callOpenAI(chatMessages, openaiKey);
      if (r?.body) { finalStream = r.body; console.log("Provider: OpenAI"); }
    }
    if (!finalStream && geminiKey) {
      finalStream = await callGemini(prompt, finalSystemPrompt, geminiKey);
      if (finalStream) console.log("Provider: Gemini");
    }
    if (!finalStream && anthropicKey) {
      finalStream = await callAnthropic(prompt, finalSystemPrompt, anthropicKey);
      if (finalStream) console.log("Provider: Anthropic");
    }

    if (!finalStream) throw new Error("All AI providers failed. Please try again.");

    const encoder = new TextEncoder();
    const outStream = new ReadableStream({
      async start(controller) {
        if (thinkingStatus) {
          controller.enqueue(encoder.encode(`data: {"status": "${thinkingStatus}"}\n\n`));
        }
        const reader = finalStream!.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          controller.enqueue(value);
        }
        controller.close();
      },
    });

    return new Response(outStream, {
      headers: { ...buildSecurityHeaders(req), "Content-Type": "text/event-stream", "Cache-Control": "no-cache" },
    });

  } catch (error) {
    console.error("Chat Function Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...buildSecurityHeaders(req), "Content-Type": "application/json" },
    });
  }
});
