import 'jsr:@supabase/functions-js/edge-runtime.d.ts';
import { runFirewall, SECURITY_HEADERS as CORS } from '../_shared/firewall.ts';

const OWNER_EMAIL = 'alphatekxcompany@gmail.com';

async function sendEmail(apiKey: string, payload: object): Promise<Response> {
  return fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
}

Deno.serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: 'send-waitlist-email', maxReqsPer60s: 5 });
  if (blocked) return blocked;

  try {
    const { email } = await req.json();

    if (!email?.trim() || !email.includes('@')) {
      return new Response(
        JSON.stringify({ error: 'A valid email address is required.' }),
        { status: 400, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
      );
    }

    const apiKey = Deno.env.get('RESEND_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'Email service not configured. Please set RESEND_API_KEY.' }),
        { status: 500, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
      );
    }

    const subscriberEmail = email.trim().toLowerCase();
    const joinedAt = new Date().toUTCString();

    // ── 1. Notify AlphaTekx owner ──────────────────────────────────────────
    const ownerNotification = {
      from: 'AlphaTekx Waitlist <onboarding@resend.dev>',
      to: [OWNER_EMAIL],
      reply_to: subscriberEmail,
      subject: `🚀 New Waitlist Signup — ${subscriberEmail}`,
      html: `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0B0C10; border-radius: 16px; overflow: hidden; border: 1px solid #1e2030;">
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #00E5FF11, #7B6FF511); padding: 32px 32px 24px; border-bottom: 1px solid #1e2030;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
              <span style="font-size: 24px;">🛡️</span>
              <span style="font-size: 18px; font-weight: 900; letter-spacing: -0.5px; color: #fff; text-transform: uppercase;">AlphaTekx AI OS</span>
            </div>
            <p style="color: #00E5FF; font-size: 11px; font-weight: 700; letter-spacing: 0.3em; text-transform: uppercase; margin: 0;">Waitlist Notification</p>
          </div>

          <!-- Body -->
          <div style="padding: 32px;">
            <h2 style="color: #fff; font-size: 22px; font-weight: 900; margin: 0 0 8px;">New Waitlist Signup ⚡</h2>
            <p style="color: #94a3b8; font-size: 14px; margin: 0 0 24px;">Someone just joined the AlphaTekx early access waitlist.</p>

            <div style="background: #0D0E13; border: 1px solid #00E5FF22; border-radius: 12px; padding: 20px; margin-bottom: 24px;">
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; width: 100px;">Email</td>
                  <td style="padding: 8px 0; color: #00E5FF; font-size: 14px; font-weight: 600;">
                    <a href="mailto:${subscriberEmail}" style="color: #00E5FF; text-decoration: none;">${subscriberEmail}</a>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em;">Joined</td>
                  <td style="padding: 8px 0; color: #e2e8f0; font-size: 13px;">${joinedAt}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #64748b; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em;">Source</td>
                  <td style="padding: 8px 0; color: #e2e8f0; font-size: 13px;">Landing Page — Early Access Section</td>
                </tr>
              </table>
            </div>

            <p style="color: #475569; font-size: 12px; border-top: 1px solid #1e2030; padding-top: 20px; margin: 0;">
              AlphaTekx AI Operating System · Automated waitlist notification
            </p>
          </div>
        </div>
      `,
    };

    // ── 2. Confirm subscription to the user ────────────────────────────────
    const subscriberConfirmation = {
      from: 'AlphaTekx AI <onboarding@resend.dev>',
      to: [subscriberEmail],
      subject: `You're on the AlphaTekx waitlist 🚀`,
      html: `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0B0C10; border-radius: 16px; overflow: hidden; border: 1px solid #1e2030;">
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #00E5FF18, #7B6FF518); padding: 40px 32px 32px; text-align: center; border-bottom: 1px solid #1e2030;">
            <div style="font-size: 40px; margin-bottom: 12px;">🛡️</div>
            <h1 style="color: #fff; font-size: 26px; font-weight: 900; letter-spacing: -0.5px; text-transform: uppercase; margin: 0 0 6px;">AlphaTekx AI OS</h1>
            <p style="color: #00E5FF; font-size: 11px; font-weight: 700; letter-spacing: 0.3em; text-transform: uppercase; margin: 0;">You're In The System</p>
          </div>

          <!-- Body -->
          <div style="padding: 40px 32px;">
            <h2 style="color: #fff; font-size: 22px; font-weight: 900; text-align: center; margin: 0 0 12px;">Welcome to the Waitlist ⚡</h2>
            <p style="color: #94a3b8; font-size: 15px; line-height: 1.7; text-align: center; margin: 0 0 32px;">
              You've secured early access to <strong style="color: #fff;">AlphaTekx AI OS</strong> — the AI Operating System built for people who don't settle.
            </p>

            <!-- Features strip -->
            <div style="background: #0D0E13; border: 1px solid #1e2030; border-radius: 12px; padding: 24px; margin-bottom: 32px;">
              <p style="color: #64748b; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.2em; margin: 0 0 16px;">What you're getting access to</p>
              ${['Website Builder', 'Exam Prep Engine', 'AI Art Generator', 'Video Generator', 'Voice Synthesis', 'Script Writer', 'Thumbnail Studio', 'Contract Guard'].map(tool =>
                `<div style="display: flex; align-items: center; gap: 10px; padding: 6px 0; color: #cbd5e1; font-size: 13px; font-weight: 600;">
                  <span style="color: #00E5FF; font-size: 14px;">✦</span> ${tool}
                </div>`
              ).join('')}
            </div>

            <!-- CTA -->
            <div style="text-align: center; margin-bottom: 32px;">
              <a href="https://alphatekx.mdo.pw" style="display: inline-block; background: linear-gradient(135deg, #00E5FF, #38bdf8); color: #0B0C10; font-weight: 900; font-size: 13px; text-transform: uppercase; letter-spacing: 0.12em; text-decoration: none; padding: 14px 32px; border-radius: 10px;">
                Launch AlphaTekx OS →
              </a>
            </div>

            <p style="color: #334155; font-size: 12px; text-align: center; border-top: 1px solid #1e2030; padding-top: 24px; margin: 0;">
              © ${new Date().getFullYear()} AlphaTekx AI · All rights reserved<br/>
              You received this because you joined the AlphaTekx waitlist.
            </p>
          </div>
        </div>
      `,
    };

    // Send both in parallel
    const [ownerRes, subscriberRes] = await Promise.all([
      sendEmail(apiKey, ownerNotification),
      sendEmail(apiKey, subscriberConfirmation),
    ]);

    if (!ownerRes.ok || !subscriberRes.ok) {
      const errText = await (ownerRes.ok ? subscriberRes : ownerRes).text();
      console.error('Resend error:', errText);
      return new Response(
        JSON.stringify({ error: 'Failed to send email. Please try again.' }),
        { status: 502, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
      );
    }

    return new Response(
      JSON.stringify({ success: true }),
      { status: 200, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
    );

  } catch (err) {
    console.error('send-waitlist-email error:', err);
    return new Response(
      JSON.stringify({ error: 'Internal server error.' }),
      { status: 500, headers: { ...buildSecurityHeaders(req), 'Content-Type': 'application/json' } },
    );
  }
});
