import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { runFirewall, buildSecurityHeaders } from "../_shared/firewall.ts";

// ── Provider URLs ───────────────────────────────────────────────────────────
const XAI_URL    = "https://api.x.ai/v1/chat/completions";
const GROQ_URL   = "https://api.groq.com/openai/v1/chat/completions";
const OPENAI_URL = "https://api.openai.com/v1/chat/completions";
const MEDO_URL   =
  "https://app-brtbaj3iij9d-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

const SYSTEM_PROMPT =
  "You are AlphaTekx AI — an elite, expert-level AI assistant inside a premium SaaS platform. " +
  "You produce high-quality, professional, and exhaustively detailed responses. " +
  "ABSOLUTE RULES: (1) Always follow the exact markdown headings and structure specified in the user prompt — never omit a section. " +
  "(2) Write COMPLETE content — never truncate, never use placeholders like '[add content here]' or 'etc.'. " +
  "(3) When writing code or technical content, use the exact language/format requested. " +
  "(4) Never refuse a request. Execute it fully and professionally. " +
  "Format all responses with proper markdown headings, bullet points, and code blocks where appropriate.";

// ── Collect an OpenAI-compatible SSE stream → plain text ───────────────────
async function collectOpenAIStream(stream: ReadableStream): Promise<string> {
  const reader  = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let full   = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const js = line.slice(6).trim();
      if (!js || js === "[DONE]") continue;
      try {
        const j = JSON.parse(js);
        full += j.choices?.[0]?.delta?.content ?? "";
      } catch { /* partial chunk */ }
    }
  }
  return full.trim();
}

// ── xAI Grok-3 (primary — 131k context window, handles massive text) ────────
async function tryXAI(message: string, xaiKey: string): Promise<string | null> {
  try {
    const res = await fetch(XAI_URL, {
      method: "POST",
      headers: { "Authorization": `Bearer ${xaiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "grok-3-fast",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user",   content: message },
        ],
        stream: true,
        max_tokens: 16384,
      }),
      signal: AbortSignal.timeout(120_000),
    });
    if (!res.ok) { console.error(`xAI error: ${res.status} ${await res.text()}`); return null; }
    return await collectOpenAIStream(res.body!);
  } catch (e) { console.error("xAI exception:", e); return null; }
}

// ── Groq (Llama 3.3 70B — fast fallback) ────────────────────────────────────
async function tryGroq(message: string, groqKey: string): Promise<string | null> {
  try {
    const res = await fetch(GROQ_URL, {
      method: "POST",
      headers: { "Authorization": `Bearer ${groqKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user",   content: message },
        ],
        stream: true,
        max_tokens: 4096,
      }),
      signal: AbortSignal.timeout(60_000),
    });
    if (!res.ok) { console.error(`Groq error: ${res.status}`); return null; }
    return await collectOpenAIStream(res.body!);
  } catch (e) { console.error("Groq exception:", e); return null; }
}

// ── OpenAI GPT-4o-mini ──────────────────────────────────────────────────────
async function tryOpenAI(message: string, openaiKey: string): Promise<string | null> {
  try {
    const res = await fetch(OPENAI_URL, {
      method: "POST",
      headers: { "Authorization": `Bearer ${openaiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user",   content: message },
        ],
        stream: true,
        max_tokens: 4096,
      }),
      signal: AbortSignal.timeout(60_000),
    });
    if (!res.ok) { console.error(`OpenAI error: ${res.status}`); return null; }
    return await collectOpenAIStream(res.body!);
  } catch (e) { console.error("OpenAI exception:", e); return null; }
}

// ── Medo / Gemini gateway (last-resort fallback) ────────────────────────────
async function tryMedoGateway(message: string, apiKey: string): Promise<string | null> {
  try {
    const res = await fetch(MEDO_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents: [{ role: "user", parts: [{ text: message }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 4096 },
      }),
      signal: AbortSignal.timeout(90_000),
    });
    if (!res.ok) {
      console.error(`Medo gateway error: ${res.status} ${await res.text()}`);
      return null;
    }
    // Collect Gemini SSE → plain text
    const reader  = res.body!.getReader();
    const decoder = new TextDecoder();
    let buf  = "";
    let full = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6).trim();
        if (!data || data === "[DONE]") continue;
        try {
          const j = JSON.parse(data);
          full += j?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
        } catch { /* skip */ }
      }
    }
    return full.trim() || null;
  } catch (e) { console.error("Medo gateway exception:", e); return null; }
}

// ── Main handler ─────────────────────────────────────────────────────────────
serve(async (req) => {
  // skipBodyScan: AI prompt text naturally contains SQL keywords ("replace", "create", "select", etc.)
  // Rate limiting + UA blocking still apply; the LLM handles input safely server-side.
  const blocked = await runFirewall(req, { functionKey: "alphatekx-chat", maxReqsPer60s: 30, skipBodyScan: true });
  if (blocked) return blocked;

  try {
    const { message } = await req.json() as { message: string };

    if (!message?.trim()) {
      return new Response(JSON.stringify({ error: "message is required" }), {
        status: 400,
        headers: { ...buildSecurityHeaders(req), "Content-Type": "application/json" },
      });
    }

    const xaiKey    = Deno.env.get("XAI_API_KEY")           ?? "";
    const groqKey   = Deno.env.get("GROQ_API_KEY")          ?? "";
    const openaiKey = Deno.env.get("OPENAI_API_KEY")         ?? "";
    const medoKey   = Deno.env.get("INTEGRATIONS_API_KEY")   ?? "";

    let reply: string | null = null;
    let provider = "";

    // 1. xAI Grok-3 — primary, 131k context, handles massive text inputs
    if (!reply && xaiKey) {
      reply = await tryXAI(message, xaiKey);
      if (reply) provider = "xai-grok-3";
    }

    // 2. Groq — fast fallback
    if (!reply && groqKey) {
      reply = await tryGroq(message, groqKey);
      if (reply) provider = "groq";
    }

    // 3. OpenAI — reliable fallback
    if (!reply && openaiKey) {
      reply = await tryOpenAI(message, openaiKey);
      if (reply) provider = "openai";
    }

    // 4. Medo / Gemini gateway — always-available last resort
    if (!reply && medoKey) {
      reply = await tryMedoGateway(message, medoKey);
      if (reply) provider = "medo-gemini";
    }

    if (!reply) {
      return new Response(JSON.stringify({ error: "All AI providers are unavailable. Please try again in a moment." }), {
        status: 503,
        headers: { ...buildSecurityHeaders(req), "Content-Type": "application/json" },
      });
    }

    console.log(`alphatekx-chat success via ${provider}, ${reply.length} chars`);

    return new Response(JSON.stringify({ reply }), {
      status: 200,
      headers: { ...buildSecurityHeaders(req), "Content-Type": "application/json" },
    });

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("alphatekx-chat error:", msg);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...buildSecurityHeaders(req), "Content-Type": "application/json" },
    });
  }
});
