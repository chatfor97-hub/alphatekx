import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { runFirewall, SECURITY_HEADERS as corsHeaders } from "../_shared/firewall.ts";

serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: "kling-omni-video-submit", maxReqsPer60s: 10 });
  if (blocked) return blocked;

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: req.headers.get("Authorization")! } } }
    );

    const { prompt, aspect_ratio = "16:9" } = await req.json();
    console.log(`[REPLICATE] Video Submit — Prompt: "${prompt.substring(0, 80)}...", Aspect Ratio: ${aspect_ratio}`);

    // Auth is optional during construction phase
    let userId: string | null = null;
    try {
      const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
      if (!authError && user) {
        userId = user.id;
        console.log(`Authenticated user: ${userId}`);
      } else {
        console.warn("No authenticated user. Proceeding in anonymous/construction mode.");
      }
    } catch (e) {
      console.warn("Auth check failed:", e);
    }

    // Credit Check & Deduction for Video (5 credits) — only if authenticated
    if (userId) {
      const { data: hasCredits, error: rpcError } = await supabaseClient.rpc("check_and_deduct_video_credits", {
        p_user_id: userId
      });

      if (rpcError) {
        console.error("RPC Error:", rpcError);
        throw new Error(`Credit check failed: ${rpcError.message}`);
      }

      if (!hasCredits) {
        return new Response(JSON.stringify({ error: "Insufficient credits for video generation. (Cost: 5 credits)" }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      console.log("Credits deducted successfully.");
    } else {
      console.log("Skipping credit check for anonymous user.");
    }

    // Call Replicate API
    const apiKey = Deno.env.get("REPLICATE_API_TOKEN");
    if (!apiKey) {
      throw new Error("Missing REPLICATE_API_TOKEN in environment");
    }

    // Step 1: Generate image from prompt using flux-schnell (fastest, cheapest)
    console.log("[REPLICATE] Step 1: Generating image with flux-schnell...");
    const width = aspect_ratio === "9:16" ? 576 : (aspect_ratio === "1:1" ? 768 : 1024);
    const height = aspect_ratio === "9:16" ? 1024 : (aspect_ratio === "1:1" ? 768 : 576);

    const fluxResponse = await fetch(
      "https://api.replicate.com/v1/models/black-forest-labs/flux-schnell/predictions",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Token ${apiKey}`,
          "Prefer": "return=representation",
        },
        body: JSON.stringify({
          input: { prompt, aspect_ratio: `${width}:${height}` },
        }),
      }
    );

    const fluxResult = await fluxResponse.json();
    console.log("[REPLICATE] Flux response status:", fluxResponse.status);

    if (!fluxResponse.ok) {
      const errMsg = fluxResult.detail || fluxResult.error || JSON.stringify(fluxResult);
      throw new Error(`Replicate Flux error (${fluxResponse.status}): ${errMsg}`);
    }

    // Poll flux until complete (it's fast, usually <5s)
    let fluxOutput = fluxResult.output;
    let fluxStatus = fluxResult.status;
    let fluxPollCount = 0;
    const maxFluxPolls = 30;

    while (fluxStatus !== "succeeded" && fluxStatus !== "failed" && fluxPollCount < maxFluxPolls) {
      await new Promise(r => setTimeout(r, 1000));
      const pollRes = await fetch(
        `https://api.replicate.com/v1/predictions/${fluxResult.id}`,
        { headers: { "Authorization": `Token ${apiKey}` } }
      );
      const pollData = await pollRes.json();
      fluxStatus = pollData.status;
      fluxOutput = pollData.output;
      fluxPollCount++;
    }

    if (fluxStatus === "failed" || !fluxOutput) {
      throw new Error("Flux image generation failed or timed out");
    }

    const imageUrl = Array.isArray(fluxOutput) ? fluxOutput[0] : fluxOutput;
    console.log("[REPLICATE] Image generated:", imageUrl);

    // Step 2: Animate image with Wan 2.1 T2V (text-to-video via image conditioning)
    // Try Wan 2.1 first, fall back to stable-video-diffusion if needed
    const wanModel = "wagh-7777/wan2.1-t2v-1.3b";
    console.log("[REPLICATE] Step 2: Submitting to Wan 2.1 T2V...");

    const wanPayload = {
      input: {
        image: imageUrl,
        prompt: prompt.substring(0, 200),
        num_frames: 16,
        fps: 8,
      }
    };

    const wanResponse = await fetch(
      `https://api.replicate.com/v1/models/${wanModel}/predictions`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Token ${apiKey}`,
          "Prefer": "return=representation",
        },
        body: JSON.stringify(wanPayload),
      }
    );

    const wanResult = await wanResponse.json();
    console.log("[REPLICATE] Wan 2.1 response status:", wanResponse.status, "body:", JSON.stringify(wanResult).substring(0, 500));

    if (!wanResponse.ok) {
      // If Wan model not found, fall back to stable-video-diffusion
      if (wanResponse.status === 404) {
        console.warn("[REPLICATE] Wan 2.1 model not found, falling back to stable-video-diffusion...");
        
        const svdResponse = await fetch(
          "https://api.replicate.com/v1/models/stability-ai/stable-video-diffusion/predictions",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Token ${apiKey}`,
              "Prefer": "return=representation",
            },
            body: JSON.stringify({
              input: {
                image: imageUrl,
                motion_bucket_id: 127,
                noise_aug_strength: 0.02,
              }
            }),
          }
        );

        const svdResult = await svdResponse.json();
        console.log("[REPLICATE] SVD response status:", svdResponse.status);

        if (!svdResponse.ok) {
          const errMsg = svdResult.detail || svdResult.error || JSON.stringify(svdResult);
          throw new Error(`Replicate SVD error (${svdResponse.status}): ${errMsg}`);
        }

        const taskId = svdResult.id;
        console.log("[REPLICATE] SVD task submitted, prediction_id:", taskId);

        const normalized = {
          code: 0,
          message: "success",
          data: {
            task_id: taskId,
            task_status: "submitted",
          }
        };

        return new Response(JSON.stringify(normalized), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const errMsg = wanResult.detail || wanResult.error || JSON.stringify(wanResult);
      throw new Error(`Replicate Wan 2.1 error (${wanResponse.status}): ${errMsg}`);
    }

    const taskId = wanResult.id;
    console.log("[REPLICATE] Wan 2.1 task submitted, prediction_id:", taskId);

    const normalized = {
      code: 0,
      message: "success",
      data: {
        task_id: taskId,
        task_status: "submitted",
      }
    };

    return new Response(JSON.stringify(normalized), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("[REPLICATE] Submit Error:", error.message);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
