/**
 * analytics-summary — complete real platform analytics for the admin dashboard.
 *
 * Every metric is derived from actual rows in Supabase tables — zero fake data.
 *
 * Sections returned:
 *  realtime:
 *    - activeUsers       distinct sessions with last_seen in last 5 min
 *    - screenViews30min  page_views rows in last 30 min
 *    - events30min       same (every page view is an event)
 *    - topPagesNow       pages ranked by live active sessions
 *
 *  last30Days:
 *    - sessions          distinct session_ids
 *    - uniqueVisitors    distinct session_ids (same as sessions for anonymous)
 *    - pageViews         total page_view rows
 *    - bounceRate        % of sessions with only 1 page view
 *    - newSignups        new profiles.created_at in range
 *    - creditTopups      credit_topups rows in range
 *    - creditTransfers   credit_transfers rows in range
 *
 *  users:
 *    - totalRegistered, signupsToday, signupsYesterday
 *
 *  devices:            desktop/mobile/tablet percentages (last 30 days)
 *  topSources:         referrer_source ranked list (last 30 days)
 *  topPages:           page_path ranked by view count (last 30 days)
 */

import { createClient } from "npm:@supabase/supabase-js@2";
import { buildSecurityHeaders } from "../_shared/firewall.ts";

const SUPABASE_URL     = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SRV_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

// buildSecurityHeaders expects a Request object (not a string)
function cors(req: Request, body: string, status = 200) {
  return new Response(body, {
    status,
    headers: { ...buildSecurityHeaders(req), "Content-Type": "application/json" },
  });
}

// Count distinct values in an array of objects by a key
function countBy<T extends Record<string, unknown>>(rows: T[], key: keyof T): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const row of rows) {
    const val = String(row[key] ?? "unknown");
    counts[val] = (counts[val] ?? 0) + 1;
  }
  return counts;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return cors(req, "", 204);
  if (req.method !== "GET" && req.method !== "POST")
    return cors(req, JSON.stringify({ error: "Method not allowed" }), 405);

  const supabase = createClient(SUPABASE_URL, SUPABASE_SRV_KEY);
  const now = new Date();

  const fiveMinAgo    = new Date(now.getTime() -  5 * 60 * 1000).toISOString();
  const thirtyMinAgo  = new Date(now.getTime() - 30 * 60 * 1000).toISOString();
  const todayStart    = new Date(now.toISOString().slice(0, 10) + "T00:00:00.000Z").toISOString();
  const thirtyDayAgo  = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();
  const yesterdayStart = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();

  try {
    // ── 1. Active users (sessions seen in last 5 min) ───────────────────────
    const { count: activeUsers } = await supabase
      .from("active_sessions")
      .select("*", { count: "exact", head: true })
      .gte("last_seen", fiveMinAgo);

    // ── 2. Live page list (top pages by active sessions right now) ───────────
    const { data: activePagesData } = await supabase
      .from("active_sessions")
      .select("page_path")
      .gte("last_seen", fiveMinAgo);

    const activeCounts = countBy((activePagesData ?? []) as { page_path: string }[], "page_path");
    const topPagesNow = Object.entries(activeCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([page, users]) => ({ page, users }));

    // ── 3. Screen views in last 30 min ───────────────────────────────────────
    const { count: screenViews30min } = await supabase
      .from("page_views")
      .select("*", { count: "exact", head: true })
      .gte("created_at", thirtyMinAgo);

    // events = page views (every page visit is an event in our system)
    const events30min = screenViews30min ?? 0;

    // ── 4. Today's unique sessions ───────────────────────────────────────────
    const { data: todaySessionsData } = await supabase
      .from("page_views")
      .select("session_id")
      .gte("created_at", todayStart);

    const todaySessions = new Set(
      (todaySessionsData ?? []).map((r: { session_id: string }) => r.session_id)
    ).size;

    // ── 5. Last 30 days — full page_views fetch for aggregations ─────────────
    const { data: pv30 } = await supabase
      .from("page_views")
      .select("session_id, page_path, device_type, referrer_source")
      .gte("created_at", thirtyDayAgo);

    const pv30Rows = (pv30 ?? []) as {
      session_id: string;
      page_path: string;
      device_type: string;
      referrer_source: string | null;
    }[];

    const pageViews30d = pv30Rows.length;

    // Unique sessions last 30d
    const sessions30dSet = new Set(pv30Rows.map(r => r.session_id));
    const uniqueSessions30d = sessions30dSet.size;

    // Bounce rate: sessions where total page views = 1
    const sessionPageCounts: Record<string, number> = {};
    for (const r of pv30Rows) {
      sessionPageCounts[r.session_id] = (sessionPageCounts[r.session_id] ?? 0) + 1;
    }
    const singlePageSessions = Object.values(sessionPageCounts).filter(c => c === 1).length;
    const bounceRate = uniqueSessions30d > 0
      ? Math.round((singlePageSessions / uniqueSessions30d) * 1000) / 10
      : 0;

    // Device breakdown
    const deviceCounts = countBy(pv30Rows, "device_type");
    const deviceTotal  = pv30Rows.length || 1;
    const devices = ["desktop", "mobile", "tablet"].map(device => ({
      device: device.charAt(0).toUpperCase() + device.slice(1),
      views: deviceCounts[device] ?? 0,
      pct: Math.round(((deviceCounts[device] ?? 0) / deviceTotal) * 100),
    }));

    // Traffic sources
    const sourceCounts = countBy(
      pv30Rows.map(r => ({ source: r.referrer_source ?? "Direct" })),
      "source"
    );
    const topSources = Object.entries(sourceCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([source, sessions]) => ({ source, sessions }));

    // Top pages
    const pathCounts = countBy(pv30Rows, "page_path");
    const topPages = Object.entries(pathCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([page, views]) => ({ page, views }));

    // ── 6. Registered users ──────────────────────────────────────────────────
    const { count: totalRegistered } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true });

    const { count: signupsToday } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .gte("created_at", todayStart);

    const { count: signupsYesterday } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .gte("created_at", yesterdayStart)
      .lt("created_at", todayStart);

    const { count: signups30d } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .gte("created_at", thirtyDayAgo);

    // ── 7. Credit activity ───────────────────────────────────────────────────
    const { count: topups30d } = await supabase
      .from("credit_topups")
      .select("*", { count: "exact", head: true })
      .gte("created_at", thirtyDayAgo);

    const { count: transfers30d } = await supabase
      .from("credit_transfers")
      .select("*", { count: "exact", head: true })
      .gte("created_at", thirtyDayAgo);

    return cors(req, JSON.stringify({
      generatedAt: now.toISOString(),
      realtime: {
        activeUsers:      activeUsers     ?? 0,
        screenViews30min: screenViews30min ?? 0,
        events30min,
        todaySessions,
        topPagesNow,
      },
      last30Days: {
        sessions:        uniqueSessions30d,
        uniqueVisitors:  uniqueSessions30d,
        pageViews:       pageViews30d,
        bounceRate,
        newSignups:      signups30d      ?? 0,
        creditTopups:    topups30d       ?? 0,
        creditTransfers: transfers30d    ?? 0,
      },
      users: {
        totalRegistered:  totalRegistered  ?? 0,
        signupsToday:     signupsToday     ?? 0,
        signupsYesterday: signupsYesterday ?? 0,
      },
      devices,
      topSources,
      topPages,
    }));
  } catch (err) {
    console.error("analytics-summary error:", err);
    return cors(req, JSON.stringify({ error: "Failed to load analytics" }), 500);
  }
});
