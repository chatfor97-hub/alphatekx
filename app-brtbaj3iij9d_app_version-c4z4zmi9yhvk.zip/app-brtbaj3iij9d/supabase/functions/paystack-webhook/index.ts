import { createClient } from "jsr:@supabase/supabase-js@2";
import { runFirewall, SECURITY_HEADERS, buildSecurityHeaders } from "../_shared/firewall.ts";

// ─────────────────────────────────────────────────────────────────────────────
// Credit pack definitions — Exchange rate: $1 USD = ₦1,373.42 (flat)
// amountKobo values are hardcoded integers — no float math, no rounding risk.
//
//  Tier 1  $1  →  ₦1,373.42  →      137,342 kobo  →    50 credits
//  Tier 2  $5  →  ₦6,867.10  →      686,710 kobo  →   300 credits
//  Tier 3  $10 →  ₦13,734.20 →    1,373,420 kobo  →   700 credits
//  Tier 4  $50 →  ₦68,671.00 →    6,867,100 kobo  → 3,500 credits
// ─────────────────────────────────────────────────────────────────────────────
const CREDIT_PACKS: Record<string, { credits: number; amountNgn: number; amountKobo: number; usd: number }> = {
  starter: { credits:   50, usd:  1, amountNgn:  1_373.42, amountKobo:   137_342 },
  popular: { credits:  300, usd:  5, amountNgn:  6_867.10, amountKobo:   686_710 },
  pro:     { credits:  700, usd: 10, amountNgn: 13_734.20, amountKobo: 1_373_420 },
  elite:   { credits: 3500, usd: 50, amountNgn: 68_671.00, amountKobo: 6_867_100 },
};

// ── Reverse lookup: kobo amount → packId ──────────────────────────────────────
// Used as a fallback when metadata.pack_id is absent from the webhook payload.
// Allows the webhook to match any payment purely by the amount received in kobo.
const KOBO_TIER_MAP: Record<number, string> = {
    137_342: "starter",
    686_710: "popular",
  1_373_420: "pro",
  6_867_100: "elite",
};

// ─────────────────────────────────────────────────────────────────────────────
// Response helper
// ─────────────────────────────────────────────────────────────────────────────
function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// HMAC-SHA512 signature verification
//
// Paystack signs every webhook payload with HMAC-SHA512 using the secret key.
// Signature is delivered in x-paystack-signature as a lowercase hex string.
// Raw bytes MUST be read before any JSON parsing — parsing changes the bytes.
// Uses constant-time comparison to prevent timing-oracle attacks.
// ─────────────────────────────────────────────────────────────────────────────
async function verifyPaystackSignature(
  rawBody: Uint8Array,
  incomingSignature: string,
  secretKey: string,
): Promise<boolean> {
  try {
    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(secretKey),
      { name: "HMAC", hash: "SHA-512" },
      false,
      ["sign"],
    );

    const sigBuffer  = await crypto.subtle.sign("HMAC", cryptoKey, rawBody);
    const computedHex = Array.from(new Uint8Array(sigBuffer))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");

    if (computedHex.length !== incomingSignature.length) return false;

    // XOR every character — any mismatch sets mismatch to non-zero
    let mismatch = 0;
    for (let i = 0; i < computedHex.length; i++) {
      mismatch |= computedHex.charCodeAt(i) ^ incomingSignature.charCodeAt(i);
    }
    return mismatch === 0;
  } catch (err) {
    console.error("Signature verification error:", err);
    return false;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Firebase Admin — Service Account JWT → Google OAuth2 access token
//
// Deno cannot use the Firebase Admin SDK directly.
// We sign a JWT with the service account private key (RS256), then exchange it
// for a short-lived OAuth2 Bearer token to call the Firestore REST API.
// ─────────────────────────────────────────────────────────────────────────────
async function getFirebaseAccessToken(
  clientEmail: string,
  privateKey: string,
): Promise<string> {
  const now    = Math.floor(Date.now() / 1000);
  const b64url = (s: string) =>
    btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");

  const header  = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const payload = b64url(JSON.stringify({
    iss:   clientEmail,
    sub:   clientEmail,
    scope: "https://www.googleapis.com/auth/datastore https://www.googleapis.com/auth/firebase",
    aud:   "https://oauth2.googleapis.com/token",
    iat:   now,
    exp:   now + 3600,
  }));

  const signingInput = `${header}.${payload}`;

  // Strip PEM headers and normalise line endings (handle literal \n from env vars)
  const pem = privateKey
    .replace(/\\n/g, "\n")
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s+/g, "");

  const keyBytes  = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const cryptoKey = await crypto.subtle.importKey(
    "pkcs8", keyBytes,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false, ["sign"],
  );

  const sigBuf = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5", cryptoKey,
    new TextEncoder().encode(signingInput),
  );
  const sig = btoa(String.fromCharCode(...new Uint8Array(sigBuf)))
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");

  const jwt = `${signingInput}.${sig}`;

  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion:  jwt,
    }).toString(),
  });

  if (!tokenRes.ok) {
    const t = await tokenRes.text();
    throw new Error(`Firebase token exchange failed ${tokenRes.status}: ${t}`);
  }
  const td = await tokenRes.json();
  if (!td.access_token) throw new Error(`No access_token: ${JSON.stringify(td)}`);
  return td.access_token as string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Firestore: look up firebase_uid by email (fallback when metadata is absent)
//
// Queries the `users` collection for a document where email == customerEmail.
// Returns the document ID (which is the firebase_uid) or null if not found.
// ─────────────────────────────────────────────────────────────────────────────
async function lookupFirebaseUidByEmail(
  projectId: string,
  customerEmail: string,
  accessToken: string,
): Promise<string | null> {
  const runQueryUrl =
    `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents:runQuery`;

  const res = await fetch(runQueryUrl, {
    method: "POST",
    headers: {
      Authorization:  `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      structuredQuery: {
        from:  [{ collectionId: "users" }],
        where: {
          fieldFilter: {
            field:  { fieldPath: "email" },
            op:     "EQUAL",
            value:  { stringValue: customerEmail.trim().toLowerCase() },
          },
        },
        limit: 1,
      },
    }),
  });

  if (!res.ok) {
    console.warn(`Firestore user lookup failed: ${res.status}`);
    return null;
  }

  const results = await res.json() as Array<{ document?: { name?: string } }>;
  const docName = results?.[0]?.document?.name;
  if (!docName) return null;

  // Document name format: projects/{proj}/databases/(default)/documents/users/{uid}
  return docName.split("/").pop() ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Firestore: atomic credit increment via REST commit API
//
// Uses fieldTransform / INCREMENT — identical to Firestore SDK increment().
// ─────────────────────────────────────────────────────────────────────────────
async function incrementFirestoreCredits(
  projectId: string,
  uid: string,
  creditsToAdd: number,
  accessToken: string,
): Promise<void> {
  const docPath = `projects/${projectId}/databases/(default)/documents/users/${uid}`;
  const commitUrl = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents:commit`;

  const res = await fetch(commitUrl, {
    method: "POST",
    headers: {
      Authorization:  `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      writes: [{
        transform: {
          document:        docPath,
          fieldTransforms: [{
            fieldPath: "credits",
            increment: { integerValue: String(creditsToAdd) },
          }],
        },
      }],
    }),
  });

  if (!res.ok) {
    const t = await res.text();
    throw new Error(`Firestore commit failed ${res.status}: ${t}`);
  }
  console.log(`Firestore incremented: uid=${uid}, +${creditsToAdd} credits`);
}

// ─────────────────────────────────────────────────────────────────────────────
// Main webhook handler
// ─────────────────────────────────────────────────────────────────────────────
Deno.serve(async (req) => {
  // Firewall: rate-limit + UA blocking + URL scan. Body scan skipped because
  // HMAC-SHA512 verification (below) is the authoritative payload check.
  const blocked = await runFirewall(req, {
    functionKey: "paystack-webhook",
    maxReqsPer60s: 60,
    skipBodyScan: true,
    allowedMethods: ["POST", "OPTIONS"],
  });
  if (blocked) return blocked;

  // ── 1. POST only ───────────────────────────────────────────────────────────
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  // ── 2. Read raw body bytes BEFORE any parsing ──────────────────────────────
  // HMAC-SHA512 is computed over the exact bytes Paystack transmitted.
  // Parsing the body first (even to the same value) produces different bytes.
  const rawBodyBytes = new Uint8Array(await req.arrayBuffer());

  // ── 3. Verify x-paystack-signature header ──────────────────────────────────
  const paystackSecretKey = Deno.env.get("PAYSTACK_SECRET_KEY") ?? "";
  if (!paystackSecretKey) {
    console.error("PAYSTACK_SECRET_KEY not configured");
    return json({ error: "Server configuration error" }, 500);
  }

  const incomingSignature = (req.headers.get("x-paystack-signature") ?? "").toLowerCase();
  if (!incomingSignature) {
    console.warn("Missing x-paystack-signature — rejecting");
    return json({ error: "Missing signature" }, 401);
  }

  const signatureValid = await verifyPaystackSignature(
    rawBodyBytes, incomingSignature, paystackSecretKey,
  );
  if (!signatureValid) {
    console.warn("Signature mismatch — possible spoofed request");
    return json({ error: "Invalid signature" }, 401);
  }

  // ── 4. Parse verified payload ──────────────────────────────────────────────
  let payload: Record<string, unknown>;
  try {
    payload = JSON.parse(new TextDecoder().decode(rawBodyBytes));
  } catch {
    return json({ error: "Invalid JSON body" }, 400);
  }

  const event = payload.event as string | undefined;
  console.log(`Paystack webhook received: event=${event}`);

  // ── 5. Only handle charge.success — ack everything else silently ───────────
  // Paystack retries any webhook that doesn't receive HTTP 200.
  if (event !== "charge.success") {
    return json({ received: true, processed: false, reason: `event '${event}' not handled` });
  }

  // ── 6. Extract payment details from payload ────────────────────────────────
  const data       = (payload.data ?? {}) as Record<string, unknown>;
  const reference  = data.reference   as string | undefined;
  const status     = data.status      as string | undefined;
  const amountKobo = data.amount      as number | undefined; // integer in kobo
  const currency   = ((data.currency  as string) ?? "NGN").toUpperCase();
  const customer   = (data.customer   ?? {}) as Record<string, unknown>;
  const email      = customer.email   as string | undefined;
  const metadata   = (data.metadata   ?? {}) as Record<string, unknown>;

  // Convert kobo → Naira for logging (÷ 100)
  const amountNgn = amountKobo != null ? amountKobo / 100 : null;

  console.log(
    `charge.success: ref=${reference}, email=${email}, ` +
    `amount=₦${amountNgn} (${amountKobo} kobo, ${currency}), status=${status}`
  );

  if (!reference) {
    console.error("charge.success has no reference — cannot process");
    return json({ received: true, processed: false, reason: "no reference" });
  }
  if (status !== "success") {
    console.warn(`data.status=${status} is not 'success' — skipping`);
    return json({ received: true, processed: false, reason: `data.status='${status}'` });
  }

  // ── 7. Resolve pack: metadata first, then kobo-tier fallback ──────────────
  // Primary: pack_id embedded in metadata during initialize-paystack.
  // Fallback: match the received kobo amount against KOBO_TIER_MAP — handles
  //           payments initiated outside the app or metadata loss.
  const metaPackId   = metadata.pack_id      as string | undefined;
  const metaUid      = metadata.firebase_uid as string | undefined;

  let resolvedPackId = metaPackId;
  if (!resolvedPackId && amountKobo != null) {
    resolvedPackId = KOBO_TIER_MAP[amountKobo];
    if (resolvedPackId) {
      console.log(`Pack resolved via kobo tier map: ${amountKobo} kobo → ${resolvedPackId}`);
    } else {
      console.warn(`No pack matched for ${amountKobo} kobo — ref=${reference}`);
    }
  }

  const pack = resolvedPackId ? CREDIT_PACKS[resolvedPackId] : undefined;

  // ── 8. Supabase setup ──────────────────────────────────────────────────────
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
  );

  // ── 9. Idempotency check — never double-credit the same reference ──────────
  const { data: existing, error: lookupErr } = await supabase
    .from("credit_topups")
    .select("id, status, credits_added, firebase_uid, pack_id")
    .eq("paystack_ref", reference)
    .maybeSingle();

  if (lookupErr) {
    console.error("DB lookup error:", lookupErr);
    return json({ error: "DB lookup failed" }, 500); // 500 → Paystack retries
  }

  if (existing?.status === "verified") {
    console.log(`Ref ${reference} already verified — idempotent ack`);
    return json({ received: true, processed: false, reason: "already verified" });
  }

  // Prefer DB values (set during init) over webhook metadata
  const resolvedUid    = existing?.firebase_uid ?? metaUid;
  const finalPackId    = existing?.pack_id      ?? resolvedPackId ?? "unknown";
  const finalPack      = CREDIT_PACKS[finalPackId] ?? pack;
  const creditsToAdd   = finalPack?.credits ?? 0;

  if (creditsToAdd === 0) {
    console.error(`creditsToAdd=0 — unknown pack. ref=${reference}, kobo=${amountKobo}`);
    return json({ received: true, processed: false, reason: "unknown tier / 0 credits" });
  }

  // ── 10. Upsert credit_topups as "verified" ─────────────────────────────────
  // UNIQUE constraint on paystack_ref is the atomic guard against race conditions.
  const { error: upsertErr } = await supabase.from("credit_topups").upsert(
    {
      pack_id:        finalPackId,
      credits_added:  creditsToAdd,
      amount_usd:     finalPack?.amountNgn ?? amountNgn ?? 0,
      paystack_ref:   reference,
      status:         "verified",
      webhook_source: "webhook",
      verified_at:    new Date().toISOString(),
      // firebase_uid resolved below — update separately if found via email
      ...(resolvedUid ? { firebase_uid: resolvedUid } : {}),
    },
    { onConflict: "paystack_ref", ignoreDuplicates: false },
  );

  if (upsertErr) {
    if (upsertErr.code === "23505") {
      console.log(`Race condition resolved by DB constraint. ref=${reference}`);
      return json({ received: true, processed: false, reason: "concurrent write" });
    }
    console.error("credit_topups upsert error:", upsertErr);
    return json({ error: "DB write failed" }, 500);
  }

  console.log(`DB upserted: ref=${reference}, pack=${finalPackId}, credits=${creditsToAdd}`);

  // ── 11. Resolve firebase_uid — email fallback via Firestore query ──────────
  const firebaseProjectId   = Deno.env.get("FIREBASE_PROJECT_ID");
  const firebaseClientEmail = Deno.env.get("FIREBASE_CLIENT_EMAIL");
  const firebasePrivateKey  = Deno.env.get("FIREBASE_PRIVATE_KEY");

  if (!firebaseProjectId || !firebaseClientEmail || !firebasePrivateKey) {
    console.warn(
      "Firebase Admin secrets not set. Credits in Supabase. " +
      "Firestore sync deferred to PaymentCallback page."
    );
    return json({
      received: true, processed: true,
      warning:  "Firebase Admin not configured — Firestore sync deferred",
    });
  }

  let accessToken: string;
  try {
    accessToken = await getFirebaseAccessToken(firebaseClientEmail, firebasePrivateKey);
  } catch (err) {
    console.error("Firebase token error:", err);
    await supabase.from("credit_topups")
      .update({ webhook_source: "webhook_firestore_pending" })
      .eq("paystack_ref", reference);
    return json({ received: true, processed: true, warning: "Firebase auth failed" });
  }

  // Try to get uid from metadata; if absent, query Firestore by email
  let finalUid = resolvedUid;
  if (!finalUid && email) {
    console.log(`No firebase_uid in metadata — looking up by email: ${email}`);
    finalUid = await lookupFirebaseUidByEmail(
      firebaseProjectId, email, accessToken,
    ) ?? undefined;
    if (finalUid) {
      // Back-fill into credit_topups so future lookups find it
      await supabase.from("credit_topups")
        .update({ firebase_uid: finalUid })
        .eq("paystack_ref", reference);
      console.log(`Email lookup resolved uid=${finalUid} for ref=${reference}`);
    }
  }

  if (!finalUid) {
    console.error(
      `Cannot credit: no firebase_uid for ref=${reference}, email=${email}. ` +
      "Flagged for manual review."
    );
    await supabase.from("credit_topups")
      .update({ webhook_source: "webhook_firestore_pending" })
      .eq("paystack_ref", reference);
    // Return 200 — Paystack must not retry; flag is set for admin review
    return json({
      received: true, processed: true,
      warning:  "No firebase_uid resolved — flagged for manual credit",
    });
  }

  // ── 12. Atomically increment Firestore credits ─────────────────────────────
  try {
    await incrementFirestoreCredits(firebaseProjectId, finalUid, creditsToAdd, accessToken);

    console.log(
      `✅ Webhook fulfilled: ref=${reference}, uid=${finalUid}, ` +
      `+${creditsToAdd} credits (${finalPackId}), ` +
      `₦${amountNgn} (${amountKobo} kobo) paid by ${email}`
    );

    return json({ received: true, processed: true, creditsAdded: creditsToAdd, reference });

  } catch (firestoreErr) {
    // DB already updated — credits are safe in Supabase.
    // Flag for sync on next callback page load. Return 200 to stop Paystack retries.
    console.error(`Firestore increment failed uid=${finalUid} ref=${reference}:`, firestoreErr);
    await supabase.from("credit_topups")
      .update({ webhook_source: "webhook_firestore_pending" })
      .eq("paystack_ref", reference);
    return json({
      received: true, processed: true,
      warning:  "Supabase updated; Firestore sync pending (will retry on callback page)",
    });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// Response helpers
// ─────────────────────────────────────────────────────────────────────────────
function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// HMAC-SHA512 signature verification
//
// Paystack signs every webhook payload with HMAC-SHA512 using your secret key.
// The signature is sent in the `x-paystack-signature` header as a hex string.
// We MUST verify this before trusting any data in the request.
// ─────────────────────────────────────────────────────────────────────────────
async function verifyPaystackSignature(
  rawBody: Uint8Array,
  incomingSignature: string,
  secretKey: string,
): Promise<boolean> {
  try {
    const encoder = new TextEncoder();

    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      encoder.encode(secretKey),
      { name: "HMAC", hash: "SHA-512" },
      false,
      ["sign"],
    );

    const signatureBuffer = await crypto.subtle.sign(
      "HMAC",
      cryptoKey,
      rawBody,
    );

    // Convert computed signature to lowercase hex string
    const computedHex = Array.from(new Uint8Array(signatureBuffer))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");

    // Constant-time comparison to prevent timing attacks
    if (computedHex.length !== incomingSignature.length) return false;

    let mismatch = 0;
    for (let i = 0; i < computedHex.length; i++) {
      mismatch |= computedHex.charCodeAt(i) ^ incomingSignature.charCodeAt(i);
    }
    return mismatch === 0;
  } catch (err) {
    console.error("Signature verification error:", err);
    return false;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Firebase Admin — Service Account JWT → OAuth2 Access Token
//
// Deno cannot import the Firebase Admin SDK directly.
// We create a signed JWT from the service account credentials,
// then exchange it for a short-lived Google OAuth2 access token.
// This token is used to call the Firestore REST API.
// ─────────────────────────────────────────────────────────────────────────────
async function getFirebaseAccessToken(
  clientEmail: string,
  privateKey: string,
): Promise<string> {
  const now = Math.floor(Date.now() / 1000);

  // Base64url encode without padding
  const b64url = (str: string): string =>
    btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");

  const headerB64  = b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const payloadB64 = b64url(JSON.stringify({
    iss:   clientEmail,
    sub:   clientEmail,
    scope: "https://www.googleapis.com/auth/datastore https://www.googleapis.com/auth/firebase",
    aud:   "https://oauth2.googleapis.com/token",
    iat:   now,
    exp:   now + 3600,
  }));

  const signingInput = `${headerB64}.${payloadB64}`;

  // Normalize the private key: handle both literal \n and actual newlines,
  // and strip PEM headers/footers.
  const normalizedKey = privateKey
    .replace(/\\n/g, "\n")
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s+/g, "");

  const binaryKey = Uint8Array.from(atob(normalizedKey), (c) => c.charCodeAt(0));

  const cryptoKey = await crypto.subtle.importKey(
    "pkcs8",
    binaryKey,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );

  const signatureBuffer = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    cryptoKey,
    new TextEncoder().encode(signingInput),
  );

  const signatureB64 = btoa(
    String.fromCharCode(...new Uint8Array(signatureBuffer)),
  ).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");

  const jwt = `${signingInput}.${signatureB64}`;

  // Exchange JWT for OAuth2 access token
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion:  jwt,
    }).toString(),
  });

  if (!tokenRes.ok) {
    const errText = await tokenRes.text();
    throw new Error(`Firebase token exchange failed: ${tokenRes.status} ${errText}`);
  }

  const tokenData = await tokenRes.json();
  if (!tokenData.access_token) {
    throw new Error(`No access_token in Firebase token response: ${JSON.stringify(tokenData)}`);
  }

  return tokenData.access_token as string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Firestore atomic increment via REST API
//
// Uses `documents:commit` with a fieldTransform / INCREMENT to atomically
// add credits to the user document — same behaviour as Firestore increment().
// ─────────────────────────────────────────────────────────────────────────────
async function incrementFirestoreCredits(
  projectId: string,
  uid: string,
  creditsToAdd: number,
  accessToken: string,
): Promise<void> {
  const docPath =
    `projects/${projectId}/databases/(default)/documents/users/${uid}`;

  const commitRes = await fetch(
    `https://firestore.googleapis.com/v1/${docPath.split("/").slice(0, 4).join("/")}/documents:commit`,
    {
      method: "POST",
      headers: {
        Authorization:  `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        writes: [
          {
            transform: {
              document:        docPath,
              fieldTransforms: [
                {
                  fieldPath: "credits",
                  increment: { integerValue: String(creditsToAdd) },
                },
              ],
            },
          },
        ],
      }),
    },
  );

  if (!commitRes.ok) {
    const errText = await commitRes.text();
    throw new Error(
      `Firestore commit failed: ${commitRes.status} ${errText}`,
    );
  }

  console.log(`Firestore credits incremented: uid=${uid}, added=${creditsToAdd}`);
}

