import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { runFirewall, SECURITY_HEADERS as corsHeaders } from "../_shared/firewall.ts";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

async function streamToStorage(
  sourceUrl: string,
  contentTypeHint?: string,
  bucketName = "generated-media"
): Promise<{ success: true; publicUrl: string } | { success: false; error: string }> {
  try {
    console.log(`[REPLICATE] Fetching asset from: ${sourceUrl}`);
    const response = await fetch(sourceUrl);
    if (!response.ok) throw new Error(`Fetch failed: ${response.status}`);

    const contentType = contentTypeHint || response.headers.get("content-type") || "application/octet-stream";
    const ext = contentType.includes("mp4") ? "mp4" : contentType.includes("png") ? "png" : contentType.includes("jpg") || contentType.includes("jpeg") ? "jpg" : "bin";
    const filePath = `uploads/${crypto.randomUUID()}.${ext}`;

    const { data, error } = await supabase.storage
      .from(bucketName)
      .upload(filePath, response.body!, { contentType, cacheControl: "no-cache", upsert: false });

    if (error) throw error;

    const { data: urlData } = supabase.storage.from(bucketName).getPublicUrl(filePath);
    console.log(`[REPLICATE] Storage upload successful: ${urlData.publicUrl}`);
    return { success: true, publicUrl: urlData.publicUrl };
  } catch (err) {
    console.error("[REPLICATE] Storage transfer error:", (err as Error).message);
    return { success: false, error: (err as Error).message };
  }
}

serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: "kling-omni-video-query", maxReqsPer60s: 30, allowedMethods: ["POST", "GET", "OPTIONS"] });
  if (blocked) return blocked;

  try {
    const { task_id } = await req.json();
    console.log(`[REPLICATE] Polling status for prediction_id: ${task_id}`);
    
    const apiKey = Deno.env.get("REPLICATE_API_TOKEN");
    if (!apiKey) {
      throw new Error("Missing REPLICATE_API_TOKEN in environment");
    }

    const response = await fetch(
      `https://api.replicate.com/v1/predictions/${encodeURIComponent(task_id)}`,
      {
        method: "GET",
        headers: {
          "Authorization": `Token ${apiKey}`,
        },
      }
    );

    const result = await response.json();
    console.log(`[REPLICATE] Query Status: ${response.status}, Data: ${JSON.stringify(result).substring(0, 800)}`);

    if (!response.ok) {
      const errorMsg = result.detail || result.error || JSON.stringify(result);
      throw new Error(`Replicate API error (${response.status}): ${errorMsg}`);
    }

    // Map Replicate status to our normalized status
    const statusMap: Record<string, string> = {
      "starting": "submitted",
      "processing": "processing",
      "succeeded": "succeed",
      "failed": "failed",
      "canceled": "failed",
    };
    
    const normalizedStatus = statusMap[result.status] || result.status || "submitted";
    console.log(`[REPLICATE] Normalized Status: ${normalizedStatus}`);

    // Build normalized response that matches frontend expectations
    const normalized: any = {
      code: 0,
      message: "success",
      data: {
        task_id: result.id || task_id,
        task_status: normalizedStatus,
        task_status_msg: result.error?.message || result.error || "",
      }
    };

    if (normalizedStatus === "succeed" && result.output) {
      const output = result.output;
      let videoUrl: string | null = null;

      if (typeof output === "string") {
        videoUrl = output;
      } else if (Array.isArray(output) && output.length > 0 && typeof output[0] === "string") {
        videoUrl = output[0];
      } else if (output.video) {
        videoUrl = typeof output.video === "string" ? output.video : output.video.url;
      }

      if (videoUrl) {
        console.log(`[REPLICATE] Output video URL found: ${videoUrl}`);
        const transfer = await streamToStorage(videoUrl, "video/mp4");
        if (transfer.success) {
          normalized.data.task_result = { videos: [{ url: transfer.publicUrl }] };
        } else {
          normalized.data.task_result = { videos: [{ url: videoUrl }] };
          console.warn("[REPLICATE] Storage transfer failed, using Replicate URL directly:", transfer.error);
        }
      } else {
        console.warn("[REPLICATE] Status is succeeded but no video URL found in output:", JSON.stringify(output));
        normalized.data.task_result = { videos: [] };
      }
    }

    return new Response(JSON.stringify(normalized), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("[REPLICATE] Query Error:", error.message);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
