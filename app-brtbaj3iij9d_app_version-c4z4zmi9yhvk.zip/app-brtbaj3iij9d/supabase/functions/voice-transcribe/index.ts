import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { runFirewall, SECURITY_HEADERS as corsHeaders } from "../_shared/firewall.ts";

serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: "voice-transcribe", maxReqsPer60s: 20, maxBodyBytes: 26214400 });
  if (blocked) return blocked;

  try {
    const openaiKey = Deno.env.get("OPENAI_API_KEY") ?? "";
    if (!openaiKey) throw new Error("OpenAI key not configured.");

    // Forward the multipart FormData directly to Whisper
    const formData = await req.formData();
    const audioFile = formData.get("file") as File | null;
    if (!audioFile) throw new Error("No audio file received.");

    const whisperForm = new FormData();
    whisperForm.append("file", audioFile, audioFile.name ?? "audio.webm");
    whisperForm.append("model", "whisper-1");
    whisperForm.append("language", "en");

    const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST",
      headers: { Authorization: `Bearer ${openaiKey}` },
      body: whisperForm,
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Whisper error ${res.status}: ${err}`);
    }

    const { text } = await res.json();
    return new Response(JSON.stringify({ text: text?.trim() ?? "" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("voice-transcribe error:", e);
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
