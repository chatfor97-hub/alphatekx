import { createClient } from "jsr:@supabase/supabase-js@2";
import { runFirewall, SECURITY_HEADERS as corsHeaders } from "../_shared/firewall.ts";

// Credit packs — Exchange rate: $1 USD = ₦1,373.42 (flat market rate)
// Kobo hardcoded as integers to avoid float rounding.
// Must stay in sync with initialize-paystack and paystack-webhook.
//
//  Tier 1  $1  →  ₦1,373.42  →      137,342 kobo  →    50 credits
//  Tier 2  $5  →  ₦6,867.10  →      686,710 kobo  →   300 credits
//  Tier 3  $10 →  ₦13,734.20 →    1,373,420 kobo  →   700 credits
//  Tier 4  $50 →  ₦68,671.00 →    6,867,100 kobo  → 3,500 credits
const CREDIT_PACKS: Record<string, { credits: number; amountNgn: number; amountKobo: number; usd: number }> = {
  starter: { credits:   50, usd:  1, amountNgn:  1_373.42, amountKobo:   137_342 },
  popular: { credits:  300, usd:  5, amountNgn:  6_867.10, amountKobo:   686_710 },
  pro:     { credits:  700, usd: 10, amountNgn: 13_734.20, amountKobo: 1_373_420 },
  elite:   { credits: 3500, usd: 50, amountNgn: 68_671.00, amountKobo: 6_867_100 },
};

function ok(data: unknown): Response {
  return new Response(JSON.stringify({ code: "SUCCESS", data }), {
    status: 200,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

function fail(msg: string, status = 400): Response {
  return new Response(JSON.stringify({ code: "FAIL", message: msg }), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

Deno.serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: "verify-paystack", maxReqsPer60s: 10 });
  if (blocked) return blocked;

  try {
    const { reference, packId, firebaseUid } = await req.json();

    if (!reference || !packId || !firebaseUid) {
      return fail("Missing required fields: reference, packId, firebaseUid");
    }

    const pack = CREDIT_PACKS[packId];
    if (!pack) return fail(`Unknown pack: ${packId}`);

    const paystackSecretKey = Deno.env.get("PAYSTACK_SECRET_KEY");
    if (!paystackSecretKey) {
      return fail("PAYSTACK_SECRET_KEY is not configured", 500);
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // ── Idempotency check — never credit the same reference twice ─────────
    const { data: existing } = await supabase
      .from("credit_topups")
      .select("id, credits_added, status, webhook_source")
      .eq("paystack_ref", reference)
      .maybeSingle();

    if (existing?.status === "verified") {
      // Already processed — return idempotent success.
      // Pass back webhook_source so the callback page knows if Firestore
      // was already credited (webhook did it) or still needs to be credited.
      console.log(`Reference ${reference} already processed (idempotent). source=${existing.webhook_source}`);
      return ok({
        creditsToAdd:  existing.credits_added,
        packId,
        reference,
        idempotent:    true,
        webhookSource: existing.webhook_source ?? "callback",
      });
    }

    // ── Verify transaction with Paystack API ──────────────────────────────
    const verifyRes = await fetch(
      `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
      { headers: { Authorization: `Bearer ${paystackSecretKey}` } }
    );

    if (!verifyRes.ok) {
      console.error("Paystack verify HTTP error:", verifyRes.status);
      return fail("Payment verification failed. Please try again.", 502);
    }

    const verifyData = await verifyRes.json();

    if (!verifyData.status || verifyData.data?.status !== "success") {
      return fail(`Payment not successful. Status: ${verifyData.data?.status ?? "unknown"}`);
    }

    // ── Validate amount paid (Paystack returns amount in kobo for NGN) ──────
    // Kobo rule: ₦1 = 100 kobo. Paystack always returns amount in smallest unit.
    const paidAmountKobo = verifyData.data.amount as number; // e.g. 137342 for Tier 1 ($1)
    const currency       = (verifyData.data.currency ?? "NGN").toUpperCase();
    const expectedKobo   = pack.amountKobo; // hardcoded exact integer, no float drift

    // Accept NGN kobo directly; also accept if Paystack returns a different
    // currency (e.g. USD cents) via metadata fallback but log a warning.
    let paidNgn: number;
    if (currency === "NGN") {
      paidNgn = paidAmountKobo / 100;
    } else {
      // Non-NGN — convert back using metadata or treat as-is (fallback)
      const metaNgn = verifyData.data.metadata?.ngn_amount;
      paidNgn = metaNgn ? Number(metaNgn) : paidAmountKobo / 100;
      console.warn(`Unexpected currency ${currency} on ref ${reference}. Falling back to metadata.`);
    }

    if (paidAmountKobo < expectedKobo) {
      return fail(
        `Amount mismatch: expected ₦${pack.amountNgn} (${expectedKobo} kobo), ` +
        `paid ₦${paidNgn} (${paidAmountKobo} kobo, ${currency})`
      );
    }

    // ── Persist to credit_topups (UNIQUE on paystack_ref guards race conditions)
    const { error: insertErr } = await supabase.from("credit_topups").upsert({
      firebase_uid:  firebaseUid,
      pack_id:       packId,
      credits_added: pack.credits,
      amount_usd:    pack.amountNgn,   // stored as NGN value in this column
      paystack_ref:  reference,
      status:        "verified",
      verified_at:   new Date().toISOString(),
    }, { onConflict: "paystack_ref", ignoreDuplicates: false });

    if (insertErr) {
      // Unique-constraint violation means another request already inserted — idempotent
      if (insertErr.code === "23505") {
        console.log(`Race condition resolved via DB unique constraint for ref ${reference}.`);
        return ok({ creditsToAdd: pack.credits, packId, reference, idempotent: true });
      }
      console.error("credit_topups insert error:", insertErr);
      return fail("Failed to record payment. Please contact support.", 500);
    }

    return ok({ creditsToAdd: pack.credits, packId, reference, webhookSource: "callback" });
  } catch (err) {
    console.error("verify-paystack error:", err);
    return fail(err instanceof Error ? err.message : "Unexpected error", 500);
  }
});
