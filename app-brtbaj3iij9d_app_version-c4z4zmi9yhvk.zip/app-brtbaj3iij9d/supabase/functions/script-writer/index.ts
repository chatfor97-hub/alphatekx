import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { runFirewall, SECURITY_HEADERS as corsHeaders, buildSecurityHeaders } from "../_shared/firewall.ts";

const XAI_URL     = "https://api.x.ai/v1/chat/completions";
const GATEWAY_URL =
  "https://app-brtbaj3iij9d-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

function buildSystemPrompt(
  topic: string,
  audience: string,
  tone: string,
  duration: string
): string {
  return `You are the AlphaTekx Elite Video Producer & Scriptwriter.

Your mission: Write a HIGH-RETENTION YouTube script for the AFRICAN tech, digital, and business creator ecosystem. This is NOT a generic AI script. It must feel like a real human creator who lives in Lagos, Accra, or Nairobi wrote it.

## USER PARAMETERS
- Topic: ${topic}
- Target Audience: ${audience}
- Video Tone/Style: ${tone}
- Estimated Video Duration: ${duration}

## CRITICAL WRITING RULES (NEVER VIOLATE)
1. NO CLICHÉ INTROS. Never say "Hey guys, welcome back to my channel," "In today's video," or "Make sure to like and subscribe." Start mid-action or mid-thought.
2. LOCAL & RELATABLE CONTEXT: Blend in local African realities where natural — internet costs, NEPA/power issues, local payment restrictions, Naira inflation, side hustles, forex income, data bundles, etc. Use vibrant urban-conversational language that matches the specified tone.
3. SPOKEN LANGUAGE OPTIMIZATION: Write exactly how people talk. Short punchy sentences. Natural contractions. Rhythm changes. If it sounds robotic when read aloud, rewrite it.
4. RETENTION-FIRST: Every section must make leaving the video feel like a mistake.

## OUTPUT FORMAT — FOLLOW EXACTLY

# 🎥 SYSTEM GENERATED SCRIPT DIRECTIVE

## 🚀 PART 1: THE COLD OPEN (0:00 - 0:30)
[High-tension, pattern-interrupt hook. Bold claim, frustrating local reality, or counter-intuitive statement. Make them STAY.]
- **Visual Directive:** [Dynamic on-screen movement, text overlays, or tight zoom cues]
- **Speaker Script:** "[Write the spoken script here — conversational, natural, punchy]"

## 🔒 PART 2: THE PROMISE LOCK & STAKES (0:30 - 1:00)
[State EXACTLY what viewers will learn. Escalate stakes — why ignoring this costs them money, time, or growth RIGHT NOW.]
- **Visual Directive:** [Supportive B-roll or graphical evidence]
- **Speaker Script:** "[Spoken script]"

## 💡 PART 3: THE CORE POINTS (Body Sections)
[Break core content into sections scaled to the duration. Each section must have a catchy sub-title, spoken script, and visual cues. Keep pace rapid.]

### Section 1: [Catchy Sub-title]
- **Visual Directive:** [Screen-recordings, stock video, or frame changes]
- **Speaker Script:** "[Spoken script]"

### Section 2: [Catchy Sub-title]
- **Visual Directive:** [Visual cues]
- **Speaker Script:** "[Spoken script]"

### Section 3: [Catchy Sub-title]
- **Visual Directive:** [Visual cues]
- **Speaker Script:** "[Spoken script]"

[Add more sections if the duration requires it — scale content to fill ${duration}]

## 🔄 PART 4: THE PATTERN BREAK & MID-ROLL REHOOK (~50% through)
[Sudden shift in tone. Warning about a costly mistake everyone makes, or a highly relatable anecdote. Reset attention and kill viewer fatigue.]
- **Visual Directive:** [Drastic visual change or music cut cue]
- **Speaker Script:** "[Spoken script]"

## 🎯 PART 5: THE ESCALATION & FINAL PAYOFF
[Most valuable, unexpected, or actionable insight. Build toward a climax — not a fade.]
- **Visual Directive:** [Intense visual emphasis or close-up camera angles]
- **Speaker Script:** "[Spoken script]"

## 🎬 PART 6: THE FINAL ACTIONABLE CTA & END-SCREEN HOOK
[Never say "That's all for today." Smoothly transition final point into a single high-value CTA. Pitch the next video on the channel to create a watch-loop.]
- **Visual Directive:** [End screen card overlay with recommended next video concept]
- **Speaker Script:** "[Spoken script]"

---

## 📊 BONUS: ALGORITHM METADATA PACKAGE

### 🎯 3 CTR-Optimized Title Options (max 60 characters each)
1. [Title Option 1 — curiosity gap, urgency, or number hook]
2. [Title Option 2 — pain-point driven, African context where fitting]
3. [Title Option 3 — bold claim or counter-intuitive angle]

### 🖼️ 2 Thumbnail Visual Concepts
**Concept A:**
- Background: [Describe background layout, colors, imagery]
- On-screen text overlay (max 4 words): "[TEXT]"

**Concept B:**
- Background: [Describe background layout, colors, imagery]
- On-screen text overlay (max 4 words): "[TEXT]"

### 📝 YouTube Description (150 words)
[Write a compelling description. Start with a hook sentence. Include what they'll learn. Add a placeholder for timestamps like [0:00 - Intro], [1:00 - Section 1], etc. End with a CTA. Keep it under 150 words.]

---

Now write the COMPLETE script for the given parameters. Be thorough, be real, be African. Every section must be fully fleshed out — no placeholders, no "[add content here]". If the duration is 10+ minutes, expand the core sections proportionally.`;
}

serve(async (req) => {
  const blocked = await runFirewall(req, { functionKey: "script-writer", maxReqsPer60s: 15, skipBodyScan: true });
  if (blocked) return blocked;

  try {
    const { topic, audience, tone, duration } = await req.json();

    if (!topic || !audience || !tone || !duration) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: topic, audience, tone, duration" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const xaiKey  = Deno.env.get("XAI_API_KEY")          ?? "";
    const medoKey = Deno.env.get("INTEGRATIONS_API_KEY")  ?? "";
    const systemPrompt = buildSystemPrompt(topic, audience, tone, duration);

    // ── Helper: wrap any OpenAI-compatible SSE stream as output ──────────────
    function wrapOpenAIStream(body: ReadableStream): ReadableStream {
      const reader  = body.getReader();
      const encoder = new TextEncoder();
      return new ReadableStream({
        async start(controller) {
          const decoder = new TextDecoder();
          let buf = "";
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buf += decoder.decode(value, { stream: true });
            const lines = buf.split("\n");
            buf = lines.pop() ?? "";
            for (const line of lines) {
              if (!line.startsWith("data: ")) continue;
              const js = line.slice(6).trim();
              if (!js || js === "[DONE]") continue;
              try {
                const text = JSON.parse(js).choices?.[0]?.delta?.content ?? "";
                if (text) {
                  const chunk = JSON.stringify({ choices: [{ delta: { content: text } }] });
                  controller.enqueue(encoder.encode(`data: ${chunk}\n\n`));
                }
              } catch { /* partial chunk */ }
            }
          }
          controller.enqueue(encoder.encode("data: [DONE]\n\n"));
          controller.close();
        },
      });
    }

    // ── Helper: wrap Gemini SSE as OpenAI-compatible output ──────────────────
    function wrapGeminiStream(body: ReadableStream): ReadableStream {
      const reader  = body.getReader();
      const encoder = new TextEncoder();
      return new ReadableStream({
        async start(controller) {
          const decoder = new TextDecoder();
          let buf = "";
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buf += decoder.decode(value, { stream: true });
            const lines = buf.split("\n");
            buf = lines.pop() ?? "";
            for (const line of lines) {
              if (!line.startsWith("data:")) continue;
              const dataStr = line.slice(5).trim();
              if (!dataStr || dataStr === "[DONE]") continue;
              try {
                const text = JSON.parse(dataStr)?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
                if (text) {
                  const chunk = JSON.stringify({ choices: [{ delta: { content: text } }] });
                  controller.enqueue(encoder.encode(`data: ${chunk}\n\n`));
                }
              } catch { /* incomplete frame */ }
            }
          }
          controller.enqueue(encoder.encode("data: [DONE]\n\n"));
          controller.close();
        },
      });
    }

    // ── Provider #1: xAI Grok-3 (131k context) ───────────────────────────────
    if (xaiKey) {
      const res = await fetch(XAI_URL, {
        method: "POST",
        headers: { "Authorization": `Bearer ${xaiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "grok-3",
          messages: [{ role: "user", content: systemPrompt }],
          stream: true,
          max_tokens: 16384,
        }),
        signal: AbortSignal.timeout(120_000),
      });
      if (res.ok && res.body) {
        console.log("script-writer: xAI Grok-3");
        return new Response(wrapOpenAIStream(res.body), {
          headers: { ...corsHeaders, "Content-Type": "text/event-stream", "Cache-Control": "no-cache" },
        });
      }
      console.error(`script-writer: xAI failed ${res.status}`);
    }

    // ── Provider #2: Medo / Gemini gateway ───────────────────────────────────
    if (!medoKey) {
      return new Response(
        JSON.stringify({ error: "No AI provider configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const upstream = await fetch(GATEWAY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${medoKey}` },
      body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: systemPrompt }] }] }),
      signal: AbortSignal.timeout(120_000),
    });

    if (upstream.status === 429 || upstream.status === 402) {
      return new Response(await upstream.text(), {
        status: upstream.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!upstream.ok || !upstream.body) {
      return new Response(
        JSON.stringify({ error: `Upstream error: ${upstream.status}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("script-writer: Medo/Gemini fallback");
    return new Response(wrapGeminiStream(upstream.body), {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream", "Cache-Control": "no-cache" },
    });

  } catch (error) {
    console.error("Script Writer Error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
