// resume-studio — AI-powered Resume & Cover Letter generator
// Multi-provider: xAI Grok-3 → Groq → OpenAI → Medo/Gemini gateway
// Accepts: experience (text), jobDescription (text), mode ('resume' | 'cover-letter' | 'both')
// Returns: { resume, coverLetter } — fully formatted Markdown strings

import { runFirewall, buildSecurityHeaders } from "../_shared/firewall.ts";

const XAI_URL    = "https://api.x.ai/v1/chat/completions";
const GROQ_URL   = "https://api.groq.com/openai/v1/chat/completions";
const OPENAI_URL = "https://api.openai.com/v1/chat/completions";
const MEDO_URL   =
  "https://app-brtbaj3iij9d-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse";

function ok(req: Request, data: unknown): Response {
  return new Response(JSON.stringify({ code: "SUCCESS", data }), {
    status: 200,
    headers: { ...buildSecurityHeaders(req), "Content-Type": "application/json" },
  });
}

function fail(req: Request, msg: string, status = 400): Response {
  return new Response(JSON.stringify({ code: "FAIL", message: msg }), {
    status,
    headers: { ...buildSecurityHeaders(req), "Content-Type": "application/json" },
  });
}

// ── OpenAI-compatible SSE → plain text ─────────────────────────────────────
async function collectOpenAIStream(stream: ReadableStream): Promise<string> {
  const reader  = stream.getReader();
  const decoder = new TextDecoder();
  let buf  = "";
  let full = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const js = line.slice(6).trim();
      if (!js || js === "[DONE]") continue;
      try { full += JSON.parse(js).choices?.[0]?.delta?.content ?? ""; } catch { /* skip */ }
    }
  }
  return full.trim();
}

// ── Provider: xAI Grok-3 (primary — 131k context) ─────────────────────────
async function tryXAI(prompt: string, system: string, key: string): Promise<string | null> {
  try {
    const res = await fetch(XAI_URL, {
      method: "POST",
      headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "grok-3",
        messages: [{ role: "system", content: system }, { role: "user", content: prompt }],
        stream: true, max_tokens: 16384,
      }),
      signal: AbortSignal.timeout(120_000),
    });
    if (!res.ok) { console.error(`xAI ${res.status} ${await res.text()}`); return null; }
    return await collectOpenAIStream(res.body!);
  } catch (e) { console.error("xAI exception:", e); return null; }
}

// ── Provider: Groq ─────────────────────────────────────────────────────────
async function tryGroq(prompt: string, system: string, key: string): Promise<string | null> {
  try {
    const res = await fetch(GROQ_URL, {
      method: "POST",
      headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: [{ role: "system", content: system }, { role: "user", content: prompt }],
        stream: true, max_tokens: 4096,
      }),
      signal: AbortSignal.timeout(60_000),
    });
    if (!res.ok) { console.error(`Groq ${res.status}`); return null; }
    return await collectOpenAIStream(res.body!);
  } catch (e) { console.error("Groq exception:", e); return null; }
}

// ── Provider: OpenAI ───────────────────────────────────────────────────────
async function tryOpenAI(prompt: string, system: string, key: string): Promise<string | null> {
  try {
    const res = await fetch(OPENAI_URL, {
      method: "POST",
      headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "system", content: system }, { role: "user", content: prompt }],
        stream: true, max_tokens: 4096,
      }),
      signal: AbortSignal.timeout(60_000),
    });
    if (!res.ok) { console.error(`OpenAI ${res.status}`); return null; }
    return await collectOpenAIStream(res.body!);
  } catch (e) { console.error("OpenAI exception:", e); return null; }
}

// ── Provider: Medo / Gemini gateway ───────────────────────────────────────
async function tryMedo(prompt: string, system: string, key: string): Promise<string | null> {
  try {
    const res = await fetch(MEDO_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Gateway-Authorization": `Bearer ${key}` },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 4096 },
      }),
      signal: AbortSignal.timeout(90_000),
    });
    if (!res.ok) { console.error(`Medo ${res.status} ${await res.text()}`); return null; }
    const reader  = res.body!.getReader();
    const decoder = new TextDecoder();
    let buf  = "";
    let full = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const d = line.slice(6).trim();
        if (!d || d === "[DONE]") continue;
        try { full += JSON.parse(d)?.candidates?.[0]?.content?.parts?.[0]?.text ?? ""; } catch { /* skip */ }
      }
    }
    return full.trim() || null;
  } catch (e) { console.error("Medo exception:", e); return null; }
}

// ── Multi-provider generate ────────────────────────────────────────────────
async function generate(
  prompt: string,
  system: string,
  xaiKey: string,
  groqKey: string,
  openaiKey: string,
  medoKey: string,
): Promise<string> {
  let text: string | null = null;
  let provider = "";

  if (!text && xaiKey)    { text = await tryXAI(prompt, system, xaiKey);       if (text) provider = "xai-grok-3"; }
  if (!text && groqKey)   { text = await tryGroq(prompt, system, groqKey);     if (text) provider = "groq"; }
  if (!text && openaiKey) { text = await tryOpenAI(prompt, system, openaiKey); if (text) provider = "openai"; }
  if (!text && medoKey)   { text = await tryMedo(prompt, system, medoKey);     if (text) provider = "medo"; }

  if (!text) throw new Error("All AI providers unavailable — please try again in a moment.");
  console.log(`resume-studio: used ${provider}, ${text.length} chars`);
  return text;
}

// ── System prompts ─────────────────────────────────────────────────────────
const RESUME_SYSTEM = `You are an elite professional resume writer with 15 years of experience helping candidates land roles at top-tier companies. You write ATS-optimized, results-driven resumes that get callbacks.

FORMAT RULES (follow exactly):
- Use markdown with ## for section headings
- Use bullet points starting with strong action verbs (Engineered, Delivered, Scaled, Led, Built, Drove, Generated)
- Quantify every achievement where possible (%, $, numbers, time saved)
- Keep bullet points to 1-2 lines max
- NO generic filler phrases ("responsible for", "helped with", "worked on")
- Structure: ## Summary, ## Core Skills, ## Professional Experience, ## Education, ## Notable Achievements

QUALITY BAR: Every bullet must answer "so what?" — show impact, not just activity.`;

const COVER_LETTER_SYSTEM = `You are a world-class cover letter writer who crafts letters that hiring managers actually read and remember. Your letters are concise, confident, and hook the reader in the first sentence.

FORMAT RULES (follow exactly):
- Use markdown with ## headings
- 3 tight paragraphs: Opening Hook, Relevant Value, Closing CTA
- First sentence must be bold and memorable — NOT "I am writing to apply for..."
- Personalize to the specific role and company using the job description
- Keep to ~250-300 words max — hiring managers skim
- End with a confident, specific call-to-action

QUALITY BAR: The letter must feel like it was written by someone who already gets the job done, not someone begging for a chance.`;

// ── Main handler ───────────────────────────────────────────────────────────
Deno.serve(async (req) => {
  // skipBodyScan: Resume/job description text naturally contains SQL keywords ("create", "replace", etc.)
  // Rate limiting + UA blocking still apply; the LLM handles input safely server-side.
  const blocked = await runFirewall(req, { functionKey: "resume-studio", maxReqsPer60s: 15, skipBodyScan: true });
  if (blocked) return blocked;
  if (req.method !== "POST") return fail(req, "Method not allowed", 405);

  try {
    const { experience, jobDescription, mode = "both", name = "" } = await req.json() as {
      experience: string;
      jobDescription: string;
      mode?: "resume" | "cover-letter" | "both";
      name?: string;
    };

    if (!experience?.trim())     return fail(req, "experience is required");
    if (!jobDescription?.trim()) return fail(req, "jobDescription is required");

    const xaiKey    = Deno.env.get("XAI_API_KEY")           ?? "";
    const groqKey   = Deno.env.get("GROQ_API_KEY")          ?? "";
    const openaiKey = Deno.env.get("OPENAI_API_KEY")        ?? "";
    const medoKey   = Deno.env.get("INTEGRATIONS_API_KEY")  ?? "";

    const nameTag  = name ? `Candidate name: ${name}\n` : "";
    const userBlob = `${nameTag}---CANDIDATE BACKGROUND---\n${experience.trim()}\n\n---TARGET JOB DESCRIPTION---\n${jobDescription.trim()}`;

    let resume      = "";
    let coverLetter = "";

    if (mode === "resume" || mode === "both") {
      console.log("Generating resume…");
      resume = await generate(
        `Generate a professional, ATS-optimized resume for this candidate applying to this role:\n\n${userBlob}`,
        RESUME_SYSTEM,
        xaiKey, groqKey, openaiKey, medoKey,
      );
    }

    if (mode === "cover-letter" || mode === "both") {
      console.log("Generating cover letter…");
      coverLetter = await generate(
        `Write a compelling, personalized cover letter for this candidate applying to this role:\n\n${userBlob}`,
        COVER_LETTER_SYSTEM,
        xaiKey, groqKey, openaiKey, medoKey,
      );
    }

    if (!resume && !coverLetter) {
      return fail(req, "AI returned no content. Please try again.", 502);
    }

    console.log(`resume-studio done: mode=${mode}, resume=${resume.length}chars, letter=${coverLetter.length}chars`);
    return ok(req, { resume, coverLetter });

  } catch (err) {
    console.error("resume-studio error:", err);
    return fail(req, err instanceof Error ? err.message : "Unexpected server error", 500);
  }
});

