import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Hammer, Send, CheckCircle, Loader2, Zap, MessageSquare, Lightbulb, Users } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { useUserSession } from '@/contexts/UserSessionContext';
import PageMeta from '@/components/common/PageMeta';

const WHY_CARDS = [
  {
    icon: Zap,
    title: 'Have a killer idea?',
    body: 'We want to hear it. Share your vision and let\'s talk about building it together on AlphaTekx.',
  },
  {
    icon: Lightbulb,
    title: 'Found a bug or gap?',
    body: 'Your feedback directly shapes what we build next. Tell us what\'s broken or what\'s missing.',
  },
  {
    icon: MessageSquare,
    title: 'Want to collaborate?',
    body: 'Developers, creators, businesses — if you see a partnership opportunity, reach out.',
  },
];

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export default function BuildWithUs() {
  const { appUser } = useUserSession();
  const navigate = useNavigate();

  const [name, setName]       = useState(appUser?.display_name ?? '');
  const [email, setEmail]     = useState(appUser?.email ?? '');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent]       = useState(false);

  const emailError = email && !isValidEmail(email);
  const canSubmit  = name.trim() && email.trim() && isValidEmail(email) && message.trim() && !sending;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;

    setSending(true);
    try {
      const { error } = await supabase.functions.invoke('send-contact-email', {
        body: {
          name:    name.trim(),
          email:   email.trim(),
          message: message.trim(),
        },
      });

      if (error) {
        const errMsg = await error?.context?.text?.();
        throw new Error(errMsg || error.message || 'Submission failed');
      }

      setSent(true);
      setMessage('');
      toast.success('Message sent! We\'ll get back to you soon.');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Something went wrong. Please try again.';
      toast.error(msg);
    } finally {
      setSending(false);
    }
  }

  function resetForm() {
    setSent(false);
  }

  return (
    <div className="h-full overflow-y-auto">
      <PageMeta title="Build With Us — AlphaTekx AI" description="Partner with AlphaTekx. Share your ideas, report issues, or collaborate with the team building the next-generation AI Operating System." />
      <div className="max-w-2xl mx-auto px-4 py-8 md:py-12">

        {/* Header */}
        <div className="flex items-center gap-3 mb-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 border border-primary/20 shrink-0">
            <Hammer className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight text-balance leading-tight">
              Build With Us
            </h1>
            <p className="text-xs text-muted-foreground">AlphaTekx — Let's create together</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground text-pretty leading-relaxed mb-8 mt-3">
          Have an idea, feedback, or want to collaborate? Drop us a message and the AlphaTekx team
          will get back to you.
        </p>

        {/* Why cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-8">
          {WHY_CARDS.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.title}
                className="rounded-xl border border-border/60 bg-card p-4 space-y-2"
              >
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 border border-primary/15">
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <p className="text-xs font-semibold text-foreground/90 text-balance leading-snug">
                  {card.title}
                </p>
                <p className="text-[11px] text-muted-foreground text-pretty leading-relaxed">
                  {card.body}
                </p>
              </div>
            );
          })}
        </div>

        {/* Success state */}
        {sent ? (
          <div className="rounded-2xl border border-primary/25 bg-primary/5 px-6 py-10 flex flex-col items-center gap-5 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 border border-primary/20">
              <CheckCircle className="h-7 w-7 text-primary" />
            </div>
            <div className="space-y-1.5 max-w-xs">
              <h2 className="text-base font-black text-balance">Message Sent!</h2>
              <p className="text-sm text-muted-foreground text-pretty leading-relaxed">
                Thank you for reaching out! We'll get back to you soon at{' '}
                <span className="text-primary font-medium">{email}</span>.
              </p>
            </div>

            {/* Team HQ CTA */}
            <div className="w-full max-w-sm rounded-xl border border-primary/30 bg-primary/8 p-4 space-y-3">
              <p className="text-xs font-black uppercase tracking-widest text-primary/70">While you wait…</p>
              <p className="text-sm text-foreground/80 text-pretty leading-relaxed">
                Join the <strong className="text-primary">Team HQ</strong> — our private command center for ideas, planning, and real-time team collaboration.
              </p>
              <Button
                onClick={() => navigate('/members-lounge')}
                className="w-full h-10 font-bold text-sm gap-2 shadow-[0_0_16px_hsl(var(--primary)/0.3)]"
              >
                <Users className="h-4 w-4" />
                Enter Team HQ
              </Button>
            </div>

            <button
              onClick={resetForm}
              className="text-xs text-muted-foreground/50 hover:text-muted-foreground font-medium underline underline-offset-2 transition-colors"
            >
              Send another message
            </button>
          </div>
        ) : (
          /* Contact form */
          <form
            onSubmit={handleSubmit}
            className="rounded-2xl border border-border/60 bg-card p-5 md:p-6 space-y-5"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Name */}
              <div className="space-y-1.5">
                <Label htmlFor="bwu-name" className="text-xs font-medium text-muted-foreground">
                  Your Name <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="bwu-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Chidi Okonkwo"
                  required
                  className="h-10 text-sm bg-background border-border/70 focus:border-primary/50"
                />
              </div>

              {/* Email */}
              <div className="space-y-1.5">
                <Label htmlFor="bwu-email" className="text-xs font-medium text-muted-foreground">
                  Email Address <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="bwu-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className={`h-10 text-sm bg-background border-border/70 focus:border-primary/50 ${
                    emailError ? 'border-destructive focus:border-destructive' : ''
                  }`}
                />
                {emailError && (
                  <p className="text-[11px] text-destructive">Please enter a valid email address.</p>
                )}
              </div>
            </div>

            {/* Message */}
            <div className="space-y-1.5">
              <Label htmlFor="bwu-message" className="text-xs font-medium text-muted-foreground">
                Your Message <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="bwu-message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tell us your idea, feedback, or what you'd like to build with us…"
                required
                rows={5}
                className="text-sm bg-background border-border/70 focus:border-primary/50 resize-none"
              />
              <p className="text-[11px] text-muted-foreground/60 text-right">
                {message.length} / 2000 characters
              </p>
            </div>

            <Button
              type="submit"
              disabled={!canSubmit}
              className="w-full h-10 font-semibold text-sm gap-2"
            >
              {sending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Sending…
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  Send Message
                </>
              )}
            </Button>

            <p className="text-[11px] text-muted-foreground/50 text-center leading-relaxed">
              Messages are sent directly to the AlphaTekx team at{' '}
              <span className="text-muted-foreground/70">alphatekxcompany@gmail.com</span>
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
