import PageMeta from '@/components/common/PageMeta';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function Terms() {
  return (
    <>
      <PageMeta
        title="Terms of Service — AlphaTekx AI"
        description="Read the AlphaTekx AI Terms of Service. Understand your rights and responsibilities when using our AI Operating System platform."
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://alphatekx.name.ng/" },
            { "@type": "ListItem", "position": 2, "name": "Terms of Service", "item": "https://alphatekx.name.ng/terms" },
          ],
        }) }}
      />
      <div className="mx-auto max-w-3xl px-4 py-8 md:py-12">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>

        <Card className="glass border border-white/10">
          <CardHeader>
            <CardTitle className="text-xl font-bold tracking-tight">Terms of Service</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-sm leading-relaxed text-muted-foreground">
            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">1. Acceptance of Terms</h2>
              <p>
                By accessing or using AlphaTekx ("the Platform"), you agree to be bound by these Terms of Service.
                If you do not agree, do not use the Platform. We reserve the right to update these terms at any time.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">2. Eligibility</h2>
              <p>
                You must be at least 18 years old and capable of forming a binding contract to use AlphaTekx.
                You are responsible for maintaining the confidentiality of your account credentials.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">3. Acceptable Use</h2>
              <p>
                You agree not to misuse the Platform, including but not limited to: attempting to gain unauthorized access,
                interfering with service availability, uploading malicious code, or violating applicable laws.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">4. Intellectual Property</h2>
              <p>
                All content, software, and materials provided on AlphaTekx are owned by or licensed to us.
                You may not reproduce, distribute, or create derivative works without express permission.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">5. Termination</h2>
              <p>
                We may suspend or terminate your access at any time for violations of these terms or for operational reasons.
                You may also delete your account at any time.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">6. Disclaimer</h2>
              <p>
                AlphaTekx is provided "as is" without warranties of any kind. We do not guarantee uninterrupted
                or error-free service. Use the Platform at your own risk.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">7. Contact</h2>
              <p>
                For questions regarding these terms, contact us at legal@alphatekx.com.
              </p>
            </section>

            <p className="text-xs text-muted-foreground pt-4 border-t border-white/10">
              Last updated: May 20, 2026. Please modify these Terms to suit your legal requirements.
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
