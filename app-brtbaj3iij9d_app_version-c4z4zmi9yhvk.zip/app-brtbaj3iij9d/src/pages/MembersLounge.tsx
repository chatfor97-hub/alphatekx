import { useEffect, useRef, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/db/supabase';
import { useUserSession } from '@/contexts/UserSessionContext';
import { useLoungePresence } from '@/hooks/use-lounge-presence';
import { toast } from 'sonner';
import {
  Users, Send, X, Shield, CornerDownLeft, Loader2,
  Pin, Zap, BookOpen, MessageSquare, CheckSquare, Square,
  ChevronRight, Trash2, TrendingUp, Save, Clock, ArrowRightLeft,
  CheckCircle2, Search, AlertCircle,
} from 'lucide-react';
import AnnouncementBanner from '@/components/common/AnnouncementBanner';
import { getUserByEmail, transferCredits, addFirestoreCredits, type AppUser } from '@/lib/firestore';
import { formatCredits } from '@/lib/credits';

// ── Types ─────────────────────────────────────────────────────────────────────
interface LoungeMessage {
  id:              string;
  firebase_uid:    string;
  display_name:    string;
  avatar_url:      string | null;
  message_text:    string;
  youtube_video_id: string | null;
  reply_to_id:     string | null;
  reply_to_name:   string | null;
  reply_to_text:   string | null;
  created_at:      string;
}

interface StrategyPin {
  id:            string;
  message_text:  string;
  pinned_by:     string;
  pinned_by_name: string;
  pinned_at:     string;
}

interface ActionTask {
  title:       string;
  description: string;
  owner:       string;
  done:        boolean;
}

interface ActionPlan {
  id:         string;
  message_id: string;
  tasks:      ActionTask[];
  created_at: string;
}

interface VideoComment {
  id:               string;
  video_id:         string;
  timestamp_seconds: number;
  comment_text:     string;
  author_uid:       string;
  author_name:      string;
  created_at:       string;
}

// ── Constants ─────────────────────────────────────────────────────────────────
const ACCESS_CODE = '126213alphatekx-777-jesus-is-in-it';
const SESSION_KEY  = 'teamHQUnlocked';
const REPLY_MAX    = 55;
const TYPING_CHANNEL = 'team-hq-typing';

// ── Helpers ───────────────────────────────────────────────────────────────────
function extractYouTubeId(text: string): string | null {
  const patterns = [
    /(?:https?:\/\/)?(?:www\.)?youtube\.com\/watch\?v=([A-Za-z0-9_-]{11})/,
    /(?:https?:\/\/)?youtu\.be\/([A-Za-z0-9_-]{11})/,
    /(?:https?:\/\/)?(?:www\.)?youtube\.com\/embed\/([A-Za-z0-9_-]{11})/,
    /(?:https?:\/\/)?(?:www\.)?youtube\.com\/live\/([A-Za-z0-9_-]{11})/,
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m) return m[1];
  }
  return null;
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatSeconds(s: number) {
  const m = Math.floor(s / 60), sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, '0')}`;
}

function initials(name: string) {
  return name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
}

// ── Avatar ────────────────────────────────────────────────────────────────────
function MemberAvatar({ url, name, size = 8 }: { url?: string | null; name: string; size?: number }) {
  const cls = `rounded-full shrink-0 flex items-center justify-center text-[11px] font-bold select-none border border-white/10`;
  const dim = `h-${size} w-${size}`;
  if (url) return <img src={url} alt={name} className={`${dim} ${cls} object-cover`} />;
  return (
    <div className={`${dim} ${cls} bg-primary/20 border-primary/30 text-primary`}>
      {initials(name)}
    </div>
  );
}

// ── Credits Exhausted Gate ────────────────────────────────────────────────────
function NoCreditsGate() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col items-center justify-center h-full px-6 py-12 gap-6 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-yellow-500/10 border border-yellow-500/30">
        <Zap className="h-8 w-8 text-yellow-400" />
      </div>
      <div className="space-y-2 max-w-xs">
        <h2 className="text-lg font-black text-balance">Credits Required</h2>
        <p className="text-sm text-muted-foreground text-pretty">
          You need credits to access the Team Command Center. Top up your balance to enter the HQ.
        </p>
      </div>
      <button
        onClick={() => navigate('/dashboard')}
        className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:bg-primary/90 transition-all"
      >
        Top Up Credits
      </button>
    </div>
  );
}

// ── Access Code Gate ──────────────────────────────────────────────────────────
function AccessGate({ onUnlock }: { onUnlock: () => void }) {
  const [code, setCode]   = useState('');
  const [error, setError] = useState('');

  function attempt() {
    if (code === ACCESS_CODE) {
      sessionStorage.setItem(SESSION_KEY, 'true');
      onUnlock();
    } else {
      setError('Invalid access code. Please try again.');
      setCode('');
    }
  }

  return (
    <div className="flex flex-col items-center justify-center h-full px-6 py-12 gap-6">
      {/* Glowing icon */}
      <div className="relative">
        <div className="absolute inset-0 rounded-2xl bg-primary/20 blur-xl" />
        <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 border border-primary/40">
          <Shield className="h-8 w-8 text-primary" />
        </div>
      </div>
      <div className="text-center space-y-2 max-w-xs">
        <h2 className="text-xl font-black text-balance gradient-text">Team Command Center</h2>
        <p className="text-sm text-muted-foreground text-pretty">
          Private planning hub. Enter your access code to join the mission.
        </p>
      </div>
      <div className="w-full max-w-xs space-y-3">
        <input
          type="password"
          value={code}
          onChange={e => { setCode(e.target.value); setError(''); }}
          onKeyDown={e => e.key === 'Enter' && attempt()}
          placeholder="Enter access code"
          className="w-full rounded-xl bg-secondary/50 border border-white/10 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/30 transition-all"
        />
        {error && <p className="text-xs text-destructive font-medium">{error}</p>}
        <button
          onClick={attempt}
          disabled={!code.trim()}
          className="w-full py-3 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:bg-primary/90 transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_0_20px_hsl(var(--primary)/0.3)]"
        >
          Enter HQ
        </button>
      </div>
    </div>
  );
}

// ── Team Pulse Bar ────────────────────────────────────────────────────────────
function TeamPulseBar() {
  const [progress,  setProgress]  = useState(0);
  const [editing,   setEditing]   = useState(false);
  const [draft,     setDraft]     = useState('');
  const [saving,    setSaving]    = useState(false);

  useEffect(() => {
    supabase.from('lounge_milestone').select('progress_percentage').eq('id', 1).maybeSingle()
      .then(({ data }) => { if (data) setProgress(Number(data.progress_percentage)); });

    const ch = supabase.channel('milestone-changes')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'lounge_milestone', filter: 'id=eq.1' },
        (p) => { setProgress(Number((p.new as { progress_percentage: number }).progress_percentage)); })
      .subscribe();
    return () => { ch.unsubscribe(); };
  }, []);

  async function save() {
    const val = Math.min(100, Math.max(0, Number(draft)));
    if (isNaN(val)) return;
    setSaving(true);
    await supabase.from('lounge_milestone').update({ progress_percentage: val, updated_at: new Date().toISOString() }).eq('id', 1);
    setSaving(false);
    setEditing(false);
  }

  return (
    <div className="shrink-0 px-4 py-3 border-b border-white/10 bg-black/20">
      <div className="flex items-center gap-3">
        <TrendingUp className="h-4 w-4 text-primary shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Team Pulse</span>
            {editing ? (
              <div className="flex items-center gap-1.5">
                <input
                  type="number" min={0} max={100}
                  value={draft}
                  onChange={e => setDraft(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && save()}
                  className="w-14 text-center rounded-md bg-secondary/60 border border-white/10 px-2 py-0.5 text-xs focus:outline-none focus:border-primary/40"
                />
                <button onClick={save} disabled={saving} className="flex items-center gap-0.5 text-[11px] text-primary font-semibold hover:opacity-80 transition-opacity">
                  {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
                  Save
                </button>
                <button onClick={() => setEditing(false)} className="text-muted-foreground/50 hover:text-foreground transition-colors">
                  <X className="h-3 w-3" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => { setDraft(String(progress)); setEditing(true); }}
                className="text-[11px] font-bold text-primary hover:opacity-80 transition-opacity"
              >
                {progress}% toward milestone
              </button>
            )}
          </div>
          <div className="h-2 w-full rounded-full bg-secondary/50 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-700 ease-out"
              style={{
                width:      `${progress}%`,
                background: `linear-gradient(90deg, hsl(var(--primary)) 0%, hsl(var(--primary)/0.7) 100%)`,
                boxShadow:  `0 0 8px hsl(var(--primary)/0.4)`,
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── YouTube Inline Embed with Timestamped Comments ────────────────────────────
function InlineYouTubePlayer({ videoId, authorName, authorUid }: { videoId: string; authorName: string; authorUid: string }) {
  const playerRef    = useRef<HTMLIFrameElement>(null);
  const [comments,   setComments]   = useState<VideoComment[]>([]);
  const [commentText, setCommentText] = useState('');
  const [currentTs,   setCurrentTs]   = useState(0);
  const [submitting,  setSubmitting]  = useState(false);
  const [showComments, setShowComments] = useState(false);

  // Load comments
  useEffect(() => {
    supabase.from('lounge_video_comments')
      .select('*').eq('video_id', videoId).order('timestamp_seconds', { ascending: true }).limit(50)
      .then(({ data }) => { if (data) setComments(data as VideoComment[]); });

    const ch = supabase.channel(`video-comments-${videoId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'lounge_video_comments' },
        (p) => {
          const c = p.new as VideoComment;
          if (c.video_id === videoId) setComments(prev => [...prev, c].sort((a, b) => a.timestamp_seconds - b.timestamp_seconds));
        })
      .subscribe();
    return () => { ch.unsubscribe(); };
  }, [videoId]);

  // Poll current timestamp from iframe via postMessage
  useEffect(() => {
    const handler = (e: MessageEvent) => {
      if (e.data?.event === 'onStateChange' || e.data?.info?.currentTime !== undefined) {
        const t = e.data?.info?.currentTime;
        if (typeof t === 'number') setCurrentTs(t);
      }
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, []);

  async function submitComment() {
    if (!commentText.trim() || submitting) return;
    setSubmitting(true);
    await supabase.from('lounge_video_comments').insert({
      video_id: videoId, timestamp_seconds: currentTs,
      comment_text: commentText.trim(), author_uid: authorUid, author_name: authorName,
    });
    setSubmitting(false);
    setCommentText('');
  }

  function seekTo(seconds: number) {
    playerRef.current?.contentWindow?.postMessage(
      JSON.stringify({ event: 'command', func: 'seekTo', args: [seconds, true] }),
      '*'
    );
  }

  return (
    <div className="mt-2 rounded-xl overflow-hidden border border-white/10 bg-black/40">
      {/* Video */}
      <div className="relative w-full" style={{ paddingBottom: '56.25%' }}>
        <iframe
          ref={playerRef}
          className="absolute inset-0 w-full h-full"
          src={`https://www.youtube.com/embed/${videoId}?enablejsapi=1&rel=0&origin=${encodeURIComponent(window.location.origin)}`}
          title="Video"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
      {/* Comment toggle */}
      <button
        onClick={() => setShowComments(s => !s)}
        className="w-full flex items-center justify-between px-3 py-2 text-xs text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors"
      >
        <span className="flex items-center gap-1.5">
          <MessageSquare className="h-3 w-3" /> {comments.length} timestamped comment{comments.length !== 1 ? 's' : ''}
        </span>
        <ChevronRight className={`h-3 w-3 transition-transform ${showComments ? 'rotate-90' : ''}`} />
      </button>
      {showComments && (
        <div className="px-3 pb-3 space-y-2">
          {/* Add comment */}
          <div className="flex gap-2 items-center">
            <span className="text-[10px] text-primary font-mono shrink-0">{formatSeconds(currentTs)}</span>
            <input
              value={commentText}
              onChange={e => setCommentText(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && submitComment()}
              placeholder="Comment at this timestamp…"
              className="flex-1 min-w-0 rounded-lg bg-secondary/40 border border-white/10 px-3 py-1.5 text-xs text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/40 transition-all"
            />
            <button onClick={submitComment} disabled={!commentText.trim() || submitting}
              className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 border border-primary/25 hover:bg-primary/20 transition-all disabled:opacity-40 shrink-0">
              {submitting ? <Loader2 className="h-3 w-3 animate-spin text-primary" /> : <Send className="h-3 w-3 text-primary" />}
            </button>
          </div>
          {/* Comment list */}
          {comments.length === 0 && (
            <p className="text-[11px] text-muted-foreground/40 text-center py-2">No comments yet. Add the first one!</p>
          )}
          {comments.map(c => (
            <button key={c.id} onClick={() => seekTo(c.timestamp_seconds)}
              className="w-full text-left flex items-start gap-2 group px-2 py-1.5 rounded-lg hover:bg-white/5 transition-colors"
            >
              <span className="text-[10px] font-mono text-primary/80 shrink-0 mt-0.5 group-hover:text-primary transition-colors">
                <Clock className="h-2.5 w-2.5 inline mr-0.5" />{formatSeconds(c.timestamp_seconds)}
              </span>
              <div className="min-w-0">
                <span className="text-[10px] font-semibold text-muted-foreground">{c.author_name}: </span>
                <span className="text-[11px] text-foreground/80">{c.comment_text}</span>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Action Plan Card ──────────────────────────────────────────────────────────
function ActionPlanCard({ plan, messageId }: { plan: ActionPlan; messageId: string }) {
  const [tasks, setTasks] = useState<ActionTask[]>(plan.tasks);
  const [saving, setSaving] = useState(false);

  async function updateTask(index: number, patch: Partial<ActionTask>) {
    const updated = tasks.map((t, i) => i === index ? { ...t, ...patch } : t);
    setTasks(updated);
    setSaving(true);
    await supabase.from('lounge_action_plans').update({ tasks: updated }).eq('id', plan.id);
    setSaving(false);
  }

  // Real-time updates from others
  useEffect(() => {
    const ch = supabase.channel(`action-plan-${plan.id}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'lounge_action_plans' },
        (p) => {
          const updated = p.new as ActionPlan;
          if (updated.id === plan.id) setTasks(updated.tasks);
        })
      .subscribe();
    return () => { ch.unsubscribe(); };
  }, [plan.id, messageId]);

  return (
    <div className="mt-2 rounded-xl border border-primary/25 bg-primary/5 overflow-hidden">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-primary/15">
        <Zap className="h-3.5 w-3.5 text-primary shrink-0" />
        <span className="text-xs font-bold text-primary">AI Action Plan</span>
        {saving && <Loader2 className="h-3 w-3 animate-spin text-primary/60 ml-auto" />}
      </div>
      <div className="p-3 space-y-2.5">
        {tasks.map((task, i) => (
          <div key={i} className="flex items-start gap-2.5">
            <button onClick={() => updateTask(i, { done: !task.done })} className="mt-0.5 shrink-0 text-primary hover:opacity-80 transition-opacity">
              {task.done
                ? <CheckSquare className="h-4 w-4 text-green-400" />
                : <Square className="h-4 w-4 text-muted-foreground" />
              }
            </button>
            <div className="flex-1 min-w-0">
              <p className={`text-xs font-semibold ${task.done ? 'line-through text-muted-foreground/50' : 'text-foreground'}`}>
                Step {i + 1}: {task.title}
              </p>
              <p className="text-[11px] text-muted-foreground mt-0.5">{task.description}</p>
              <div className="flex items-center gap-1.5 mt-1.5">
                <span className="text-[10px] text-muted-foreground/60">Owner:</span>
                <input
                  value={task.owner}
                  onChange={e => updateTask(i, { owner: e.target.value })}
                  placeholder="Assign…"
                  className="flex-1 min-w-0 rounded bg-secondary/40 border border-white/8 px-2 py-0.5 text-[11px] text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:border-primary/30 transition-all"
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Message Bubble ────────────────────────────────────────────────────────────
const SWIPE_THRESHOLD = 60;
const SWIPE_MAX_TRANSLATE = 80;

function MessageBubble({
  msg, isOwn, isAdmin, onReply, onPin, onConvert, onDelete, convertingId, actionPlan, authorName, authorUid,
}: {
  msg:          LoungeMessage;
  isOwn:        boolean;
  isAdmin:      boolean;
  onReply:      (m: LoungeMessage) => void;
  onPin:        (m: LoungeMessage) => void;
  onConvert:    (m: LoungeMessage) => void;
  onDelete:     (m: LoungeMessage) => void;
  convertingId: string | null;
  actionPlan:   ActionPlan | null;
  authorName:   string;
  authorUid:    string;
}) {
  const [hovered,    setHovered]    = useState(false);
  const [swipeDeltaX, setSwipeDeltaX] = useState(0);
  const touchStartX  = useRef(0);
  const touchStartY  = useRef(0);
  const isSwiping    = useRef(false);
  const isConverting = convertingId === msg.id;

  // ── Swipe-to-Reply touch handlers ─────────────────────────────────────────
  function handleTouchStart(e: React.TouchEvent) {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    isSwiping.current   = false;
  }

  function handleTouchMove(e: React.TouchEvent) {
    const dx = e.touches[0].clientX - touchStartX.current;
    const dy = e.touches[0].clientY - touchStartY.current;
    // Only activate horizontal swipe when dx > dy (not scroll)
    if (!isSwiping.current && Math.abs(dx) < Math.abs(dy)) return;
    if (dx > 0) {
      isSwiping.current = true;
      setSwipeDeltaX(Math.min(dx, SWIPE_MAX_TRANSLATE));
    }
  }

  function handleTouchEnd() {
    if (swipeDeltaX >= SWIPE_THRESHOLD) {
      onReply(msg);
    }
    setSwipeDeltaX(0);
    isSwiping.current = false;
  }

  return (
    <div
      className={`flex gap-2.5 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {!isOwn && <MemberAvatar url={msg.avatar_url} name={msg.display_name} size={8} />}
      <div
        className={`flex flex-col gap-0.5 max-w-[85%] min-w-0 ${isOwn ? 'items-end' : 'items-start'}`}
        style={{
          transform:  `translateX(${swipeDeltaX}px)`,
          transition: swipeDeltaX === 0 ? 'transform 0.25s cubic-bezier(0.34,1.56,0.64,1)' : 'none',
        }}
      >
        {!isOwn && (
          <span className="text-[11px] font-semibold text-primary/80 px-1">{msg.display_name}</span>
        )}
        {/* Reply preview */}
        {msg.reply_to_id && (
          <div className={`px-3 py-1.5 rounded-xl text-[11px] text-muted-foreground border-l-2 border-primary/40 bg-primary/5 ${isOwn ? 'border-r-2 border-l-0 text-right' : ''}`}>
            <span className="font-semibold text-primary/70">{msg.reply_to_name}</span>
            <p className="truncate max-w-[200px]">{msg.reply_to_text}</p>
          </div>
        )}
        {/* Bubble + action buttons row */}
        <div className={`flex items-end gap-1.5 w-full ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}>
          <div className={`relative px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed break-words min-w-0 transition-all ${
            isOwn
              ? 'bg-primary/20 border border-primary/30 text-foreground rounded-tr-sm'
              : 'bg-secondary/70 border border-white/8 text-foreground rounded-tl-sm'
          }`}>
            {/* Swipe hint arrow (shows when swiping) */}
            {swipeDeltaX > 10 && !isOwn && (
              <span className="absolute -left-6 top-1/2 -translate-y-1/2 text-primary/60">
                <CornerDownLeft className="h-3.5 w-3.5" />
              </span>
            )}
            {msg.message_text}
          </div>
          {/* Hover action buttons */}
          <div className={`flex items-center gap-0.5 transition-all ${hovered ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
            <button onClick={() => onReply(msg)} title="Reply"
              className="flex h-6 w-6 items-center justify-center rounded-lg bg-secondary/60 border border-white/8 hover:border-primary/30 hover:text-primary transition-all text-muted-foreground/60">
              <CornerDownLeft className="h-3 w-3" />
            </button>
            <button onClick={() => onPin(msg)} title="Pin to Strategy"
              className="flex h-6 w-6 items-center justify-center rounded-lg bg-secondary/60 border border-white/8 hover:border-yellow-400/40 hover:text-yellow-400 transition-all text-muted-foreground/60">
              <Pin className="h-3 w-3" />
            </button>
            <button onClick={() => onConvert(msg)} disabled={isConverting} title="Convert to Action Plan"
              className="flex h-6 w-6 items-center justify-center rounded-lg bg-secondary/60 border border-white/8 hover:border-primary/40 hover:text-primary transition-all text-muted-foreground/60 disabled:opacity-60">
              {isConverting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Zap className="h-3 w-3" />}
            </button>
            {/* Admin-only delete */}
            {isAdmin && (
              <button onClick={() => onDelete(msg)} title="Delete message"
                className="flex h-6 w-6 items-center justify-center rounded-lg bg-secondary/60 border border-white/8 hover:border-destructive/50 hover:text-destructive transition-all text-muted-foreground/60">
                <Trash2 className="h-3 w-3" />
              </button>
            )}
          </div>
        </div>
        {/* YouTube embed (if URL detected) */}
        {msg.youtube_video_id && (
          <div className="w-full max-w-xs md:max-w-sm">
            <InlineYouTubePlayer
              videoId={msg.youtube_video_id}
              authorName={authorName}
              authorUid={authorUid}
            />
          </div>
        )}
        {/* Action plan card */}
        {actionPlan && (
          <div className="w-full">
            <ActionPlanCard plan={actionPlan} messageId={msg.id} />
          </div>
        )}
        <span className="text-[10px] text-muted-foreground/40 px-1">{formatTime(msg.created_at)}</span>
      </div>
    </div>
  );
}

// ── Strategy Document Tab ─────────────────────────────────────────────────────
function StrategyDocument() {
  const [pins,    setPins]    = useState<StrategyPin[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from('lounge_strategy_pins').select('*').order('pinned_at', { ascending: true })
      .then(({ data }) => { if (data) setPins(data as StrategyPin[]); setLoading(false); });

    const ch = supabase.channel('strategy-pins')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'lounge_strategy_pins' },
        async () => {
          const { data } = await supabase.from('lounge_strategy_pins').select('*').order('pinned_at', { ascending: true });
          if (data) setPins(data as StrategyPin[]);
        })
      .subscribe();
    return () => { ch.unsubscribe(); };
  }, []);

  async function removePin(id: string) {
    await supabase.from('lounge_strategy_pins').delete().eq('id', id);
  }

  return (
    <div className="flex-1 overflow-y-auto px-4 py-4 min-h-0 space-y-3">
      <div className="flex items-center gap-2 mb-4">
        <BookOpen className="h-4 w-4 text-primary" />
        <h3 className="text-sm font-black text-foreground">Strategy Document</h3>
        <span className="text-[11px] text-muted-foreground/60">{pins.length} pin{pins.length !== 1 ? 's' : ''}</span>
      </div>
      {loading && <div className="flex justify-center pt-8"><Loader2 className="h-4 w-4 animate-spin text-muted-foreground/40" /></div>}
      {!loading && pins.length === 0 && (
        <div className="flex flex-col items-center gap-2 pt-12 text-muted-foreground/40 text-center">
          <Pin className="h-6 w-6" />
          <p className="text-sm">No pins yet. Hover over any message and click the pin icon to add it here.</p>
        </div>
      )}
      {pins.map((pin, i) => (
        <div key={pin.id} className="group relative rounded-xl border border-white/8 bg-secondary/40 px-4 py-3.5 hover:border-primary/20 transition-all">
          <div className="flex items-start gap-2">
            <span className="text-[11px] font-bold text-primary/60 shrink-0 mt-0.5">#{i + 1}</span>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-foreground leading-relaxed">{pin.message_text}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-[10px] text-muted-foreground/50">Pinned by</span>
                <span className="text-[10px] font-semibold text-primary/70">{pin.pinned_by_name}</span>
                <span className="text-[10px] text-muted-foreground/40">{formatTime(pin.pinned_at)}</span>
              </div>
            </div>
          </div>
          <button onClick={() => removePin(pin.id)}
            className="absolute top-2.5 right-2.5 opacity-0 group-hover:opacity-100 flex h-6 w-6 items-center justify-center rounded-lg text-muted-foreground/50 hover:text-destructive hover:bg-destructive/10 transition-all">
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
}

// ── Main Team Command Center ───────────────────────────────────────────────────
// ── Send Credits Panel ────────────────────────────────────────────────────────
// ── Types for upgraded send panel ─────────────────────────────────────────────
type SendStep  = 'form' | 'confirm' | 'receipt';
type SendMode  = 'transfer' | 'grant';

interface TransferReceipt {
  amount:         number;
  recipientName:  string;
  recipientEmail: string;
  newBalance:     number | null;  // null for grant mode (sender balance unchanged)
  sentAt:         Date;
  mode:           SendMode;
}

function SendCreditsPanel({ senderUid, senderEmail, senderCredits, isAdmin, onSuccess }: {
  senderUid:     string;
  senderEmail:   string;
  senderCredits: number;
  isAdmin:       boolean;
  onSuccess:     (newBalance: number) => void;
}) {
  const [mode,            setMode]            = useState<SendMode>('transfer');
  const [step,            setStep]            = useState<SendStep>('form');
  const [recipientEmail,  setRecipientEmail]  = useState('');
  const [amount,          setAmount]          = useState('');
  const [sending,         setSending]         = useState(false);
  const [error,           setError]           = useState<string | null>(null);
  const [receipt,         setReceipt]         = useState<TransferReceipt | null>(null);

  // Live recipient lookup state
  const [lookupState,  setLookupState]  = useState<'idle' | 'loading' | 'found' | 'not_found'>('idle');
  const [resolvedUser, setResolvedUser] = useState<AppUser | null>(null);
  const lookupDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  function clearError() { setError(null); }

  // Switch mode resets form
  function handleModeSwitch(m: SendMode) {
    setMode(m);
    setStep('form');
    setRecipientEmail('');
    setAmount('');
    setResolvedUser(null);
    setLookupState('idle');
    setReceipt(null);
    clearError();
  }

  // Live lookup: fires 600ms after user stops typing email
  function handleEmailChange(val: string) {
    setRecipientEmail(val);
    clearError();
    setResolvedUser(null);
    if (lookupDebounceRef.current) clearTimeout(lookupDebounceRef.current);

    const trimmed = val.trim().toLowerCase();
    if (!trimmed || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      setLookupState('idle');
      return;
    }
    setLookupState('loading');
    lookupDebounceRef.current = setTimeout(async () => {
      const user = await getUserByEmail(trimmed);
      if (user) { setResolvedUser(user); setLookupState('found'); }
      else       { setLookupState('not_found'); }
    }, 600);
  }

  useEffect(() => () => {
    if (lookupDebounceRef.current) clearTimeout(lookupDebounceRef.current);
  }, []);

  // ── Step 1 → Step 2: validate then show confirm ────────────────────────────
  function handleReview() {
    clearError();
    const emailTrimmed = recipientEmail.trim().toLowerCase();
    const amt = parseInt(amount, 10);

    if (!emailTrimmed || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailTrimmed)) {
      setError('Please enter a valid Gmail / email address.'); return;
    }
    if (mode === 'transfer' && emailTrimmed === senderEmail.toLowerCase()) {
      setError('You cannot send credits to yourself.'); return;
    }
    if (isNaN(amt) || amt <= 0) {
      setError('Please enter a valid credit amount greater than 0.'); return;
    }
    if (mode === 'transfer' && amt > senderCredits) {
      setError(`Insufficient credits. You only have ${formatCredits(senderCredits)} credits.`); return;
    }
    if (lookupState === 'not_found') {
      setError('No AlphaTekx account found for that email address.'); return;
    }
    if (lookupState === 'loading') {
      setError('Still looking up that email — please wait a moment.'); return;
    }
    setStep('confirm');
  }

  // ── Step 2 → Step 3: execute transfer or grant ────────────────────────────
  async function handleConfirm() {
    clearError();
    setSending(true);
    const emailTrimmed = recipientEmail.trim().toLowerCase();
    const amt = parseInt(amount, 10);

    try {
      const recipient = resolvedUser ?? await getUserByEmail(emailTrimmed);
      if (!recipient) {
        setError('No AlphaTekx account found for that email.');
        setStep('form'); setSending(false); return;
      }

      if (mode === 'grant') {
        // ── ADMIN GRANT: add credits directly, no sender deduction ──────────
        await addFirestoreCredits(recipient.uid, amt);
        await supabase.from('credit_transfers').insert({
          sender_uid:      senderUid,
          sender_email:    senderEmail,
          recipient_uid:   recipient.uid,
          recipient_email: emailTrimmed,
          amount:          amt,
          transfer_type:   'grant',
        });
        setReceipt({
          amount:         amt,
          recipientName:  recipient.display_name || emailTrimmed,
          recipientEmail: emailTrimmed,
          newBalance:     null,
          sentAt:         new Date(),
          mode:           'grant',
        });
        toast.success(`${amt} credit${amt !== 1 ? 's' : ''} granted to ${recipient.display_name}`);
      } else {
        // ── TRANSFER: deduct from sender, add to recipient ───────────────────
        const result = await transferCredits(senderUid, recipient.uid, amt);
        if (!result.success) {
          setError(result.error ?? 'Transfer failed. Please try again.');
          setStep('form'); setSending(false); return;
        }
        await supabase.from('credit_transfers').insert({
          sender_uid:      senderUid,
          sender_email:    senderEmail,
          recipient_uid:   recipient.uid,
          recipient_email: emailTrimmed,
          amount:          amt,
          transfer_type:   'transfer',
        });
        const newBalance = result.senderBalance ?? senderCredits - amt;
        setReceipt({
          amount:         amt,
          recipientName:  recipient.display_name || emailTrimmed,
          recipientEmail: emailTrimmed,
          newBalance,
          sentAt:         new Date(),
          mode:           'transfer',
        });
        onSuccess(newBalance);
        toast.success(`${amt} credit${amt !== 1 ? 's' : ''} sent to ${recipient.display_name}`);
      }

      setStep('receipt');
    } catch {
      setError('Something went wrong. Please try again.');
      setStep('form');
    } finally {
      setSending(false);
    }
  }

  function handleSendAnother() {
    setStep('form');
    setRecipientEmail('');
    setAmount('');
    setResolvedUser(null);
    setLookupState('idle');
    setReceipt(null);
    clearError();
  }

  const amt      = parseInt(amount, 10);
  const canReview = recipientEmail.trim().length > 0
    && !isNaN(amt) && amt > 0
    && lookupState !== 'loading'
    && !sending;

  // ── Mode toggle (admin only) ───────────────────────────────────────────────
  const ModeToggle = isAdmin ? (
    <div className="flex rounded-xl border border-border/50 bg-secondary/30 p-1 gap-1">
      <button
        onClick={() => handleModeSwitch('transfer')}
        className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-black transition-all ${
          mode === 'transfer'
            ? 'bg-primary text-primary-foreground shadow-sm'
            : 'text-muted-foreground hover:text-foreground'
        }`}
      >
        <ArrowRightLeft className="h-3.5 w-3.5" />
        Send from Balance
      </button>
      <button
        onClick={() => handleModeSwitch('grant')}
        className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-black transition-all ${
          mode === 'grant'
            ? 'bg-primary text-primary-foreground shadow-sm'
            : 'text-muted-foreground hover:text-foreground'
        }`}
      >
        <Zap className="h-3.5 w-3.5" />
        Grant Credits
      </button>
    </div>
  ) : null;

  // ── STEP 3: Receipt ────────────────────────────────────────────────────────
  if (step === 'receipt' && receipt) {
    return (
      <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6 min-h-0">
        <div className="max-w-md mx-auto space-y-6">
          <div className="rounded-2xl border border-green-500/30 bg-green-500/8 p-6 flex flex-col items-center gap-4 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-green-500/15 border border-green-500/30">
              <CheckCircle2 className="h-7 w-7 text-green-500" />
            </div>
            <div>
              <h2 className="text-lg font-black text-foreground">
                {receipt.mode === 'grant' ? 'Credits Granted!' : 'Transfer Complete!'}
              </h2>
              <p className="text-sm text-muted-foreground mt-1 text-pretty">
                {receipt.mode === 'grant'
                  ? 'Credits have been added to their account instantly.'
                  : 'Your credits have been sent instantly.'}
              </p>
            </div>
          </div>

          <div className="rounded-2xl border border-border/50 bg-card divide-y divide-border/40 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">
                {receipt.mode === 'grant' ? 'Credits Granted' : 'Amount Sent'}
              </span>
              <span className="text-sm font-black text-primary">
                {receipt.amount.toLocaleString()} credit{receipt.amount !== 1 ? 's' : ''}
              </span>
            </div>
            <div className="flex items-center justify-between px-5 py-3.5">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">
                {receipt.mode === 'grant' ? 'Credited To' : 'Sent To'}
              </span>
              <div className="text-right">
                <p className="text-sm font-bold text-foreground">{receipt.recipientName}</p>
                <p className="text-xs text-muted-foreground">{receipt.recipientEmail}</p>
              </div>
            </div>
            {receipt.mode === 'transfer' && receipt.newBalance !== null && (
              <div className="flex items-center justify-between px-5 py-3.5">
                <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Your New Balance</span>
                <span className="text-sm font-black text-foreground">{formatCredits(receipt.newBalance)} credits</span>
              </div>
            )}
            {receipt.mode === 'grant' && (
              <div className="flex items-center justify-between px-5 py-3.5">
                <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Type</span>
                <span className="text-xs font-black text-primary uppercase tracking-widest">Admin Grant</span>
              </div>
            )}
            <div className="flex items-center justify-between px-5 py-3.5">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Time</span>
              <span className="text-xs font-bold text-muted-foreground">
                {receipt.sentAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                {' · '}
                {receipt.sentAt.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
              </span>
            </div>
          </div>

          <button
            onClick={handleSendAnother}
            className="w-full flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-primary text-primary-foreground font-black text-sm shadow-lg shadow-primary/20 hover:bg-primary/90 active:scale-[0.98] transition-all"
          >
            <ArrowRightLeft className="h-4 w-4" />
            {mode === 'grant' ? 'Grant Again' : 'Send Another Transfer'}
          </button>
        </div>
      </div>
    );
  }

  // ── STEP 2: Confirm ────────────────────────────────────────────────────────
  if (step === 'confirm') {
    const displayName = resolvedUser?.display_name || recipientEmail.trim();
    const isGrant = mode === 'grant';
    return (
      <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6 min-h-0">
        <div className="max-w-md mx-auto space-y-6">
          <div className={`rounded-2xl border p-5 flex items-start gap-4 ${
            isGrant ? 'border-amber-500/25 bg-amber-500/5' : 'border-primary/20 bg-primary/5'
          }`}>
            <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border ${
              isGrant ? 'bg-amber-500/15 border-amber-500/30' : 'bg-primary/15 border-primary/30'
            }`}>
              {isGrant ? <Zap className="h-5 w-5 text-amber-500" /> : <Send className="h-5 w-5 text-primary" />}
            </div>
            <div>
              <h2 className="text-base font-black text-foreground">
                {isGrant ? 'Confirm Credit Grant' : 'Confirm Transfer'}
              </h2>
              <p className="text-sm text-muted-foreground mt-1 text-pretty">
                {isGrant
                  ? 'These credits will be added to their account from the platform — your balance is unaffected.'
                  : 'Please review the details below before confirming.'}
              </p>
            </div>
          </div>

          <div className="rounded-2xl border border-border/50 bg-card divide-y divide-border/40 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">
                {isGrant ? 'Granting' : 'Sending'}
              </span>
              <span className="text-xl font-black text-primary">
                {parseInt(amount, 10).toLocaleString()} credit{parseInt(amount, 10) !== 1 ? 's' : ''}
              </span>
            </div>
            <div className="flex items-center justify-between px-5 py-4">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">To</span>
              <div className="text-right">
                <p className="text-sm font-black text-foreground">{displayName}</p>
                <p className="text-xs text-muted-foreground">{recipientEmail.trim().toLowerCase()}</p>
              </div>
            </div>
            <div className="flex items-center justify-between px-5 py-4">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Your Balance</span>
              <span className="text-sm font-bold text-muted-foreground">
                {isGrant
                  ? <span className="text-green-500 font-black">Unchanged</span>
                  : `${formatCredits(senderCredits - parseInt(amount, 10))} credits after`}
              </span>
            </div>
          </div>

          {isGrant && (
            <p className="text-center text-xs text-amber-500/80 font-bold">
              ⚡ Admin grant — credits are created instantly, not deducted from any balance
            </p>
          )}
          {!isGrant && (
            <p className="text-center text-xs text-amber-500/80 font-bold">
              ⚠ Transfers are instant and irreversible
            </p>
          )}

          {error && (
            <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive text-sm font-bold">
              <AlertCircle className="h-4 w-4 shrink-0" />{error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={() => { setStep('form'); clearError(); }}
              disabled={sending}
              className="flex-1 px-5 py-3.5 rounded-xl border border-border/60 bg-secondary/40 text-foreground font-bold text-sm hover:bg-secondary/70 transition-all disabled:opacity-40"
            >
              Go Back
            </button>
            <button
              onClick={handleConfirm}
              disabled={sending}
              className={`flex-1 flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl font-black text-sm shadow-lg active:scale-[0.98] transition-all disabled:opacity-40 ${
                isGrant
                  ? 'bg-amber-500 text-white shadow-amber-500/20 hover:bg-amber-500/90'
                  : 'bg-primary text-primary-foreground shadow-primary/20 hover:bg-primary/90'
              }`}
            >
              {sending ? (
                <><Loader2 className="h-4 w-4 animate-spin" /> {isGrant ? 'Granting…' : 'Sending…'}</>
              ) : (
                <>{isGrant ? <Zap className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
                  {isGrant ? 'Confirm Grant' : 'Confirm Send'}</>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── STEP 1: Form ───────────────────────────────────────────────────────────
  const isGrant = mode === 'grant';
  return (
    <div className="flex-1 overflow-y-auto px-4 md:px-6 py-6 min-h-0">
      <div className="max-w-md mx-auto space-y-5">

        {/* Mode toggle — admin only */}
        {ModeToggle}

        {/* Header card */}
        <div className={`rounded-2xl border p-5 flex items-start gap-4 ${
          isGrant ? 'border-amber-500/25 bg-amber-500/5' : 'border-primary/20 bg-primary/5'
        }`}>
          <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border ${
            isGrant ? 'bg-amber-500/15 border-amber-500/30' : 'bg-primary/15 border-primary/30'
          }`}>
            {isGrant ? <Zap className="h-5 w-5 text-amber-500" /> : <ArrowRightLeft className="h-5 w-5 text-primary" />}
          </div>
          <div>
            <h2 className="text-base font-black text-foreground">
              {isGrant ? 'Grant Credits' : 'Send Credits'}
            </h2>
            <p className="text-sm text-muted-foreground mt-1 text-pretty">
              {isGrant
                ? 'Add any amount of credits to any member\'s account instantly — no balance required. Admin only.'
                : 'Transfer any amount of credits to any AlphaTekx member instantly from your balance.'}
            </p>
          </div>
        </div>

        {/* Balance pill — hide for grant mode */}
        {!isGrant && (
          <div className="flex items-center justify-between px-4 py-3 rounded-xl bg-secondary/50 border border-border/40">
            <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Your Balance</span>
            <span className="text-sm font-black text-primary">{formatCredits(senderCredits)} credits</span>
          </div>
        )}

        {/* Form */}
        <div className="space-y-4">

          {/* Email field + live lookup */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Recipient Gmail</label>
            <div className="relative">
              <input
                type="email"
                value={recipientEmail}
                onChange={e => handleEmailChange(e.target.value)}
                placeholder="their@gmail.com"
                className="w-full rounded-xl border border-border/60 bg-secondary/40 px-4 py-3 pr-10 text-sm text-foreground placeholder:text-muted-foreground/40 outline-none focus:border-primary/60 focus:ring-1 focus:ring-primary/20 transition-all font-medium"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                {lookupState === 'loading'   && <Loader2      className="h-4 w-4 animate-spin text-muted-foreground/40" />}
                {lookupState === 'found'     && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                {lookupState === 'not_found' && <AlertCircle  className="h-4 w-4 text-destructive/70" />}
                {lookupState === 'idle'      && <Search       className="h-4 w-4 text-muted-foreground/25" />}
              </div>
            </div>

            {/* Live recipient preview */}
            {lookupState === 'found' && resolvedUser && (
              <div className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-green-500/8 border border-green-500/20 animate-in fade-in slide-in-from-top-1 duration-200">
                {resolvedUser.photo_url ? (
                  <img src={resolvedUser.photo_url} className="h-7 w-7 rounded-full object-cover shrink-0" alt="" />
                ) : (
                  <div className="h-7 w-7 rounded-full bg-primary/20 shrink-0 flex items-center justify-center text-[10px] font-black text-primary">
                    {resolvedUser.display_name?.charAt(0)?.toUpperCase() ?? '?'}
                  </div>
                )}
                <div className="min-w-0">
                  <p className="text-xs font-black text-green-400 truncate">{resolvedUser.display_name}</p>
                  <p className="text-[10px] text-muted-foreground/60 truncate">AlphaTekx member · ready to receive</p>
                </div>
              </div>
            )}
            {lookupState === 'not_found' && recipientEmail.trim().length > 0 && (
              <p className="text-xs text-destructive/80 font-bold px-1">No AlphaTekx account found for this email.</p>
            )}
          </div>

          {/* Amount field */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Credit Amount</label>
            <input
              type="number"
              min={1}
              value={amount}
              onChange={e => { setAmount(e.target.value); clearError(); }}
              onKeyDown={e => e.key === 'Enter' && canReview && handleReview()}
              placeholder="Type any amount, e.g. 10, 250, 1000…"
              className="w-full rounded-xl border border-border/60 bg-secondary/40 px-4 py-3.5 text-base font-black text-foreground placeholder:text-muted-foreground/30 placeholder:font-normal outline-none focus:border-primary/60 focus:ring-1 focus:ring-primary/20 transition-all"
            />
            {!isGrant && !isNaN(amt) && amt > 0 && (
              <p className="text-xs text-muted-foreground/60 font-bold px-1">
                Balance after: {formatCredits(Math.max(0, senderCredits - amt))} credits
              </p>
            )}
            {isGrant && !isNaN(amt) && amt > 0 && (
              <p className="text-xs text-amber-500/70 font-bold px-1">
                ⚡ {amt.toLocaleString()} credits will be added to their account — your balance stays the same
              </p>
            )}
          </div>

          {/* Quick-amount chips */}
          <div className="space-y-1.5">
            <p className="text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest">Quick amounts</p>
            <div className="flex flex-wrap gap-2">
              {[10, 25, 50, 100, 200, 500, 1000].map(v => (
                <button
                  key={v}
                  onClick={() => { setAmount(String(v)); clearError(); }}
                  className={`px-3 py-1.5 rounded-full text-xs font-black border transition-all ${
                    amount === String(v)
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'bg-secondary/60 border-border/40 text-muted-foreground hover:text-foreground hover:border-primary/30'
                  }`}
                >
                  {v.toLocaleString()}
                </button>
              ))}
            </div>
          </div>

          {/* Error message */}
          {error && (
            <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/25 text-destructive text-sm font-bold animate-in fade-in slide-in-from-bottom-1 duration-200">
              <AlertCircle className="h-4 w-4 shrink-0" />{error}
            </div>
          )}

          {/* Review button */}
          <button
            onClick={handleReview}
            disabled={!canReview}
            className={`w-full flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-black text-sm shadow-lg active:scale-[0.98] transition-all disabled:opacity-40 ${
              isGrant
                ? 'bg-amber-500 text-white shadow-amber-500/20 hover:bg-amber-500/90'
                : 'bg-primary text-primary-foreground shadow-primary/20 hover:bg-primary/90'
            }`}
          >
            {isGrant ? <Zap className="h-4 w-4" /> : <Send className="h-4 w-4" />}
            {isGrant ? 'Review Grant' : 'Review Transfer'}
          </button>
        </div>

        <p className="text-center text-[10px] text-muted-foreground/30 font-bold uppercase tracking-widest">
          {isGrant ? 'Admin grants are logged and audited' : 'Transfers are instant and irreversible'}
        </p>
      </div>
    </div>
  );
}

export default function MembersLounge() {
  const { appUser }  = useUserSession();
  const navigate     = useNavigate();
  const credits      = appUser?.credits ?? 0;
  const hasCredits   = credits > 0;
  const [unlocked, setUnlocked] = useState(
    () => sessionStorage.getItem(SESSION_KEY) === 'true'
  );
  const [activeTab,   setActiveTab]   = useState<'chat' | 'strategy' | 'credits'>('chat');
  const [messages,    setMessages]    = useState<LoungeMessage[]>([]);
  const [actionPlans, setActionPlans] = useState<Record<string, ActionPlan>>({});
  const [input,       setInput]       = useState('');
  const [sending,     setSending]     = useState(false);
  const [replyTo,     setReplyTo]     = useState<LoungeMessage | null>(null);
  const [loading,     setLoading]     = useState(true);
  const [convertingId, setConvertingId] = useState<string | null>(null);
  const [clearing, setClearing] = useState(false);
  const [typingNames,  setTypingNames]  = useState<string[]>([]);
  const typingTimer  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const typingChannel = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const bottomRef    = useRef<HTMLDivElement>(null);

  const displayName = appUser?.display_name || appUser?.email || 'Member';
  const avatarUrl   = appUser?.photo_url    || null;
  const firebaseUid = appUser?.uid          || '';
  const isAdmin     = appUser?.role === 'admin';

  const onlineCount = useLoungePresence(displayName, unlocked);

  // ── Load messages & action plans ───────────────────────────────────────────
  useEffect(() => {
    if (!unlocked) return;

    supabase.from('lounge_messages').select('*').order('created_at', { ascending: true }).limit(150)
      .then(({ data }) => { if (data) setMessages(data as LoungeMessage[]); setLoading(false); });

    supabase.from('lounge_action_plans').select('*')
      .then(({ data }) => {
        if (data) {
          const map: Record<string, ActionPlan> = {};
          (data as ActionPlan[]).forEach(p => { map[p.message_id] = p; });
          setActionPlans(map);
        }
      });

    const chatCh = supabase.channel('hq-messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'lounge_messages' },
        (p) => setMessages(prev => [...prev, p.new as LoungeMessage]))
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'lounge_messages' },
        (p) => setMessages(prev => prev.filter(m => m.id !== (p.old as { id: string }).id)))
      .subscribe();

    const planCh = supabase.channel('hq-plans')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'lounge_action_plans' },
        (p) => {
          const plan = p.new as ActionPlan;
          setActionPlans(prev => ({ ...prev, [plan.message_id]: plan }));
        })
      .subscribe();

    return () => { chatCh.unsubscribe(); planCh.unsubscribe(); };
  }, [unlocked]);

  // ── Typing indicator via Realtime broadcast ────────────────────────────────
  useEffect(() => {
    if (!unlocked) return;
    const ch = supabase.channel(TYPING_CHANNEL);
    typingChannel.current = ch;
    ch.on('broadcast', { event: 'typing' }, (payload) => {
      const { name, uid } = payload.payload as { name: string; uid: string };
      if (uid === firebaseUid) return;
      setTypingNames(prev => prev.includes(name) ? prev : [...prev, name]);
      setTimeout(() => setTypingNames(prev => prev.filter(n => n !== name)), 3500);
    }).subscribe();
    return () => { ch.unsubscribe(); typingChannel.current = null; };
  }, [unlocked, firebaseUid]);

  const broadcastTyping = useCallback(() => {
    typingChannel.current?.send({ type: 'broadcast', event: 'typing', payload: { name: displayName, uid: firebaseUid } });
    if (typingTimer.current) clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => { typingTimer.current = null; }, 2500);
  }, [displayName, firebaseUid]);

  // ── Auto-scroll ────────────────────────────────────────────────────────────
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  // ── Send message ───────────────────────────────────────────────────────────
  async function sendMessage() {
    const text = input.trim();
    if (!text || sending) return;

    // ── "announce" trigger word ───────────────────────────────────────────────
    // Format: "announce <message>" — broadcasts a live banner to the whole app
    const ANNOUNCE_PREFIX = /^announce\s+/i;
    if (ANNOUNCE_PREFIX.test(text)) {
      const bannerText = text.replace(ANNOUNCE_PREFIX, '').trim();
      if (!bannerText) {
        toast.error('Type something after "announce" to post a banner.');
        return;
      }
      setSending(true);
      // Deactivate all previous announcements, then insert new one
      await supabase.from('lounge_announcements').update({ is_active: false }).eq('is_active', true);
      const { error } = await supabase.from('lounge_announcements').insert({
        text: bannerText,
        is_active: true,
        created_by_name: displayName,
      });
      setSending(false);
      if (error) { toast.error('Failed to post announcement.'); return; }
      setInput('');
      toast.success('📣 Announcement is now live for everyone!');
      return;
    }

    // ── Normal message ────────────────────────────────────────────────────────
    setSending(true);
    const youtubeId = extractYouTubeId(text);
    const payload: Record<string, unknown> = {
      firebase_uid: firebaseUid, display_name: displayName, avatar_url: avatarUrl,
      message_text: text, youtube_video_id: youtubeId ?? null,
    };
    if (replyTo) {
      payload.reply_to_id   = replyTo.id;
      payload.reply_to_name = replyTo.display_name;
      payload.reply_to_text = replyTo.message_text.slice(0, REPLY_MAX);
    }
    const { error } = await supabase.from('lounge_messages').insert(payload);
    setSending(false);
    if (error) { toast.error('Failed to send message.'); return; }
    setInput('');
    setReplyTo(null);
  }

  // ── Pin to strategy ────────────────────────────────────────────────────────
  async function pinMessage(msg: LoungeMessage) {
    const { error } = await supabase.from('lounge_strategy_pins').insert({
      message_text: msg.message_text, pinned_by: firebaseUid,
      pinned_by_name: displayName, pinned_at: new Date().toISOString(),
    });
    if (error) { toast.error('Failed to pin message.'); return; }
    toast.success('Pinned to Strategy Document ✦');
  }

  // ── Delete message (admin only) ────────────────────────────────────────────
  async function deleteMessage(msg: LoungeMessage) {
    const { error } = await supabase.from('lounge_messages').delete().eq('id', msg.id);
    if (error) { toast.error('Failed to delete message.'); return; }
    // Optimistically remove locally; Realtime DELETE will confirm for all others
    setMessages(prev => prev.filter(m => m.id !== msg.id));
  }

  async function clearAllMessages() {
    if (!isAdmin) return;
    if (!window.confirm('Clear ALL messages from Team HQ? This cannot be undone.')) return;
    setClearing(true);
    const { error } = await supabase.from('lounge_messages').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    if (error) { toast.error('Failed to clear chat.'); }
    else { setMessages([]); toast.success('Chat cleared — HQ is fresh.'); }
    setClearing(false);
  }

  // ── Convert to action plan ─────────────────────────────────────────────────
  async function convertToActionPlan(msg: LoungeMessage) {
    if (convertingId) return;
    setConvertingId(msg.id);
    try {
      const { data, error } = await supabase.functions.invoke('convert-to-action-plan', {
        body: { messageText: msg.message_text },
      });
      if (error) {
        const txt = await error?.context?.text?.();
        toast.error(`AI failed: ${txt || error.message}`);
        return;
      }
      const tasks = (data as { tasks: ActionTask[] }).tasks;
      if (!tasks?.length) { toast.error('AI returned no tasks.'); return; }
      const { error: dbErr } = await supabase.from('lounge_action_plans').insert({ message_id: msg.id, tasks });
      if (dbErr) { toast.error('Failed to save action plan.'); return; }
      toast.success('Action plan generated ⚡');
    } finally {
      setConvertingId(null);
    }
  }

  // ── Gates ──────────────────────────────────────────────────────────────────
  if (!hasCredits) {
    return <div className="flex flex-col h-full w-full"><NoCreditsGate /></div>;
  }
  if (!unlocked) {
    return <div className="flex flex-col h-full w-full"><AccessGate onUnlock={() => setUnlocked(true)} /></div>;
  }

  // ── HQ UI ──────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col h-full w-full min-w-0 overflow-hidden">

      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div className="shrink-0 px-5 py-4 border-b border-white/10 glass-strong flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative shrink-0">
            <div className="absolute inset-0 rounded-xl bg-primary/30 blur-md" />
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 border border-primary/35">
              <Shield className="h-5 w-5 text-primary" />
            </div>
          </div>
          <div className="min-w-0">
            <p className="text-base font-black leading-tight gradient-text">Team Command Center</p>
            <p className="text-[11px] text-muted-foreground">AlphaTekx HQ · Mission Control</p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {/* Clear chat — admin only */}
          {isAdmin && (
            <button
              onClick={clearAllMessages}
              disabled={clearing}
              title="Clear all messages"
              className="flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-bold uppercase tracking-wider border border-destructive/30 text-destructive/70 hover:bg-destructive/10 hover:text-destructive hover:border-destructive/50 transition-all disabled:opacity-40"
            >
              {clearing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
              <span className="hidden sm:inline">Clear Chat</span>
            </button>
          )}
          {/* Online */}
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-green-500/10 border border-green-500/20">
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inset-0 rounded-full bg-green-400/70" />
              <span className="relative flex h-1.5 w-1.5 rounded-full bg-green-500" />
            </span>
            <Users className="h-3 w-3 text-green-400" />
            <span className="text-xs font-bold text-green-400 tabular-nums">{onlineCount}</span>
          </div>
          {/* Close */}
          <button onClick={() => navigate('/dashboard')}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary/60 border border-white/10 text-muted-foreground hover:text-foreground hover:border-white/25 transition-all">
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* ── Team Pulse ─────────────────────────────────────────────────────── */}
      <TeamPulseBar />

      {/* ── Announcement Banner — prominent in HQ ──────────────────────────── */}
      <AnnouncementBanner isAdmin={isAdmin} variant="prominent" />

      {/* ── Tab bar ────────────────────────────────────────────────────────── */}
      <div className="shrink-0 flex gap-1 px-4 md:px-6 pt-4 pb-0">
        {([
          { id: 'chat',     label: 'Live Chat',    Icon: MessageSquare },
          { id: 'strategy', label: 'Strategy Doc', Icon: BookOpen },
          { id: 'credits',  label: 'Send Credits', Icon: ArrowRightLeft },
        ] as const).map(({ id, label, Icon }) => (
          <button key={id} onClick={() => setActiveTab(id)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-t-xl text-xs font-semibold transition-all border-b-2 ${
              activeTab === id
                ? 'bg-primary/10 border-primary text-primary'
                : 'bg-transparent border-transparent text-muted-foreground hover:text-foreground hover:bg-white/5'
            }`}>
            <Icon className="h-3.5 w-3.5" />
            {label}
          </button>
        ))}
      </div>
      <div className="shrink-0 h-px bg-white/8 mx-0 mb-0" />

      {/* ── Strategy Document ────────────────────────────────────────────── */}
      {activeTab === 'strategy' && <StrategyDocument />}

      {/* ── Send Credits ─────────────────────────────────────────────────── */}
      {activeTab === 'credits' && (
        <SendCreditsPanel
          senderUid={firebaseUid}
          senderEmail={appUser?.email ?? ''}
          senderCredits={credits}
          isAdmin={isAdmin}
          onSuccess={(newBalance) => {
            // Optimistically update the local appUser credits display
            // The real balance will sync via refreshBalance on next load
            void newBalance;
          }}
        />
      )}

      {/* ── Chat ─────────────────────────────────────────────────────────── */}
      {activeTab === 'chat' && (
        <>
          <div className="flex-1 overflow-y-auto px-4 md:px-6 py-5 space-y-4 min-h-0">
            {loading && (
              <div className="flex justify-center pt-8"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground/40" /></div>
            )}
            {!loading && messages.length === 0 && (
              <div className="flex flex-col items-center gap-3 pt-16 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 border border-primary/25">
                  <Zap className="h-7 w-7 text-primary" />
                </div>
                <p className="text-sm font-semibold text-foreground/70">The HQ is ready.</p>
                <p className="text-xs text-muted-foreground/50 max-w-xs">Start planning your million-dollar move. Every message counts.</p>
              </div>
            )}
            {messages.map(msg => (
              <MessageBubble
                key={msg.id}
                msg={msg}
                isOwn={msg.firebase_uid === firebaseUid}
                isAdmin={isAdmin}
                onReply={setReplyTo}
                onPin={pinMessage}
                onConvert={convertToActionPlan}
                onDelete={deleteMessage}
                convertingId={convertingId}
                actionPlan={actionPlans[msg.id] ?? null}
                authorName={displayName}
                authorUid={firebaseUid}
              />
            ))}
            {/* Typing indicator */}
            {typingNames.length > 0 && (
              <div className="flex items-center gap-2 px-2">
                <div className="flex gap-0.5">
                  {[0,1,2].map(i => (
                    <span key={i} className="h-1.5 w-1.5 rounded-full bg-muted-foreground/50 animate-bounce"
                      style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
                <span className="text-[11px] text-muted-foreground/60 italic">
                  {typingNames.join(', ')} {typingNames.length === 1 ? 'is' : 'are'} typing...
                </span>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Reply bar */}
          {replyTo && (
            <div className="shrink-0 mx-3 mb-1 flex items-start gap-2 px-3 py-2 rounded-xl bg-primary/8 border border-primary/25">
              <CornerDownLeft className="h-3.5 w-3.5 text-primary/70 mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-[11px] font-semibold text-primary/80">{replyTo.display_name}</p>
                <p className="text-[11px] text-muted-foreground truncate">{replyTo.message_text.slice(0, REPLY_MAX)}</p>
              </div>
              <button onClick={() => setReplyTo(null)} className="shrink-0 text-muted-foreground/50 hover:text-foreground transition-colors">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {/* Input bar */}
          <div className="shrink-0 px-4 md:px-6 pb-5 pt-3">
            <div className="flex items-end gap-3 rounded-2xl bg-secondary/50 border border-white/10 px-4 py-3 focus-within:border-primary/40 transition-all">
              <textarea
                value={input}
                onChange={e => { setInput(e.target.value); broadcastTyping(); }}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                rows={1}
                placeholder='Plan, ideate, execute… · Type "announce <message>" to broadcast a banner'
                className="flex-1 min-w-0 resize-none bg-transparent text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none leading-relaxed max-h-24 overflow-y-auto"
                style={{ scrollbarWidth: 'none' }}
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim() || sending}
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary hover:bg-primary/90 transition-all disabled:opacity-40 shrink-0 shadow-[0_0_12px_hsl(var(--primary)/0.3)]"
              >
                {sending ? <Loader2 className="h-4 w-4 animate-spin text-primary-foreground" /> : <Send className="h-4 w-4 text-primary-foreground" />}
              </button>
            </div>
            <p className="text-center text-[10px] text-muted-foreground/25 mt-1.5">
              Hover for actions · Swipe right to reply · Type "announce …" to broadcast · Enter to send
            </p>
          </div>
        </>
      )}
    </div>
  );
}
