import LoginModal from '@/components/auth/LoginModal';
import PageMeta from '@/components/common/PageMeta';

export default function LoginPage() {
  return (
    <>
      <PageMeta title="Sign In" description="Secure access to AlphaTekx AI Operating System" />
      <LoginModal />
    </>
  );
}
