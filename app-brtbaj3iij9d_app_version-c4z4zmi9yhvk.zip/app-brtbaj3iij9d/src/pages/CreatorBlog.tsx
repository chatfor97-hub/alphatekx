import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { useUserSession } from '@/contexts/UserSessionContext';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import {
  PenLine, ArrowLeft, Search, Tag, X, Loader2, Image,
  Calendar, User, Trash2, Edit3, BookOpen, Plus, ChevronDown,
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────────────────────
interface BlogPost {
  id:            string;
  firebase_uid:  string;
  author_name:   string;
  author_avatar: string | null;
  title:         string;
  body:          string;
  cover_url:     string | null;
  tags:          string[];
  category:      string;
  created_at:    string;
  updated_at:    string;
}

type View = 'list' | 'read' | 'compose';

const CATEGORIES = ['General', 'YouTube Growth', 'Milestones', 'Tips & Tricks', 'Behind the Scenes', 'Gear & Setup', 'Monetization'];
const PAGE_SIZE  = 20;

// ── Helpers ────────────────────────────────────────────────────────────────────
function timeAgo(iso: string) {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60)     return 'just now';
  if (diff < 3600)   return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400)  return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function AuthorAvatar({ url, name, size = 8 }: { url?: string | null; name: string; size?: number }) {
  const base = `h-${size} w-${size} rounded-xl shrink-0`;
  if (url) return <img src={url} alt={name} className={`${base} object-cover border border-border/50`} />;
  return (
    <div className={`${base} flex items-center justify-center bg-primary/10 border border-primary/20`}>
      <span className="text-primary font-black text-xs uppercase">{name.charAt(0)}</span>
    </div>
  );
}

function TagBadge({ label, active, onClick }: { label: string; active?: boolean; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
        active
          ? 'bg-primary text-primary-foreground'
          : 'bg-primary/10 text-primary/80 border border-primary/20 hover:bg-primary/20'
      }`}
    >
      {label}
    </button>
  );
}

// ── Post Card ──────────────────────────────────────────────────────────────────
function PostCard({ post, onClick }: { post: BlogPost; onClick: () => void }) {
  return (
    <div
      onClick={onClick}
      className="group cursor-pointer rounded-2xl border border-border/50 bg-card hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-200 overflow-hidden animate-in fade-in duration-200"
    >
      {post.cover_url && (
        <div className="aspect-video w-full overflow-hidden">
          <img
            src={post.cover_url}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
          />
        </div>
      )}
      <div className="p-5 space-y-3">
        {/* Category + tags */}
        <div className="flex flex-wrap gap-1.5">
          <TagBadge label={post.category} />
          {post.tags.slice(0, 2).map(t => (
            <TagBadge key={t} label={t} />
          ))}
        </div>

        {/* Title */}
        <h3 className="text-base font-black text-foreground leading-snug text-balance group-hover:text-primary transition-colors line-clamp-2">
          {post.title}
        </h3>

        {/* Excerpt */}
        <p className="text-sm text-muted-foreground leading-relaxed text-pretty line-clamp-3">
          {post.body.slice(0, 180)}{post.body.length > 180 ? '…' : ''}
        </p>

        {/* Author + date */}
        <div className="flex items-center gap-2.5 pt-1">
          <AuthorAvatar url={post.author_avatar} name={post.author_name} size={7} />
          <div className="min-w-0">
            <p className="text-xs font-bold text-foreground truncate">{post.author_name}</p>
            <p className="text-[10px] text-muted-foreground/50">{timeAgo(post.created_at)}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Composer ───────────────────────────────────────────────────────────────────
function PostComposer({
  editPost, senderUid, authorName, authorAvatar,
  onPublished, onCancel,
}: {
  editPost:      BlogPost | null;
  senderUid:     string;
  authorName:    string;
  authorAvatar:  string | null;
  onPublished:   (post: BlogPost) => void;
  onCancel:      () => void;
}) {
  const [title,      setTitle]      = useState(editPost?.title      ?? '');
  const [body,       setBody]        = useState(editPost?.body       ?? '');
  const [category,   setCategory]   = useState(editPost?.category   ?? 'General');
  const [tagInput,   setTagInput]   = useState(editPost?.tags.join(', ') ?? '');
  const [coverFile,  setCoverFile]  = useState<File | null>(null);
  const [coverPrev,  setCoverPrev]  = useState<string | null>(editPost?.cover_url ?? null);
  const [saving,     setSaving]     = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.type.startsWith('image/')) { toast.error('Only images are supported.'); return; }
    if (f.size > 4 * 1024 * 1024)    { toast.error('Image must be under 4 MB.'); return; }
    setCoverFile(f);
    setCoverPrev(URL.createObjectURL(f));
  }

  async function uploadCover(file: File): Promise<string | null> {
    const ext  = file.name.split('.').pop() ?? 'jpg';
    const path = `covers/${senderUid}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from('blog-covers').upload(path, file, { contentType: file.type });
    if (error) { toast.error('Cover upload failed.'); return null; }
    const { data } = supabase.storage.from('blog-covers').getPublicUrl(path);
    return data.publicUrl;
  }

  async function handleSubmit() {
    if (!title.trim())  { toast.error('Title is required.'); return; }
    if (!body.trim())   { toast.error('Body is required.'); return; }
    setSaving(true);

    let coverUrl = editPost?.cover_url ?? null;
    if (coverFile) {
      coverUrl = await uploadCover(coverFile);
      if (!coverUrl) { setSaving(false); return; }
    }

    const tags = tagInput.split(',').map(t => t.trim()).filter(Boolean);
    const payload = {
      firebase_uid:  senderUid,
      author_name:   authorName,
      author_avatar: authorAvatar,
      title:         title.trim(),
      body:          body.trim(),
      cover_url:     coverUrl,
      tags,
      category,
    };

    if (editPost) {
      const { data, error } = await supabase
        .from('creator_blog_posts').update(payload).eq('id', editPost.id).select().maybeSingle();
      if (error || !data) { toast.error('Update failed. Try again.'); setSaving(false); return; }
      toast.success('Post updated!');
      onPublished(data as BlogPost);
    } else {
      const { data, error } = await supabase
        .from('creator_blog_posts').insert(payload).select().maybeSingle();
      if (error || !data) { toast.error('Publish failed. Try again.'); setSaving(false); return; }
      toast.success('Post published!');
      onPublished(data as BlogPost);
    }
    setSaving(false);
  }

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Header */}
      <div className="shrink-0 flex items-center gap-3 px-4 md:px-6 py-4 border-b border-border/40">
        <button onClick={onCancel} className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors text-sm font-bold">
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <span className="text-sm font-black text-foreground ml-2">{editPost ? 'Edit Post' : 'New Post'}</span>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar px-4 md:px-6 py-6">
        <div className="max-w-2xl mx-auto space-y-5">

          {/* Cover image */}
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest block mb-2">Cover Image (optional)</label>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
            {coverPrev ? (
              <div className="relative rounded-xl overflow-hidden aspect-video border border-border/50">
                <img src={coverPrev} alt="Cover preview" className="w-full h-full object-cover" />
                <button
                  onClick={() => { setCoverFile(null); setCoverPrev(null); if (fileRef.current) fileRef.current.value = ''; }}
                  className="absolute top-2 right-2 h-7 w-7 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center border border-border/60 text-foreground hover:bg-destructive hover:text-destructive-foreground transition-all"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileRef.current?.click()}
                className="w-full flex flex-col items-center gap-2 py-8 rounded-xl border-2 border-dashed border-border/50 hover:border-primary/40 text-muted-foreground hover:text-primary transition-all"
              >
                <Image className="h-6 w-6" />
                <span className="text-xs font-bold">Click to upload cover image</span>
              </button>
            )}
          </div>

          {/* Title */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Title *</label>
            <input
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Your post title…"
              className="w-full rounded-xl border border-border/60 bg-secondary/40 px-4 py-3 text-base font-black text-foreground placeholder:text-muted-foreground/40 outline-none focus:border-primary/60 focus:ring-1 focus:ring-primary/20 transition-all"
            />
          </div>

          {/* Body */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Content *</label>
            <textarea
              value={body}
              onChange={e => setBody(e.target.value)}
              placeholder="Share your progress, insights, or story…"
              rows={12}
              className="w-full rounded-xl border border-border/60 bg-secondary/40 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/40 outline-none focus:border-primary/60 focus:ring-1 focus:ring-primary/20 transition-all resize-y leading-relaxed custom-scrollbar font-medium min-h-[180px]"
            />
          </div>

          {/* Category */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Category</label>
            <div className="relative">
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full appearance-none rounded-xl border border-border/60 bg-secondary/40 px-4 py-3 text-sm font-bold text-foreground outline-none focus:border-primary/60 transition-all pr-10"
              >
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            </div>
          </div>

          {/* Tags */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Tags (comma-separated)</label>
            <input
              value={tagInput}
              onChange={e => setTagInput(e.target.value)}
              placeholder="e.g. vlog, youtube, growth"
              className="w-full rounded-xl border border-border/60 bg-secondary/40 px-4 py-3 text-sm font-medium text-foreground placeholder:text-muted-foreground/40 outline-none focus:border-primary/60 focus:ring-1 focus:ring-primary/20 transition-all"
            />
          </div>

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={!title.trim() || !body.trim() || saving}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-primary text-primary-foreground font-black text-sm shadow-lg shadow-primary/20 hover:bg-primary/90 active:scale-[0.98] transition-all disabled:opacity-40"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <PenLine className="h-4 w-4" />}
            {saving ? 'Saving…' : editPost ? 'Update Post' : 'Publish Post'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Single Post View ───────────────────────────────────────────────────────────
function PostView({
  post, isOwn, isAdmin, onBack, onEdit, onDelete,
}: {
  post:    BlogPost;
  isOwn:   boolean;
  isAdmin: boolean;
  onBack:  () => void;
  onEdit:  () => void;
  onDelete: () => void;
}) {
  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="shrink-0 flex items-center justify-between gap-3 px-4 md:px-6 py-4 border-b border-border/40">
        <button onClick={onBack} className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors text-sm font-bold">
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        {(isOwn || isAdmin) && (
          <div className="flex items-center gap-2">
            <button onClick={onEdit} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-secondary/60 border border-border/40 text-muted-foreground hover:text-foreground transition-all">
              <Edit3 className="h-3.5 w-3.5" /> Edit
            </button>
            <button onClick={onDelete} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-destructive/10 border border-destructive/20 text-destructive hover:bg-destructive/20 transition-all">
              <Trash2 className="h-3.5 w-3.5" /> Delete
            </button>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar px-4 md:px-6 py-6">
        <article className="max-w-2xl mx-auto space-y-6">
          {post.cover_url && (
            <div className="aspect-video w-full rounded-2xl overflow-hidden border border-border/50">
              <img src={post.cover_url} alt={post.title} className="w-full h-full object-cover" />
            </div>
          )}

          {/* Tags + category */}
          <div className="flex flex-wrap gap-1.5">
            <TagBadge label={post.category} />
            {post.tags.map(t => <TagBadge key={t} label={t} />)}
          </div>

          {/* Title */}
          <h1 className="text-2xl md:text-3xl font-black text-foreground text-balance leading-tight">{post.title}</h1>

          {/* Meta */}
          <div className="flex items-center gap-3 py-3 border-y border-border/30">
            <AuthorAvatar url={post.author_avatar} name={post.author_name} size={9} />
            <div>
              <p className="text-sm font-black text-foreground">{post.author_name}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground/60">
                <Calendar className="h-3 w-3" />
                {new Date(post.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </div>
            </div>
          </div>

          {/* Body */}
          <div className="prose prose-sm max-w-none text-foreground">
            {post.body.split('\n').map((para, i) =>
              para.trim()
                ? <p key={i} className="text-sm md:text-base leading-relaxed text-pretty mb-4 last:mb-0">{para}</p>
                : <br key={i} />
            )}
          </div>
        </article>
      </div>
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────
export default function CreatorBlog() {
  const { appUser } = useUserSession();
  const firebaseUid = appUser?.uid ?? '';
  const authorName  = appUser?.display_name || appUser?.email || 'Creator';
  const authorAvatar = appUser?.photo_url ?? null;
  const isAdmin     = appUser?.role === 'admin';

  const [view,        setView]        = useState<View>('list');
  const [posts,       setPosts]       = useState<BlogPost[]>([]);
  const [loading,     setLoading]     = useState(true);
  const [hasMore,     setHasMore]     = useState(true);
  const [search,      setSearch]      = useState('');
  const [filterTag,   setFilterTag]   = useState('');
  const [activePost,  setActivePost]  = useState<BlogPost | null>(null);
  const [editPost,    setEditPost]    = useState<BlogPost | null>(null);
  const oldestAt      = useRef<string | null>(null);
  const loadingMore   = useRef(false);

  // ── Fetch posts ──────────────────────────────────────────────────────────
  const fetchPosts = useCallback(async (reset = true) => {
    if (reset) setLoading(true);
    let q = supabase
      .from('creator_blog_posts')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(PAGE_SIZE);

    if (reset && oldestAt.current) {
      oldestAt.current = null;
    }

    if (!reset && oldestAt.current) {
      q = q.lt('created_at', oldestAt.current);
    }

    const { data } = await q;
    const rows = (data ?? []) as BlogPost[];

    if (rows.length > 0) oldestAt.current = rows[rows.length - 1].created_at;
    if (rows.length < PAGE_SIZE) setHasMore(false);

    setPosts(prev => reset ? rows : [...prev, ...rows]);
    if (reset) setLoading(false);
    loadingMore.current = false;
  }, []);

  useEffect(() => { fetchPosts(true); }, [fetchPosts]);

  // ── Realtime: new posts appear instantly ─────────────────────────────────
  useEffect(() => {
    const ch = supabase
      .channel('creator-blog-feed')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'creator_blog_posts' }, (payload) => {
        const newPost = payload.new as BlogPost;
        setPosts(prev => {
          if (prev.some(p => p.id === newPost.id)) return prev;
          return [newPost, ...prev];
        });
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'creator_blog_posts' }, (payload) => {
        const updated = payload.new as BlogPost;
        setPosts(prev => prev.map(p => p.id === updated.id ? updated : p));
        setActivePost(prev => prev?.id === updated.id ? updated : prev);
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'creator_blog_posts' }, (payload) => {
        const id = (payload.old as { id: string }).id;
        setPosts(prev => prev.filter(p => p.id !== id));
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  // ── Delete ────────────────────────────────────────────────────────────────
  async function handleDelete(post: BlogPost) {
    if (!window.confirm(`Delete "${post.title}"? This cannot be undone.`)) return;
    const { error } = await supabase.from('creator_blog_posts').delete().eq('id', post.id);
    if (error) { toast.error('Delete failed.'); return; }
    toast.success('Post deleted.');
    setView('list');
    setActivePost(null);
  }

  // ── Load more ─────────────────────────────────────────────────────────────
  async function loadMore() {
    if (loadingMore.current || !hasMore) return;
    loadingMore.current = true;
    await fetchPosts(false);
  }

  // ── Filtered display list ─────────────────────────────────────────────────
  const filtered = posts.filter(p => {
    const matchSearch = !search || p.title.toLowerCase().includes(search.toLowerCase()) || p.body.toLowerCase().includes(search.toLowerCase());
    const matchTag    = !filterTag || p.tags.includes(filterTag) || p.category === filterTag;
    return matchSearch && matchTag;
  });

  // Collect all unique tags for filter bar
  const allTags = Array.from(new Set(posts.flatMap(p => [p.category, ...p.tags]))).slice(0, 12);

  // ── Render ────────────────────────────────────────────────────────────────
  if (view === 'compose') {
    return (
      <>
        <PageMeta title="New Post — Creator Blog — AlphaTekx AI" description="Share your YouTube creator progress, milestones and tips with the AlphaTekx AI community." />
        <PostComposer
          editPost={editPost}
          senderUid={firebaseUid}
          authorName={authorName}
          authorAvatar={authorAvatar}
          onPublished={(post) => {
            setView('read');
            setActivePost(post);
            setEditPost(null);
          }}
          onCancel={() => { setView(activePost ? 'read' : 'list'); setEditPost(null); }}
        />
      </>
    );
  }

  if (view === 'read' && activePost) {
    return (
      <>
        <PageMeta title={`${activePost.title} — AlphaTekx Creator Blog`} description={activePost.body.slice(0, 160)} />
        <PostView
          post={activePost}
          isOwn={activePost.firebase_uid === firebaseUid}
          isAdmin={isAdmin}
          onBack={() => setView('list')}
          onEdit={() => { setEditPost(activePost); setView('compose'); }}
          onDelete={() => handleDelete(activePost)}
        />
      </>
    );
  }

  return (
    <>
      <PageMeta
        title="Creator Blog — AlphaTekx AI"
        description="Read and share YouTube creator progress, tips, and milestones on the AlphaTekx AI Creator Blog. Join a community of creators powered by AI."
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://alphatekx.name.ng/" },
            { "@type": "ListItem", "position": 2, "name": "Creator Blog", "item": "https://alphatekx.name.ng/tools/creator-blog" },
          ],
        }) }}
      />

      <div className="flex flex-col h-full min-h-0 overflow-hidden">

        {/* ── Header ── */}
        <div className="shrink-0 flex items-center justify-between gap-3 px-4 md:px-6 py-4 border-b border-border/40 bg-background/80 backdrop-blur-sm">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 border border-primary/20 shrink-0">
              <BookOpen className="h-4.5 w-4.5 text-primary" style={{ height: '1.125rem', width: '1.125rem' }} />
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-black tracking-tight text-foreground uppercase leading-none">Creator Blog</h1>
              <p className="text-[10px] text-muted-foreground/50 font-bold uppercase tracking-widest mt-0.5">Free · Share your journey</p>
            </div>
          </div>
          {firebaseUid && (
            <button
              onClick={() => { setEditPost(null); setView('compose'); }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-xs font-black shadow-lg shadow-primary/20 hover:bg-primary/90 active:scale-95 transition-all shrink-0"
            >
              <Plus className="h-3.5 w-3.5" /> New Post
            </button>
          )}
        </div>

        {/* ── Search + tag filters ── */}
        <div className="shrink-0 px-4 md:px-6 py-3 border-b border-border/30 space-y-2.5">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/40 pointer-events-none" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search posts…"
              className="w-full rounded-xl border border-border/50 bg-secondary/40 pl-9 pr-9 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/40 outline-none focus:border-primary/50 transition-all font-medium"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/40 hover:text-foreground transition-colors">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {allTags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 overflow-x-auto whitespace-nowrap pb-0.5">
              {filterTag && (
                <button
                  onClick={() => setFilterTag('')}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-secondary/60 border border-border/40 text-muted-foreground hover:text-foreground transition-all"
                >
                  <X className="h-2.5 w-2.5" /> Clear
                </button>
              )}
              {allTags.map(tag => (
                <TagBadge key={tag} label={tag} active={filterTag === tag} onClick={() => setFilterTag(filterTag === tag ? '' : tag)} />
              ))}
            </div>
          )}
        </div>

        {/* ── Posts feed ── */}
        <div className="flex-1 overflow-y-auto custom-scrollbar px-4 md:px-6 py-5">

          {/* Loading */}
          {loading && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="rounded-2xl border border-border/30 bg-card overflow-hidden animate-pulse">
                  <div className="aspect-video bg-muted" />
                  <div className="p-5 space-y-3">
                    <div className="h-3 w-20 bg-muted rounded-full" />
                    <div className="h-5 w-4/5 bg-muted rounded-full" />
                    <div className="h-3 w-full bg-muted rounded-full" />
                    <div className="h-3 w-3/4 bg-muted rounded-full" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Empty state */}
          {!loading && filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 border border-primary/20">
                <PenLine className="h-8 w-8 text-primary" />
              </div>
              <div className="text-center space-y-1">
                <p className="text-base font-black text-foreground">
                  {search || filterTag ? 'No posts match your search' : 'No posts yet'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {firebaseUid && !search && !filterTag
                    ? 'Be the first creator to share your journey!'
                    : 'Try adjusting your search or filters.'}
                </p>
              </div>
              {firebaseUid && !search && !filterTag && (
                <button
                  onClick={() => { setEditPost(null); setView('compose'); }}
                  className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-black shadow-lg shadow-primary/20 hover:bg-primary/90 transition-all"
                >
                  <Plus className="h-4 w-4" /> Write First Post
                </button>
              )}
            </div>
          )}

          {/* Post grid */}
          {!loading && filtered.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filtered.map(post => (
                <PostCard
                  key={post.id}
                  post={post}
                  onClick={() => { setActivePost(post); setView('read'); }}
                />
              ))}
            </div>
          )}

          {/* Load more */}
          {hasMore && !loading && filtered.length > 0 && (
            <div className="flex justify-center mt-6">
              <button
                onClick={loadMore}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-secondary/60 border border-border/40 text-sm font-bold text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-all"
              >
                <ChevronDown className="h-4 w-4" /> Load more posts
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
