import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import {
  Shield, Zap, Globe, BookOpen, Palette, Video,
  Headphones, Image, ChevronRight, CheckCircle2,
  ArrowRight, Star, Users, Activity, Lock,
  BarChart3, Menu, X, Code2,
  GraduationCap, Briefcase, Mic2, Wand2,
  ChevronDown, Mail, Send, CircleHelp,
  TrendingUp, Clock, DollarSign,
  ShieldCheck, KeyRound, Database, Server,
  Eye, Fingerprint, AlertTriangle, Wifi,
} from "lucide-react";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { supabase } from "@/db/supabase";
import { toast } from "sonner";
import PageMeta from "@/components/common/PageMeta";
import { useOnlineCount, formatLiveCount } from "@/hooks/use-online-count";

/* ══════════════════════════════════════════════════
   ANIMATED COUNTER
══════════════════════════════════════════════════ */
function AnimatedCounter({ end, suffix = "", prefix = "" }: { end: number; suffix?: string; prefix?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return;
        observer.disconnect();
        const duration = 1800;
        const startTime = performance.now();
        function step(now: number) {
          const progress = Math.min((now - startTime) / duration, 1);
          const ease = 1 - Math.pow(1 - progress, 3);
          setVal(Math.floor(ease * end));
          if (progress < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [end]);

  return <span ref={ref}>{prefix}{val.toLocaleString()}{suffix}</span>;
}

/* ══════════════════════════════════════════════════
   REVEAL WRAPPER — wraps any section with fade+rise
══════════════════════════════════════════════════ */
function Reveal({ children, delay = 0, className = "" }: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const { ref, visible } = useScrollReveal();
  return (
    <div
      ref={ref}
      className={`transition-[opacity,transform] duration-700 ease-out ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      } ${className}`}
      style={{
        transitionDelay: `${delay}ms`,
        /* Promote to own compositor layer so the opacity+translate animation
           does not trigger repaints on child cards (fixes pricing card flicker) */
        willChange: visible ? "auto" : "opacity, transform",
        backfaceVisibility: "hidden",
        WebkitBackfaceVisibility: "hidden",
      }}
    >
      {children}
    </div>
  );
}

/* ══════════════════════════════════════════════════
   DATA
══════════════════════════════════════════════════ */
const FEATURES = [
  { icon: Globe,     title: "Website Builder",   desc: "Launch production-ready websites with AI-powered layout generation and one-click deploy." },
  { icon: BookOpen,  title: "Exam Prep Engine",  desc: "Automated question synthesis, study plans, and performance tracking powered by LLM reasoning." },
  { icon: Palette,   title: "Art Generator",     desc: "Studio-quality visuals from text prompts. Concept art, product shots, and brand identity." },
  { icon: Video,     title: "Video Generator",   desc: "Script-to-cinematic-video pipeline. High-fidelity AI production at enterprise scale." },
  { icon: Headphones,title: "Voice Gen",         desc: "Hyper-realistic voice synthesis. Narrations, ads, and podcasts — zero recording studio." },
  { icon: Image,     title: "Thumbnail Studio",  desc: "Conversion-optimised thumbnails tailored to your brand in seconds, not hours." },
  { icon: Code2,     title: "Script Writer",     desc: "AI-authored scripts for YouTube, TikTok, ads, and long-form video — ready to shoot." },
  { icon: Lock,      title: "Contract Guard",    desc: "Legal document analysis and risk assessment. Know what you're signing before you sign." },
];

const STATS = [
  { value: 8,   suffix: "+",  label: "AI Tools Integrated" },
  { value: 99,  suffix: "%",  label: "Uptime Guaranteed" },
  { value: 50,  suffix: "K+", label: "Prompts Processed" },
  { value: 3,   suffix: "×",  label: "Faster Than Competitors" },
];

const USE_CASES = [
  {
    icon: GraduationCap,
    audience: "Students & Researchers",
    headline: "Ace every exam. Publish faster.",
    points: [
      "Generate custom exam questions from any topic",
      "Synthesise research papers in minutes",
      "Build academic portfolios with AI art",
      "Convert lecture notes into voice summaries",
    ],
    color: "from-blue-500/10 to-primary/5",
    border: "border-blue-500/20",
  },
  {
    icon: Wand2,
    audience: "Content Creators",
    headline: "Create more. Stress less.",
    points: [
      "Script, record, and thumbnail in one session",
      "Generate viral-ready short-form video",
      "Produce studio-quality voice-overs instantly",
      "Design thumbnails that drive clicks",
    ],
    color: "from-violet-500/10 to-primary/5",
    border: "border-violet-500/20",
  },
  {
    icon: Briefcase,
    audience: "Business Owners",
    headline: "Run leaner. Scale faster.",
    points: [
      "Launch your website without a dev agency",
      "Review contracts without a lawyer on retainer",
      "Automate marketing content pipelines",
      "Cut tool subscriptions from 6 to 1",
    ],
    color: "from-emerald-500/10 to-primary/5",
    border: "border-emerald-500/20",
  },
  {
    icon: Mic2,
    audience: "Agencies & Teams",
    headline: "Deliver in days, not weeks.",
    points: [
      "Ship client deliverables 3× faster",
      "Centralise AI production for your whole team",
      "Brand-consistent outputs every time",
      "Enterprise SLA available",
    ],
    color: "from-orange-500/10 to-primary/5",
    border: "border-orange-500/20",
  },
];

const PRICING = [
  {
    name: "Starter Pack",
    price: "$1",
    period: "",
    credits: "50 Credits",
    desc: "Try the full power of AlphaTekx.",
    features: [
      "50 AI credits",
      "Access to all 8 tools",
      "Instant top-up",
      "No subscription required",
    ],
    cta: "Buy Starter Pack",
    highlight: false,
  },
  {
    name: "Pro Pack",
    price: "$5",
    period: "",
    credits: "300 Credits",
    desc: "Best value for creators & students.",
    features: [
      "300 AI credits",
      "Access to all 8 tools",
      "Priority AI processing",
      "Instant top-up",
      "No subscription required",
    ],
    cta: "Buy Pro Pack",
    highlight: true,
  },
  {
    name: "Power Pack",
    price: "$10",
    period: "",
    credits: "700 Credits",
    desc: "For professionals who don't stop.",
    features: [
      "700 AI credits",
      "Access to all 8 tools",
      "Priority AI processing",
      "Advanced analytics",
      "No subscription required",
    ],
    cta: "Buy Power Pack",
    highlight: false,
  },
  {
    name: "Elite Pack",
    price: "$50",
    period: "",
    credits: "3,500 Credits",
    desc: "Maximum firepower. Best rate per credit.",
    features: [
      "3,500 AI credits",
      "Access to all 8 tools",
      "Priority AI processing",
      "Best value per credit",
      "No subscription required",
    ],
    cta: "Buy Elite Pack",
    highlight: false,
    badge: "🔥 Best Value",
  },
];

const TESTIMONIALS = [
  {
    quote: "AlphaTekx replaced 6 different subscriptions for me. It's the only AI platform I actually stick with.",
    name: "Marcus T.",
    role: "Digital Creator",
    stars: 5,
  },
  {
    quote: "The Exam Prep Engine alone saved me 3 hours a day during exam season. This thing is unreal.",
    name: "Aisha M.",
    role: "Graduate Researcher",
    stars: 5,
  },
  {
    quote: "Our agency went from 2-week deliverables to 2-day turnaround. AlphaTekx is the infrastructure we needed.",
    name: "Jordan K.",
    role: "Creative Agency Director",
    stars: 5,
  },
];

const FAQS = [
  {
    q: "Is AlphaTekx really free to start?",
    a: "Yes — you get 30 AI credits the moment you sign up, no credit card required. When you're ready to go further, top up with a credit pack starting at just $1 for 50 credits.",
  },
  {
    q: "What makes AlphaTekx different from ChatGPT or other AI tools?",
    a: "ChatGPT is a chat tool. AlphaTekx is an operating system. We give you 8 purpose-built, specialised AI tools in one place — from cinematic video generation to legal contract analysis. Each tool is engineered for a specific output, not just conversation.",
  },
  {
    q: "Do I need technical skills to use AlphaTekx?",
    a: "Zero. Every tool is designed for non-technical users. If you can type a sentence, you can use AlphaTekx. Our interface is built for speed and clarity — not for engineers.",
  },
  {
    q: "How do credits work?",
    a: "Credits are consumed when you use any AI tool. Different tasks use different amounts depending on complexity. You buy credits in one-time packs — $1 for 50 credits, $5 for 300 credits, $10 for 700 credits, or $50 for 3,500 credits (best value). Credits never expire and work across all 8 AI tools.",
  },
  {
    q: "Is there a monthly subscription?",
    a: "No. AlphaTekx uses a pay-as-you-go credit model — there are no recurring subscriptions, no hidden fees, and no contracts. Buy credits when you need them, use them at your own pace, and top up anytime.",
  },
  {
    q: "Is my data safe and private?",
    a: "Your data is encrypted in transit and at rest. We do not use your prompts or outputs to train any models. Your intellectual property stays yours.",
  },
];

/* ══════════════════════════════════════════════════
   FAQ ITEM
══════════════════════════════════════════════════ */
function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`faq-item${open ? " faq-open" : ""}`}>
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between gap-3 px-4 md:px-6 py-4 md:py-5 text-left"
      >
        <span className="text-sm md:text-base font-bold text-white leading-snug pr-2">{q}</span>
        <ChevronDown
          className={`h-4 w-4 md:h-5 md:w-5 text-primary shrink-0 transition-transform duration-200 ${open ? "rotate-180" : ""}`}
        />
      </button>
      {/* Use grid-rows trick: composites on GPU, never triggers layout */}
      <div className={`grid transition-[grid-template-rows] duration-200 ease-out ${open ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}>
        <div className="overflow-hidden">
          <p className="px-4 md:px-6 pb-4 md:pb-5 text-xs md:text-sm text-slate-400 leading-relaxed">{a}</p>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════
   WAITLIST FORM
══════════════════════════════════════════════════ */
function WaitlistForm() {
  const [email, setEmail]         = useState("");
  const [honeypot, setHoneypot]   = useState(""); // bot trap — must stay empty
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading]     = useState(false);
  const formLoadedAt              = useRef(Date.now());

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = email.trim();
    if (!trimmed || !trimmed.includes("@")) return;

    // ── Security gates ────────────────────────────────────────────────────
    // 1. Honeypot: bots fill hidden fields, humans never see them
    if (honeypot.trim().length > 0) {
      // Silently succeed — don't tell bots they were caught
      setSubmitted(true);
      return;
    }

    // 2. Timing guard: submission under 1.5s = bot
    if (Date.now() - formLoadedAt.current < 1500) {
      toast.error("Please wait a moment before submitting.");
      return;
    }

    // 3. Client-side rate limit: max 3 attempts per 5 minutes
    const { checkClientRateLimit } = await import("@/lib/security");
    if (!checkClientRateLimit("waitlist-submit", 3, 300_000)) {
      toast.error("Too many attempts. Please try again in a few minutes.");
      return;
    }

    // 4. Input threat scan
    const { detectThreat, sanitizeInput } = await import("@/lib/security");
    const safeEmail = sanitizeInput(trimmed);
    if (detectThreat(safeEmail)) {
      toast.error("Invalid input detected.");
      return;
    }
    // ─────────────────────────────────────────────────────────────────────

    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke("send-waitlist-email", {
        body: { email: safeEmail },
      });

      if (error) {
        const msg = await error?.context?.text?.();
        console.error("waitlist error:", msg || error.message);
        toast.error("Something went wrong. Please try again.");
        return;
      }

      setSubmitted(true);
      toast.success("You're on the list! Check your inbox for a confirmation.");
    } catch (err) {
      console.error("waitlist error:", err);
      toast.error("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  if (submitted) {
    return (
      <div className="flex flex-col items-center gap-4 py-4 animate-slide-up">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 border border-primary/30">
          <CheckCircle2 className="h-7 w-7 text-primary" />
        </div>
        <p className="text-lg font-black text-white uppercase tracking-wide">You're on the list.</p>
        <p className="text-sm text-slate-400">Check your inbox — a confirmation is on its way.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 w-full max-w-md mx-auto">
      {/* Honeypot field — hidden from real users, bots fill it automatically */}
      <input
        type="text"
        name="website"
        value={honeypot}
        onChange={e => setHoneypot(e.target.value)}
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
        style={{ position: "absolute", left: "-9999px", width: "1px", height: "1px", opacity: 0 }}
      />
      <div className="flex-1 relative min-w-0">
        <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500 pointer-events-none" />
        <input
          type="email"
          required
          value={email}
          onChange={e => setEmail(e.target.value)}
          placeholder="Enter your email address"
          className="w-full h-12 pl-10 pr-3 rounded-xl bg-secondary border border-border/60 text-white placeholder:text-slate-500 text-sm font-medium focus:outline-none focus:border-primary/60 transition-colors"
        />
      </div>
      <button
        type="submit"
        disabled={loading}
        className="btn-neon h-12 px-5 md:px-6 rounded-xl text-sm shrink-0 flex items-center gap-2 justify-center disabled:opacity-60"
      >
        {loading
          ? <span className="h-4 w-4 rounded-full border-2 border-black/40 border-t-black animate-spin" />
          : <><Send className="h-4 w-4" /> Join Waitlist</>
        }
      </button>
    </form>
  );
}

/* ══════════════════════════════════════════════════
   FIREWALL SECURITY SECTION
══════════════════════════════════════════════════ */

// Threat dots that fly into center and get destroyed
const THREAT_DOTS = [
  { id: 1, cx: "12%",  cy: "18%",  delay: "0s",    dur: "3.2s",  tx: "-120px", ty: "-80px"  },
  { id: 2, cx: "82%",  cy: "22%",  delay: "0.8s",  dur: "2.8s",  tx: "110px",  ty: "-90px"  },
  { id: 3, cx: "90%",  cy: "55%",  delay: "1.6s",  dur: "3.5s",  tx: "130px",  ty: "20px"   },
  { id: 4, cx: "78%",  cy: "84%",  delay: "2.4s",  dur: "2.9s",  tx: "100px",  ty: "90px"   },
  { id: 5, cx: "18%",  cy: "80%",  delay: "3.0s",  dur: "3.1s",  tx: "-110px", ty: "85px"   },
  { id: 6, cx: "8%",   cy: "48%",  delay: "3.8s",  dur: "2.7s",  tx: "-125px", ty: "10px"   },
  { id: 7, cx: "50%",  cy: "5%",   delay: "1.2s",  dur: "3.0s",  tx: "0px",    ty: "-140px" },
  { id: 8, cx: "50%",  cy: "95%",  delay: "4.2s",  dur: "3.3s",  tx: "0px",    ty: "140px"  },
];

const SECURITY_LAYERS = [
  {
    icon: KeyRound,
    title: "Firebase Auth + 2FA",
    desc: "Industry-grade identity verification. Every session is cryptographically signed. Google OAuth + multi-factor ready.",
    status: "ACTIVE",
    color: "text-cyan-400",
    glow: "rgba(34,211,238,0.15)",
  },
  {
    icon: Database,
    title: "Row-Level Security (RLS)",
    desc: "Supabase RLS policies enforce that every user can only ever read or write their own data. Zero data leakage by design.",
    status: "ENFORCED",
    color: "text-emerald-400",
    glow: "rgba(52,211,153,0.15)",
  },
  {
    icon: Lock,
    title: "AES-256 + TLS 1.3",
    desc: "All data is encrypted at rest with AES-256 and in transit with TLS 1.3. Your secrets never travel in plain text.",
    status: "ENCRYPTED",
    color: "text-violet-400",
    glow: "rgba(167,139,250,0.15)",
  },
  {
    icon: Server,
    title: "Edge Function Isolation",
    desc: "Every third-party API key lives exclusively in Supabase Edge Function secrets — never exposed to the browser.",
    status: "ISOLATED",
    color: "text-amber-400",
    glow: "rgba(251,191,36,0.15)",
  },
  {
    icon: ShieldCheck,
    title: "Content Security Policy",
    desc: "Strict CSP headers block XSS, clickjacking, and code injection attacks before they can reach the DOM.",
    status: "BLOCKING",
    color: "text-cyan-400",
    glow: "rgba(34,211,238,0.15)",
  },
  {
    icon: Fingerprint,
    title: "Rate Limiting & Bot Guard",
    desc: "Edge-level rate limiting stops brute-force, credential stuffing, and automated scraping dead in their tracks.",
    status: "ACTIVE",
    color: "text-rose-400",
    glow: "rgba(251,113,133,0.15)",
  },
];

function FirewallRadar() {
  return (
    <div className="relative flex items-center justify-center" style={{ width: 340, height: 340 }}>
      {/* Outermost ambient glow */}
      <div className="absolute inset-0 rounded-full"
        style={{ background: "radial-gradient(circle, rgba(0,229,255,0.06) 0%, transparent 70%)" }} />

      {/* Radar ping rings — staggered */}
      {[0, 1, 2].map(i => (
        <div
          key={i}
          className="absolute rounded-full border border-primary/30 animate-radar-ping"
          style={{
            width: 120, height: 120,
            animationDelay: `${i * 0.8}s`,
            animationDuration: "2.4s",
          }}
        />
      ))}

      {/* Outer dashed spinning ring */}
      <div
        className="absolute rounded-full border border-dashed border-primary/20 animate-spin-slow"
        style={{ width: 300, height: 300 }}
      />

      {/* Inner counter-spinning ring */}
      <div
        className="absolute rounded-full border border-primary/15 animate-spin-slow-r"
        style={{
          width: 240, height: 240,
          borderStyle: "dashed",
          borderWidth: 1,
        }}
      />

      {/* Grid cross-hairs */}
      <div className="absolute" style={{ width: 220, height: 220 }}>
        <div className="absolute left-1/2 top-0 bottom-0 w-px bg-primary/10" />
        <div className="absolute top-1/2 left-0 right-0 h-px bg-primary/10" />
        {/* Diagonal cross-hairs */}
        <div className="absolute inset-0 rounded-full border border-primary/8" />
      </div>

      {/* Threat dots — each flies from edge to center and explodes */}
      {THREAT_DOTS.map(dot => (
        <div
          key={dot.id}
          className="absolute"
          style={{
            left: dot.cx, top: dot.cy,
            transform: "translate(-50%,-50%)",
          }}
        >
          <div
            style={{
              width: 8, height: 8, borderRadius: "50%",
              background: "rgba(239,68,68,0.9)",
              boxShadow: "0 0 8px rgba(239,68,68,0.8), 0 0 16px rgba(239,68,68,0.4)",
              // CSS custom props for the keyframe offsets
              ["--tx" as string]: dot.tx,
              ["--ty" as string]: dot.ty,
              animation: `threat-in ${dot.dur} ${dot.delay} ease-in-out infinite`,
            }}
          />
        </div>
      ))}

      {/* Central shield */}
      <div className="relative z-10 flex items-center justify-center">
        {/* Core glow halo */}
        <div
          className="absolute rounded-full animate-glow-pulse"
          style={{
            width: 90, height: 90,
            background: "radial-gradient(circle, rgba(0,229,255,0.25) 0%, transparent 70%)",
          }}
        />
        {/* Shield icon */}
        <div
          className="relative flex items-center justify-center rounded-full bg-[#0B0C10] border border-primary/40 animate-shield-pulse"
          style={{
            width: 72, height: 72,
            boxShadow: "0 0 0 1px rgba(0,229,255,0.1), inset 0 0 24px rgba(0,229,255,0.08)",
          }}
        >
          <Shield className="h-8 w-8 text-primary" strokeWidth={1.5} />
        </div>
      </div>

      {/* Tick marks around the outer ring */}
      {Array.from({ length: 12 }).map((_, i) => {
        const angle = (i / 12) * 360;
        const rad   = (angle * Math.PI) / 180;
        const r     = 148;
        const x     = 170 + r * Math.sin(rad);
        const y     = 170 - r * Math.cos(rad);
        return (
          <div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-primary/30"
            style={{ left: x, top: y, transform: "translate(-50%,-50%)" }}
          />
        );
      })}
    </div>
  );
}

function FirewallSection() {
  const [blocked, setBlocked] = useState(147382);

  // Simulate live blocked-threat counter ticking up
  useEffect(() => {
    const id = setInterval(() => {
      setBlocked(v => v + Math.floor(Math.random() * 4) + 1);
    }, 1800);
    return () => clearInterval(id);
  }, []);

  return (
    <section className="relative py-16 md:py-24 lg:py-32 overflow-hidden bg-[#07080C] border-y border-white/5">
      {/* Cyber grid backdrop */}
      <div className="absolute inset-0 cyber-grid opacity-50 pointer-events-none" />

      {/* Giant ambient glow behind radar */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div
          className="rounded-full animate-glow-pulse"
          style={{
            width: 600, height: 600,
            background: "radial-gradient(circle, rgba(0,229,255,0.05) 0%, transparent 65%)",
          }}
        />
      </div>

      {/* Horizontal data-stream scan line */}
      <div className="absolute top-1/2 left-0 right-0 h-px pointer-events-none overflow-hidden" style={{ transform: "translateY(-50%)" }}>
        <div
          className="h-px w-1/3 animate-data-stream"
          style={{ background: "linear-gradient(90deg, transparent 0%, rgba(0,229,255,0.35) 50%, transparent 100%)" }}
        />
      </div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">

        {/* ── Header ── */}
        <Reveal className="text-center space-y-4 mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full border border-primary/30 bg-primary/5 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-primary">
            <Eye className="h-3 w-3 md:h-3.5 md:w-3.5 animate-live-blink" />
            AlphaTekx Firewall — Active Protection
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black tracking-tight text-balance">
            Built Like a{" "}
            <span className="gradient-text">Fortress.</span>
            <br className="hidden sm:block" />
            Zero Compromises.
          </h2>
          <p className="text-sm md:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed text-pretty">
            Your data, your sessions, your creative work — protected by military-grade
            infrastructure at every layer. We don't bolt on security. We build from it.
          </p>
          <div className="section-divider mt-4" />
        </Reveal>

        {/* ── Main layout: radar + counters + layer grid ── */}
        <div className="flex flex-col lg:flex-row items-center gap-10 lg:gap-16 xl:gap-24">

          {/* ── Left: Animated Radar ── */}
          <Reveal delay={100} className="shrink-0 flex flex-col items-center gap-6">
            <FirewallRadar />

            {/* Live blocked counter */}
            <div
              className="w-full max-w-[340px] rounded-2xl px-6 py-4 text-center"
              style={{
                background: "rgba(0,229,255,0.04)",
                border: "1px solid rgba(0,229,255,0.18)",
                boxShadow: "0 0 32px rgba(0,229,255,0.06), inset 0 0 24px rgba(0,229,255,0.04)",
              }}
            >
              <div className="flex items-center justify-center gap-2 mb-1">
                <span className="h-2 w-2 rounded-full bg-primary animate-live-blink" />
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70">Threats Neutralised — Live</span>
              </div>
              <p className="text-3xl md:text-4xl font-black text-primary tabular-nums" style={{ textShadow: "0 0 32px rgba(0,229,255,0.6)" }}>
                {blocked.toLocaleString()}
              </p>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">
                Malicious requests blocked since launch
              </p>
            </div>

            {/* Status pills */}
            <div className="flex flex-wrap justify-center gap-2">
              {[
                { label: "All Systems Go",      dot: "bg-emerald-400" },
                { label: "No Breaches",          dot: "bg-emerald-400" },
                { label: "Firewall Online",      dot: "bg-primary animate-live-blink" },
              ].map(({ label, dot }) => (
                <div
                  key={label}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest"
                  style={{ background: "rgba(0,229,255,0.05)", border: "1px solid rgba(0,229,255,0.15)" }}
                >
                  <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />
                  <span className="text-slate-300">{label}</span>
                </div>
              ))}
            </div>
          </Reveal>

          {/* ── Right: Security Layer Cards ── */}
          <div className="flex-1 min-w-0 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {SECURITY_LAYERS.map((layer, i) => {
              const Icon = layer.icon;
              return (
                <Reveal key={layer.title} delay={i * 80}>
                  <div
                    className="firewall-card h-full p-5 flex flex-col gap-3"
                    style={{ ["--glow" as string]: layer.glow }}
                  >
                    {/* Icon + status */}
                    <div className="flex items-start justify-between gap-3">
                      <div
                        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border"
                        style={{
                          background: layer.glow,
                          borderColor: layer.glow.replace("0.15", "0.3"),
                        }}
                      >
                        <Icon className={`h-5 w-5 ${layer.color}`} strokeWidth={1.5} />
                      </div>
                      <span
                        className="text-[9px] font-black uppercase tracking-[0.2em] px-2 py-1 rounded-full shrink-0"
                        style={{
                          background: layer.glow,
                          color: layer.color.replace("text-", ""),
                          border: `1px solid ${layer.glow.replace("0.15", "0.3")}`,
                        }}
                      >
                        {layer.status}
                      </span>
                    </div>
                    <h3 className="text-sm font-black text-white leading-snug">{layer.title}</h3>
                    <p className="text-xs text-slate-400 leading-relaxed text-pretty flex-1">{layer.desc}</p>
                    {/* Progress bar — always 100% for security */}
                    <div className="h-1 w-full rounded-full bg-white/5 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-1000"
                        style={{
                          width: "100%",
                          background: `linear-gradient(90deg, ${layer.glow.replace("0.15", "0.8")}, ${layer.glow.replace("0.15", "0.4")})`,
                          boxShadow: `0 0 8px ${layer.glow.replace("0.15", "0.6")}`,
                        }}
                      />
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>

        {/* ── Bottom banner ── */}
        <Reveal delay={200} className="mt-12 md:mt-16">
          <div
            className="rounded-2xl px-6 md:px-10 py-6 md:py-8 flex flex-col md:flex-row items-center justify-between gap-6"
            style={{
              background: "linear-gradient(135deg, rgba(0,229,255,0.05) 0%, rgba(0,0,0,0) 100%)",
              border: "1px solid rgba(0,229,255,0.15)",
              boxShadow: "0 0 64px rgba(0,229,255,0.05)",
            }}
          >
            <div className="flex items-center gap-4">
              <div
                className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl animate-shield-pulse"
                style={{ background: "rgba(0,229,255,0.08)", border: "1px solid rgba(0,229,255,0.25)" }}
              >
                <ShieldCheck className="h-7 w-7 text-primary" strokeWidth={1.5} />
              </div>
              <div>
                <p className="text-base font-black text-white text-balance">Your data is untouchable.</p>
                <p className="text-sm text-slate-400 text-pretty">
                  We never sell, share, or use your prompts to train models.
                  Your creative output belongs to you — forever.
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-4 shrink-0">
              {[
                { icon: Lock,          label: "SOC-2 Ready" },
                { icon: AlertTriangle, label: "Zero Breaches" },
                { icon: Wifi,          label: "99.9% Uptime" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-2 text-xs font-black text-slate-300 uppercase tracking-widest">
                  <Icon className="h-3.5 w-3.5 text-primary" />
                  {label}
                </div>
              ))}
            </div>
          </div>
        </Reveal>

      </div>
    </section>
  );
}

/* ══════════════════════════════════════════════════
   MAIN PAGE
══════════════════════════════════════════════════ */
export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const liveCount = useOnlineCount();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#0B0C10] text-white selection:bg-primary/20 overflow-x-hidden">

      {/* ════ SEO: PageMeta + FAQ schema + BreadcrumbList ════ */}
      <PageMeta
        title="AlphaTekx AI — The All-in-One AI Operating System"
        description="Stop juggling 6 subscriptions. Get 8 elite AI tools in one precision-engineered platform — Video Generator, Script Writer, Voice Gen, Art Studio and more. Start free."
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": FAQS.map(({ q, a }) => ({
            "@type": "Question",
            "name": q,
            "acceptedAnswer": { "@type": "Answer", "text": a },
          })),
        }) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://alphatekx.name.ng/" },
          ],
        }) }}
      />

      {/* ════════════ NAV ════════════ */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "glass shadow-2xl shadow-black/50" : "bg-transparent"
      } h-16 md:h-20 flex items-center`}>
        <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2 md:gap-3 group">
            <div className="flex h-9 w-9 md:h-10 md:w-10 items-center justify-center rounded-xl bg-primary/10 border border-primary/20 group-hover:bg-primary/20 transition-colors shrink-0">
              <Shield className="h-4 w-4 md:h-5 md:w-5 text-primary" />
            </div>
            <span className="text-lg md:text-xl font-black tracking-tighter uppercase">
              AlphaTekx <span className="text-primary">AI</span>
            </span>
          </Link>

          {/* Desktop nav links */}
          <div className="hidden md:flex items-center gap-6">
            <a href="#features"  className="text-sm font-semibold text-slate-400 hover:text-white transition-colors uppercase tracking-wider">Features</a>
            <a href="#use-cases" className="text-sm font-semibold text-slate-400 hover:text-white transition-colors uppercase tracking-wider">Use Cases</a>
            <a href="#pricing"   className="text-sm font-semibold text-slate-400 hover:text-white transition-colors uppercase tracking-wider">Pricing</a>
            <a href="#faq"       className="text-sm font-semibold text-slate-400 hover:text-white transition-colors uppercase tracking-wider">FAQ</a>
          </div>

          {/* Desktop CTAs */}
          <div className="hidden md:flex items-center gap-3">
            <Link to="/login" className="text-sm font-bold text-slate-300 hover:text-white transition-colors px-4 py-2 uppercase tracking-wider">
              Sign In
            </Link>
            <Link to="/login">
              <button className="btn-neon px-6 py-2.5 rounded-lg text-sm">Get Started →</button>
            </Link>
          </div>

          {/* Mobile: Sign In + Hamburger */}
          <div className="md:hidden flex items-center gap-2">
            <Link to="/login" className="text-xs font-bold text-slate-300 hover:text-primary transition-colors px-3 py-2 uppercase tracking-wider">
              Sign In
            </Link>
            <button
              onClick={() => setMobileMenuOpen(v => !v)}
              className="h-10 w-10 flex items-center justify-center rounded-xl bg-secondary/60 border border-border/40"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-16 left-0 right-0 glass border-b border-white/5 py-5 px-4 flex flex-col gap-3 animate-slide-up z-50">
            <a href="#features"  onClick={() => setMobileMenuOpen(false)} className="text-sm font-bold uppercase tracking-widest text-slate-300 hover:text-primary transition-colors py-2 border-b border-white/5">Features</a>
            <a href="#use-cases" onClick={() => setMobileMenuOpen(false)} className="text-sm font-bold uppercase tracking-widest text-slate-300 hover:text-primary transition-colors py-2 border-b border-white/5">Use Cases</a>
            <a href="#pricing"   onClick={() => setMobileMenuOpen(false)} className="text-sm font-bold uppercase tracking-widest text-slate-300 hover:text-primary transition-colors py-2 border-b border-white/5">Pricing</a>
            <a href="#faq"       onClick={() => setMobileMenuOpen(false)} className="text-sm font-bold uppercase tracking-widest text-slate-300 hover:text-primary transition-colors py-2 border-b border-white/5">FAQ</a>
            <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
              <button className="btn-neon w-full py-3.5 rounded-xl text-sm mt-2">Launch AlphaTekx OS →</button>
            </Link>
          </div>
        )}
      </nav>

      {/* ════════════ HERO ════════════ */}
      <section className="relative min-h-screen flex flex-col justify-center cyber-grid overflow-hidden pt-16 md:pt-20">
        {/* Ambient blobs — capped so they don't overflow on mobile */}
        <div className="absolute top-1/4 left-0 w-full max-w-[500px] h-[400px] md:h-[600px] rounded-full bg-primary/5 blur-[100px] pointer-events-none animate-glow-pulse" />
        <div className="absolute bottom-1/4 right-0 w-full max-w-[350px] h-[300px] md:h-[400px] rounded-full bg-violet-500/5 blur-[80px] pointer-events-none animate-glow-pulse [animation-delay:1.5s]" />

        <div className="container mx-auto px-4 md:px-6 relative z-10 py-12 md:py-0">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 lg:gap-16 items-center">

            {/* Text column */}
            <div className="space-y-6 md:space-y-8 text-center lg:text-left">
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 md:gap-3">
                <div className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full border border-primary/30 bg-primary/5 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-primary animate-fade-in">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse shrink-0" />
                  AlphaTekx OS v3.0 — Now Live
                </div>
                {/* Live online count — visible to all landing page visitors */}
                <div className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full border border-green-500/25 bg-green-500/5 animate-fade-in [animation-delay:0.15s]">
                  <span className="relative flex h-2 w-2 shrink-0">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-70" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-green-500" />
                  </span>
                  <span className="text-[10px] md:text-xs font-black tabular-nums text-green-400">
                    {formatLiveCount(liveCount)}
                  </span>
                  <span className="text-[10px] md:text-xs font-bold text-green-500/70 uppercase tracking-[0.15em]">online now</span>
                </div>
              </div>

              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-black leading-[1.05] tracking-tight animate-slide-up [animation-delay:0.1s]">
                The AI Operating{" "}
                <span className="text-primary">System</span>{" "}
                Built for{" "}
                <span className="text-white">Winners.</span>
              </h1>

              <p className="text-sm sm:text-base md:text-lg lg:text-xl text-slate-400 max-w-lg mx-auto lg:mx-0 leading-relaxed animate-slide-up [animation-delay:0.2s]">
                Eight elite AI tools. One precision-engineered platform. Stop juggling subscriptions — dominate every workflow from a single command center.
              </p>

              <div className="flex flex-col sm:flex-row items-center lg:items-start gap-3 md:gap-4 animate-slide-up [animation-delay:0.3s]">
                <Link to="/login" className="w-full sm:w-auto">
                  <button className="btn-neon w-full sm:w-auto px-8 md:px-10 py-3.5 md:py-4 rounded-xl text-sm md:text-base">
                    Launch AlphaTekx OS
                  </button>
                </Link>
                <a href="#features" className="flex items-center gap-2 text-sm font-bold text-slate-400 hover:text-white transition-colors group">
                  See all tools
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </a>
              </div>

              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 md:gap-6 pt-1 animate-slide-up [animation-delay:0.4s]">
                {["No credit card required", "8 tools in one", "Instant access"].map(t => (
                  <div key={t} className="flex items-center gap-1.5 text-[10px] md:text-xs text-slate-500 font-semibold uppercase tracking-wider">
                    <CheckCircle2 className="h-3 w-3 md:h-3.5 md:w-3.5 text-primary shrink-0" />
                    {t}
                  </div>
                ))}
              </div>
            </div>

            {/* Image column */}
            <div className="relative flex justify-center lg:justify-end animate-fade-in [animation-delay:0.2s]">
              <div className="w-full max-w-sm sm:max-w-md md:max-w-lg xl:max-w-xl animate-float"
                style={{ backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden", transform: "translateZ(0)" }}
              >
                <div className="absolute -inset-4 rounded-2xl bg-primary/5 blur-2xl pointer-events-none" />
                <div className="relative rounded-2xl overflow-hidden border border-primary/20 shadow-2xl shadow-primary/10">
                  <img
                    src="https://miaoda-site-img.s3cdn.medo.dev/images/KLing_9d5434f5-5660-44fc-8842-3c2b08c06a74.jpg"
                    alt="AlphaTekx AI OS — Dashboard Interface"
                    className="w-full h-auto block"
                    loading="eager"
                    decoding="async"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src =
                        "https://miaoda-site-img.s3cdn.medo.dev/images/KLing_5c0d6103-2321-4d85-8335-1daf01962fa8.jpg";
                    }}
                  />
                  <div className="absolute bottom-0 left-0 right-0 glass border-t border-primary/20 px-4 md:px-5 py-3 md:py-4">
                    <div className="flex items-center gap-2 md:gap-3">
                      <div className="h-2 w-2 rounded-full bg-green-400 animate-pulse shrink-0" />
                      <span className="text-[10px] md:text-xs font-black text-green-400 uppercase tracking-widest">All systems operational</span>
                    </div>
                  </div>
                </div>
                {/* Floating badges — hidden on very small phones */}
                <div className="absolute -top-3 -right-3 md:-top-4 md:-right-4 glass border border-primary/20 rounded-xl px-3 md:px-4 py-2 md:py-3 shadow-xl hidden sm:flex items-center gap-2">
                  <Zap className="h-3.5 w-3.5 md:h-4 md:w-4 text-yellow-400 shrink-0" />
                  <span className="text-[10px] md:text-xs font-black text-white uppercase tracking-wider whitespace-nowrap">8 AI Tools Active</span>
                </div>
                <div className="absolute -bottom-3 -left-3 md:-bottom-4 md:-left-4 glass border border-violet-500/20 rounded-xl px-3 md:px-4 py-2 md:py-3 shadow-xl hidden sm:flex items-center gap-2">
                  <Activity className="h-3.5 w-3.5 md:h-4 md:w-4 text-primary shrink-0" />
                  <span className="text-[10px] md:text-xs font-black text-white uppercase tracking-wider whitespace-nowrap">Live • 99% Uptime</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-24 md:h-32 bg-gradient-to-t from-[#0B0C10] to-transparent pointer-events-none" />
      </section>

      {/* ════════════ STATS ════════════ */}
      <section className="py-14 md:py-20 border-y border-white/5 bg-[#0D0E13]">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-4">
            {STATS.map((s) => (
              <Reveal key={s.label} className="text-center space-y-2">
                <div className="text-3xl md:text-4xl lg:text-5xl font-black text-primary tabular-nums">
                  <AnimatedCounter end={s.value} suffix={s.suffix} />
                </div>
                <p className="text-[10px] md:text-xs font-bold text-slate-500 uppercase tracking-widest">{s.label}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ════════════ FEATURES ════════════ */}
      <section id="features" className="py-16 md:py-24 lg:py-32 relative cyber-grid">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0B0C10] via-transparent to-[#0B0C10] pointer-events-none" />
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <Reveal className="text-center space-y-4 md:space-y-5 mb-10 md:mb-16 lg:mb-20">
            <div className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full border border-primary/20 bg-primary/5 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-primary">
              <Zap className="h-3 w-3 md:h-3.5 md:w-3.5" />
              Integrated Tool Suite
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black tracking-tight text-balance">
              Eight Weapons.<br />
              <span className="text-primary">One Platform.</span>
            </h2>
            <p className="text-sm md:text-base lg:text-lg text-slate-400 max-w-xl mx-auto leading-relaxed text-pretty">
              Every tool you need to create, research, build, and scale — all inside AlphaTekx OS.
            </p>
            <div className="section-divider mt-4" />
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
            {FEATURES.map((f, i) => {
              const Icon = f.icon;
              return (
                <Reveal key={f.title} delay={i * 60}>
                  <div className="neon-card p-5 md:p-6 flex flex-col gap-4 md:gap-5 group h-full">
                    <div className="flex h-11 w-11 md:h-12 md:w-12 items-center justify-center rounded-xl bg-primary/10 border border-primary/20 group-hover:bg-primary group-hover:border-primary transition-all duration-300 shrink-0">
                      <Icon className="h-5 w-5 md:h-6 md:w-6 text-primary group-hover:text-black transition-colors duration-300" />
                    </div>
                    <div className="space-y-1.5">
                      <h3 className="text-sm md:text-base font-black uppercase tracking-tight text-white">{f.title}</h3>
                      <p className="text-xs md:text-sm text-slate-400 leading-relaxed text-pretty">{f.desc}</p>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* ════════════ WHO IS THIS FOR? ════════════ */}
      <section id="use-cases" className="py-16 md:py-24 lg:py-32 bg-[#0D0E13] border-y border-white/5">
        <div className="container mx-auto px-4 md:px-6">
          <Reveal className="text-center space-y-4 md:space-y-5 mb-10 md:mb-16 lg:mb-20">
            <div className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full border border-primary/20 bg-primary/5 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-primary">
              <Users className="h-3 w-3 md:h-3.5 md:w-3.5" />
              Who Is This For?
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black tracking-tight text-balance">
              Built for <span className="text-primary">Everyone</span> Who Creates.
            </h2>
            <p className="text-sm md:text-base lg:text-lg text-slate-400 max-w-xl mx-auto leading-relaxed text-pretty">
              Whether you're a student, a solopreneur, or running a full agency — AlphaTekx OS scales with your ambition.
            </p>
            <div className="section-divider mt-4" />
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            {USE_CASES.map((uc) => {
              const Icon = uc.icon;
              return (
                <div key={uc.audience} className={`relative neon-card p-5 md:p-7 flex flex-col gap-4 md:gap-5 h-full overflow-hidden ${uc.border}`}>
                    <div className={`absolute inset-0 bg-gradient-to-br ${uc.color} pointer-events-none`} />
                    <div className="relative z-10 flex items-center gap-3 md:gap-4">
                      <div className="flex h-11 w-11 md:h-12 md:w-12 items-center justify-center rounded-xl bg-white/5 border border-white/10 shrink-0">
                        <Icon className="h-5 w-5 md:h-6 md:w-6 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-primary/70">{uc.audience}</p>
                        <h3 className="text-base md:text-lg font-black text-white leading-tight">{uc.headline}</h3>
                      </div>
                    </div>
                    <ul className="relative z-10 space-y-2.5 md:space-y-3">
                      {uc.points.map(p => (
                        <li key={p} className="flex items-start gap-2.5 md:gap-3 text-xs md:text-sm text-slate-300">
                          <CheckCircle2 className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                          {p}
                        </li>
                      ))}
                    </ul>
                    <div className="relative z-10 mt-auto pt-3 md:pt-4 border-t border-white/5">
                      <Link to="/login">
                        <button className="text-xs font-black text-primary uppercase tracking-widest flex items-center gap-1.5 transition-all group">
                          Get started
                          <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
                        </button>
                      </Link>
                    </div>
                  </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ════════════ VALUE PROPS STRIP ════════════ */}
      <section className="py-12 md:py-16 border-b border-white/5">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 md:gap-8">
            {[
              { icon: DollarSign, title: "Save Money", desc: "Replace 6+ subscriptions with one. Average user saves $180/month." },
              { icon: Clock,      title: "Save Time",  desc: "AI-assisted workflows cut production time by up to 70%." },
              { icon: TrendingUp, title: "Scale Fast",  desc: "From 1 to 1,000 deliverables — AlphaTekx grows with you." },
            ].map((v, i) => {
              const Icon = v.icon;
              return (
                <Reveal key={v.title} delay={i * 100} className="flex items-start gap-4 md:gap-5">
                  <div className="flex h-11 w-11 md:h-12 md:w-12 items-center justify-center rounded-xl bg-primary/10 border border-primary/20 shrink-0">
                    <Icon className="h-5 w-5 md:h-6 md:w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-black text-white text-sm md:text-base mb-1">{v.title}</h4>
                    <p className="text-xs md:text-sm text-slate-400 leading-relaxed">{v.desc}</p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* ════════════ TESTIMONIALS ════════════ */}
      <section className="py-16 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
          <Reveal className="text-center space-y-4 md:space-y-5 mb-10 md:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-balance">
              Trusted by <span className="text-primary">Operators</span> Who Move Fast
            </h2>
            <div className="section-divider" />
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
            {TESTIMONIALS.map((t, i) => (
              <Reveal key={t.name} delay={i * 80}>
                <div className="neon-card p-5 md:p-7 flex flex-col gap-4 md:gap-5 h-full">
                  <div className="flex gap-1">
                    {Array.from({ length: t.stars }).map((_, si) => (
                      <Star key={si} className="h-3.5 w-3.5 md:h-4 md:w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-sm md:text-base text-slate-300 leading-relaxed text-pretty italic flex-1">"{t.quote}"</p>
                  <div className="border-t border-white/5 pt-3 md:pt-4">
                    <p className="font-black text-white text-sm">{t.name}</p>
                    <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider mt-0.5">{t.role}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ════════════ PRICING ════════════ */}
      <section id="pricing" className="py-16 md:py-24 lg:py-32 bg-[#0D0E13] border-y border-white/5">
        <div className="container mx-auto px-4 md:px-6">
          <Reveal className="text-center space-y-4 md:space-y-5 mb-10 md:mb-16 lg:mb-20">
            <div className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full border border-primary/20 bg-primary/5 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-primary">
              <BarChart3 className="h-3 w-3 md:h-3.5 md:w-3.5" />
              Simple Pricing
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black tracking-tight text-balance">
              Top Up Credits. <span className="text-primary">No Subscription.</span>
            </h2>
            <p className="text-sm md:text-base text-slate-400 max-w-lg mx-auto leading-relaxed text-pretty">
              Buy only what you need. Credits never expire and work across all 8 AI tools.
            </p>
            <div className="section-divider" />
          </Reveal>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6 max-w-6xl mx-auto items-stretch">
            {PRICING.map((p, i) => (
              <Reveal key={p.name} delay={i * 80}>
                {/* Extra top padding on highlighted / badged cards */}
                <div className={`pricing-card-stable relative flex flex-col rounded-2xl p-5 md:p-7 gap-5 md:gap-6 h-full ${
                  p.highlight ? "pricing-popular pt-8 md:pt-10" : "neon-card"
                } ${'badge' in p && p.badge && !p.highlight ? "pt-8 md:pt-10" : ""}`}>
                  {p.highlight && (
                    <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 md:px-5 py-1.5 rounded-full bg-primary text-black text-[10px] md:text-xs font-black uppercase tracking-widest whitespace-nowrap shadow-lg shadow-primary/30">
                      Best Value
                    </div>
                  )}
                  {'badge' in p && p.badge && !p.highlight && (
                    <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full bg-amber-500 text-black text-[10px] font-black uppercase tracking-widest whitespace-nowrap shadow-lg shadow-amber-500/30">
                      {p.badge}
                    </div>
                  )}
                  <div className="space-y-1.5">
                    <h3 className="text-xs md:text-sm font-black uppercase tracking-[0.2em] text-slate-400">{p.name}</h3>
                    <div className="flex items-end gap-2">
                      <span className="text-3xl md:text-4xl font-black text-white">{p.price}</span>
                      <span className="mb-1 px-2.5 py-0.5 rounded-full bg-primary/10 border border-primary/25 text-primary text-[11px] md:text-xs font-black tracking-wide whitespace-nowrap">{p.credits}</span>
                    </div>
                    <p className="text-xs md:text-sm text-slate-400">{p.desc}</p>
                  </div>
                  <ul className="flex-1 space-y-2.5 md:space-y-3">
                    {p.features.map(f => (
                      <li key={f} className="flex items-start gap-2.5 md:gap-3 text-xs md:text-sm text-slate-300">
                        <CheckCircle2 className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Link to="/login" className="block">
                    <button className={`w-full py-3 md:py-3.5 rounded-xl font-black uppercase tracking-widest text-xs md:text-sm transition-all ${
                      p.highlight
                        ? "btn-neon"
                        : "border border-primary/30 text-primary hover:bg-primary/10 transition-colors"
                    }`}>
                      {p.cta}
                    </button>
                  </Link>
                </div>
              </Reveal>
            ))}
          </div>

          {/* ── No-Refund Notice ── */}
          <Reveal delay={150} className="mt-8 md:mt-10 max-w-3xl mx-auto">
            <div className="flex items-start gap-3 px-4 md:px-5 py-3.5 md:py-4 rounded-xl border border-yellow-500/30 bg-yellow-500/5">
              <span className="text-yellow-400 text-base md:text-lg shrink-0 mt-0.5">⚠</span>
              <p className="text-[11px] md:text-xs text-yellow-300/80 leading-relaxed font-medium">
                <span className="font-black text-yellow-300 uppercase tracking-wide">No Refund Policy:</span>{" "}
                All purchases on AlphaTekx are final and non-refundable. AI credits are consumed upon use and cannot be reversed. Please review your plan carefully before completing your purchase. By subscribing, you acknowledge and agree to this no-refund policy.
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ════════════ FOUNDER / ABOUT ════════════ */}
      <section id="about" className="py-16 md:py-24 lg:py-32 border-b border-white/5">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 md:gap-16 items-center">
            <Reveal className="flex justify-center">
              <div className="relative">
                <div className="absolute -inset-3 rounded-full bg-primary/10 blur-2xl pointer-events-none animate-glow-pulse" />
                <div className="relative w-56 h-56 sm:w-64 sm:h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-2 border-primary/30 shadow-2xl shadow-primary/20">
                  <img
                    src="https://miaoda-conversation-file.s3cdn.medo.dev/user-bjmcmupeascg/app-brtbaj3iij9d/20260531/create-a-professional-corporate-headshot-for-websi.jpeg"
                    alt="AlphaTekx Architect"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10]/30 to-transparent pointer-events-none" />
                </div>
                <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 glass border border-primary/30 rounded-full px-4 md:px-5 py-2 whitespace-nowrap shadow-xl">
                  <span className="text-[10px] md:text-xs font-black text-primary uppercase tracking-widest">Architect & Founder</span>
                </div>
              </div>
            </Reveal>

            <Reveal delay={100} className="space-y-6 md:space-y-8 text-center lg:text-left">
              <div className="space-y-3">
                <div className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full border border-primary/20 bg-primary/5 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-primary">
                  <Users className="h-3 w-3 md:h-3.5 md:w-3.5" />
                  Meet the Architect
                </div>
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-balance">
                  Built by someone who <span className="text-primary">refused to settle.</span>
                </h2>
              </div>
              <div className="space-y-4 md:space-y-5 text-slate-300 text-sm md:text-base lg:text-lg leading-[1.8]">
                <p>
                  AlphaTekx was born from frustration. Too many tools, too many subscriptions, too much friction — and zero coherence. I built the platform I always wanted: a singular, ruthlessly efficient AI command centre.
                </p>
                <p>
                  Every feature is engineered for performance. Every tool is integrated by design, not as an afterthought. This isn't a collection of widgets — it's an operating system for the modern digital professional.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3 md:gap-4">
                {[
                  { icon: Shield,   label: "Production-grade security" },
                  { icon: Zap,      label: "Real-time AI processing" },
                  { icon: Activity, label: "99% uptime SLA" },
                  { icon: Lock,     label: "End-to-end encryption" },
                ].map(({ icon: Icon, label }) => (
                  <div key={label} className="flex items-center gap-2 md:gap-3 text-xs md:text-sm text-slate-400">
                    <Icon className="h-3.5 w-3.5 md:h-4 md:w-4 text-primary shrink-0" />
                    <span className="font-semibold">{label}</span>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ════════════ FAQ ════════════ */}
      <section id="faq" className="py-16 md:py-24 lg:py-32 bg-[#0D0E13] border-b border-white/5" style={{ isolation: "isolate" }}>
        <div className="container mx-auto px-4 md:px-6">
          <Reveal className="text-center space-y-4 md:space-y-5 mb-10 md:mb-16">
            <div className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full border border-primary/20 bg-primary/5 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-primary">
              <CircleHelp className="h-3 w-3 md:h-3.5 md:w-3.5" />
              Frequently Asked Questions
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-balance">
              Everything You Need to <span className="text-primary">Know</span>
            </h2>
            <p className="text-sm md:text-base text-slate-400 max-w-lg mx-auto leading-relaxed text-pretty">
              No fluff. Straight answers to the questions we get asked most.
            </p>
            <div className="section-divider" />
          </Reveal>

          <div className="max-w-3xl mx-auto space-y-2.5 md:space-y-3">
            {FAQS.map((faq) => (
              <FaqItem key={faq.q} q={faq.q} a={faq.a} />
            ))}
          </div>

          <Reveal delay={200} className="text-center mt-10 md:mt-12">
            <p className="text-slate-500 text-xs md:text-sm">
              Still have questions?{" "}
              <Link to="/login" className="text-primary font-bold hover:underline">
                Launch the app and chat with us directly.
              </Link>
            </p>
          </Reveal>
        </div>
      </section>

      {/* ════════════ FIREWALL / SECURITY ════════════ */}
      <FirewallSection />

      {/* ════════════ WAITLIST / EMAIL CAPTURE ════════════ */}
      <section className="py-16 md:py-24 lg:py-32 relative overflow-hidden">
        <div className="absolute inset-0 cyber-grid opacity-40 pointer-events-none" />
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-full max-w-[700px] h-[200px] md:h-[300px] bg-primary/6 rounded-full blur-[80px] animate-glow-pulse" />
        </div>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <Reveal className="max-w-2xl mx-auto text-center space-y-6 md:space-y-8">
            <div className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full border border-primary/30 bg-primary/5 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-primary">
              <Mail className="h-3 w-3 md:h-3.5 md:w-3.5" />
              Stay in the Loop
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-black tracking-tight text-balance">
              Get Early Access & <span className="text-primary">Exclusive Updates</span>
            </h2>
            <p className="text-sm md:text-base lg:text-lg text-slate-400 leading-relaxed text-pretty">
              Join thousands of creators, students, and professionals already on the AlphaTekx waitlist. Be the first to unlock new tools, features, and offers.
            </p>
            <WaitlistForm />
            <p className="text-[10px] md:text-xs text-slate-600 font-semibold uppercase tracking-widest">
              No spam. Unsubscribe anytime. Your data stays private.
            </p>
          </Reveal>
        </div>
      </section>

      {/* ════════════ FINAL CTA ════════════ */}
      <section className="py-20 md:py-32 lg:py-48 relative overflow-hidden bg-[#0D0E13] border-t border-white/5">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-full max-w-[800px] h-[300px] md:h-[400px] bg-primary/5 rounded-full blur-[100px] animate-glow-pulse" />
        </div>
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center">
          <Reveal className="max-w-3xl mx-auto space-y-7 md:space-y-10">
            <div className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full border border-primary/30 bg-primary/5 text-[10px] md:text-xs font-black uppercase tracking-[0.2em] text-primary">
              <Shield className="h-3 w-3 md:h-3.5 md:w-3.5" />
              Join the AlphaTekx Ecosystem
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-balance leading-[1.05]">
              Stop using five tools.<br />
              <span className="text-primary">Start using one.</span>
            </h2>
            <p className="text-sm md:text-base lg:text-lg text-slate-400 max-w-xl mx-auto leading-relaxed text-pretty">
              AlphaTekx OS gives you the power of an entire AI department — without the overhead. Launch today and feel the difference.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 md:gap-4">
              <Link to="/login" className="w-full sm:w-auto">
                <button className="btn-neon w-full sm:w-auto px-8 md:px-12 py-3.5 md:py-4 rounded-xl text-sm md:text-base group">
                  Launch AlphaTekx OS
                  <ChevronRight className="inline-block ml-2 h-4 w-4 md:h-5 md:w-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </Link>
              <a href="#pricing" className="text-sm font-bold text-slate-400 hover:text-white transition-colors flex items-center gap-2 group">
                View pricing
                <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
            <p className="text-[10px] md:text-xs text-slate-600 font-semibold uppercase tracking-widest">
              No credit card required · No subscription · Instant access
            </p>
          </Reveal>
        </div>
      </section>

      {/* ════════════ FOOTER ════════════ */}
      <footer className="border-t border-white/5 py-10 md:py-12 bg-[#0A0B0F]">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col gap-6 md:gap-8">
            {/* Top row */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-4">
              <div className="flex items-center gap-2 md:gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 border border-primary/20 shrink-0">
                  <Shield className="h-4 w-4 text-primary" />
                </div>
                <span className="text-sm font-black tracking-tighter uppercase">
                  AlphaTekx <span className="text-primary">AI</span>
                </span>
              </div>
              <p className="text-[10px] md:text-xs text-slate-600 font-semibold uppercase tracking-widest text-center sm:text-right">
                &copy; {new Date().getFullYear()} AlphaTekx AI. All rights reserved.
              </p>
            </div>
            {/* Nav links — wrap on mobile */}
            <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 md:gap-x-6 border-t border-white/5 pt-6">
              <a href="#features"  className="text-[10px] md:text-xs text-slate-500 hover:text-slate-300 transition-colors uppercase tracking-wider font-semibold">Features</a>
              <a href="#use-cases" className="text-[10px] md:text-xs text-slate-500 hover:text-slate-300 transition-colors uppercase tracking-wider font-semibold">Use Cases</a>
              <a href="#pricing"   className="text-[10px] md:text-xs text-slate-500 hover:text-slate-300 transition-colors uppercase tracking-wider font-semibold">Pricing</a>
              <a href="#faq"       className="text-[10px] md:text-xs text-slate-500 hover:text-slate-300 transition-colors uppercase tracking-wider font-semibold">FAQ</a>
              <Link to="/terms"    className="text-[10px] md:text-xs text-slate-500 hover:text-slate-300 transition-colors uppercase tracking-wider font-semibold">Terms</Link>
              <Link to="/privacy"  className="text-[10px] md:text-xs text-slate-500 hover:text-slate-300 transition-colors uppercase tracking-wider font-semibold">Privacy</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
