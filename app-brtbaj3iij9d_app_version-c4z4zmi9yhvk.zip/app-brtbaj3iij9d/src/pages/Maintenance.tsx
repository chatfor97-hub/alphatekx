import PageMeta from '@/components/common/PageMeta';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Construction, ArrowLeft } from 'lucide-react';

export default function Maintenance() {
  return (
    <>
      <PageMeta title="Maintenance" description="AlphaTekx is under maintenance" />
      <div className="flex items-center justify-center min-h-screen px-4">
        <Card className="w-full max-w-md glass-strong border border-white/10 text-center">
          <CardHeader className="space-y-3">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-warning/10 border border-warning/20">
              <Construction className="h-7 w-7 text-warning" />
            </div>
            <CardTitle className="text-xl font-bold tracking-tight">
              System Maintenance
            </CardTitle>
            <CardDescription className="text-muted-foreground text-sm text-pretty">
              AlphaTekx is temporarily offline for scheduled maintenance.
              Our engineering team is optimizing the AI Operating System.
              Please check back shortly.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/dashboard">
              <Button variant="outline" className="w-full h-11 gap-2 border-white/10 hover:bg-white/5 hover:border-white/20">
                <ArrowLeft className="h-4 w-4" />
                Return to Dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
