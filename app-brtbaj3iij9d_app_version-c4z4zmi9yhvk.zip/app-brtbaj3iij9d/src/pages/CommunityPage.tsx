import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/db/supabase';
import { useUserSession } from '@/contexts/UserSessionContext';
import { auth } from '@/lib/firebase';
import { toast } from 'sonner';
import PageMeta from '@/components/common/PageMeta';
import { Button } from '@/components/ui/button';
import {
  MessageSquare, Send, Heart, Reply, Pin, Trash2,
  Users, Image, X, ChevronUp, Loader2, Shield,
} from 'lucide-react';

// ── Types ─────────────────────────────────────────────────────────────────────
interface CommunityMessage {
  id:           string;
  firebase_uid: string;
  display_name: string;
  photo_url:    string | null;
  content:      string;
  image_url:    string | null;
  reply_to_id:  string | null;
  is_pinned:    boolean;
  is_deleted:   boolean;
  created_at:   string;
  // aggregated client-side
  reactions:    { emoji: string; count: number; reacted: boolean }[];
  replies:      CommunityMessage[];
}

interface OnlineUser {
  firebase_uid: string;
  display_name: string;
  photo_url:    string | null;
  last_seen_at: string;
}

const PAGE_SIZE   = 40;
const ONLINE_TTL  = 60; // seconds — users visible as "online" for 60 s
const PRESENCE_INTERVAL = 20_000; // heartbeat every 20 s

// ── Helpers ───────────────────────────────────────────────────────────────────
function formatTime(iso: string) {
  const d    = new Date(iso);
  const now  = new Date();
  const diff = (now.getTime() - d.getTime()) / 1000;
  if (diff < 60)      return 'just now';
  if (diff < 3600)    return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400)   return `${Math.floor(diff / 3600)}h ago`;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function Avatar({ src, name, size = 8 }: { src?: string | null; name: string; size?: number }) {
  const cls = `h-${size} w-${size} rounded-xl object-cover border border-border/60 shrink-0`;
  if (src) return <img src={src} alt={name} className={cls} />;
  return (
    <div className={`flex h-${size} w-${size} items-center justify-center rounded-xl bg-primary/15 border border-primary/20 shrink-0`}>
      <span className="text-primary font-black text-xs uppercase">{name.charAt(0)}</span>
    </div>
  );
}

// ── Reaction button ───────────────────────────────────────────────────────────
function ReactionBtn({
  messageId, reactions, firebaseUid, onToggle,
}: {
  messageId: string;
  reactions: { emoji: string; count: number; reacted: boolean }[];
  firebaseUid: string;
  onToggle: (msgId: string, emoji: string, reacted: boolean) => void;
}) {
  const heart = reactions.find(r => r.emoji === '❤️') ?? { count: 0, reacted: false };
  return (
    <button
      onClick={() => onToggle(messageId, '❤️', heart.reacted)}
      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold transition-all ${
        heart.reacted
          ? 'bg-pink-500/20 text-pink-400 border border-pink-500/30'
          : 'bg-secondary/60 text-muted-foreground border border-border/40 hover:text-pink-400 hover:border-pink-500/30'
      }`}
    >
      <Heart className={`h-3 w-3 ${heart.reacted ? 'fill-pink-400' : ''}`} />
      {heart.count > 0 && <span>{heart.count}</span>}
    </button>
  );
}

// ── Single message card ───────────────────────────────────────────────────────
function MessageCard({
  msg, isReply = false, isAdmin, firebaseUid,
  onReply, onDelete, onPin, onReaction,
}: {
  msg:          CommunityMessage;
  isReply?:     boolean;
  isAdmin:      boolean;
  firebaseUid:  string;
  onReply:      (msg: CommunityMessage) => void;
  onDelete:     (id: string) => void;
  onPin:        (id: string, pinned: boolean) => void;
  onReaction:   (msgId: string, emoji: string, reacted: boolean) => void;
}) {
  const isOwn = msg.firebase_uid === firebaseUid;

  return (
    <div className={`group flex gap-3 ${isReply ? 'ml-10 md:ml-14' : ''} animate-in fade-in slide-in-from-bottom-1 duration-200`}>
      {/* Avatar */}
      <div className="shrink-0 mt-0.5">
        <Avatar src={msg.photo_url} name={msg.display_name} size={isReply ? 7 : 9} />
      </div>

      {/* Bubble */}
      <div className="flex-1 min-w-0">
        {/* Header row */}
        <div className="flex items-center gap-2 flex-wrap mb-1">
          <span className="text-sm font-black text-foreground leading-none truncate max-w-[160px]">{msg.display_name}</span>
          {isOwn && (
            <span className="text-[9px] font-bold uppercase tracking-widest text-primary/60 bg-primary/10 px-1.5 py-0.5 rounded-full">You</span>
          )}
          {msg.is_pinned && (
            <span className="flex items-center gap-1 text-[9px] font-bold uppercase tracking-widest text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded-full">
              <Pin className="h-2.5 w-2.5" /> Pinned
            </span>
          )}
          <span className="text-[10px] text-muted-foreground/50 font-medium ml-auto shrink-0">{formatTime(msg.created_at)}</span>
        </div>

        {/* Content */}
        <div className={`relative rounded-2xl ${isReply ? 'rounded-tl-sm' : 'rounded-tl-sm'} p-3.5 border ${
          msg.is_pinned
            ? 'bg-amber-500/5 border-amber-500/20'
            : 'bg-card border-border/50'
        }`}>
          {msg.content && (
            <p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap break-words">
              {msg.content}
            </p>
          )}
          {msg.image_url && (
            <div className="mt-2">
              <img
                src={msg.image_url}
                alt="Shared image"
                className="max-w-full max-h-72 rounded-xl object-contain border border-border/40"
              />
            </div>
          )}

          {/* Action bar */}
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            <ReactionBtn
              messageId={msg.id}
              reactions={msg.reactions}
              firebaseUid={firebaseUid}
              onToggle={onReaction}
            />
            {!isReply && (
              <button
                onClick={() => onReply(msg)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-secondary/60 text-muted-foreground border border-border/40 hover:text-primary hover:border-primary/30 transition-all"
              >
                <Reply className="h-3 w-3" /> Reply
                {msg.replies.length > 0 && (
                  <span className="text-primary">{msg.replies.length}</span>
                )}
              </button>
            )}
            {/* Admin / own actions */}
            {(isAdmin || isOwn) && (
              <button
                onClick={() => onDelete(msg.id)}
                className="ml-auto flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold text-muted-foreground/40 hover:text-destructive hover:bg-destructive/10 border border-transparent hover:border-destructive/20 transition-all opacity-0 group-hover:opacity-100"
                title="Delete message"
              >
                <Trash2 className="h-3 w-3" />
              </button>
            )}
            {isAdmin && (
              <button
                onClick={() => onPin(msg.id, msg.is_pinned)}
                className={`flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-bold border transition-all opacity-0 group-hover:opacity-100 ${
                  msg.is_pinned
                    ? 'text-amber-400 border-amber-400/30 hover:bg-amber-400/10'
                    : 'text-muted-foreground/40 border-transparent hover:text-amber-400 hover:border-amber-400/30 hover:bg-amber-400/10'
                }`}
                title={msg.is_pinned ? 'Unpin' : 'Pin message'}
              >
                <Pin className="h-3 w-3" />
              </button>
            )}
          </div>
        </div>

        {/* Nested replies */}
        {msg.replies.length > 0 && (
          <div className="mt-2 space-y-2 border-l-2 border-border/30 pl-3">
            {msg.replies.map(reply => (
              <MessageCard
                key={reply.id}
                msg={reply}
                isReply
                isAdmin={isAdmin}
                firebaseUid={firebaseUid}
                onReply={onReply}
                onDelete={onDelete}
                onPin={onPin}
                onReaction={onReaction}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────────
export default function CommunityPage() {
  const { appUser } = useUserSession();
  const firebaseUid    = auth.currentUser?.uid ?? appUser?.uid ?? '';
  const displayName    = appUser?.display_name || appUser?.email || 'Anonymous';
  const photoUrl       = appUser?.photo_url ?? null;
  const isAdmin        = appUser?.role === 'admin';

  const [messages,       setMessages]       = useState<CommunityMessage[]>([]);
  const [onlineUsers,    setOnlineUsers]     = useState<OnlineUser[]>([]);
  const [loading,        setLoading]         = useState(true);
  const [loadingMore,    setLoadingMore]     = useState(false);
  const [hasMore,        setHasMore]         = useState(true);
  const [replyTo,        setReplyTo]         = useState<CommunityMessage | null>(null);
  const [input,          setInput]           = useState('');
  const [sending,        setSending]         = useState(false);
  const [pendingImage,   setPendingImage]    = useState<File | null>(null);
  const [imagePreview,   setImagePreview]    = useState<string | null>(null);
  const [uploadingImg,   setUploadingImg]    = useState(false);
  const [showOnline,     setShowOnline]      = useState(true);
  const oldestCreatedAt  = useRef<string | null>(null);
  const scrollRef        = useRef<HTMLDivElement>(null);
  const fileRef          = useRef<HTMLInputElement>(null);
  const textareaRef      = useRef<HTMLTextAreaElement>(null);
  const bottomRef        = useRef<HTMLDivElement>(null);
  const presenceTimer    = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Merge reactions into messages ──────────────────────────────────────────
  async function attachReactionsAndReplies(raw: CommunityMessage[]): Promise<CommunityMessage[]> {
    if (raw.length === 0) return [];
    const ids = raw.map(m => m.id);

    const { data: rxData } = await supabase
      .from('community_reactions')
      .select('message_id, emoji, firebase_uid')
      .in('message_id', ids);

    const rxMap: Record<string, { emoji: string; count: number; reacted: boolean }[]> = {};
    for (const rx of rxData ?? []) {
      if (!rxMap[rx.message_id]) rxMap[rx.message_id] = [];
      const existing = rxMap[rx.message_id].find(r => r.emoji === rx.emoji);
      if (existing) {
        existing.count++;
        if (rx.firebase_uid === firebaseUid) existing.reacted = true;
      } else {
        rxMap[rx.message_id].push({ emoji: rx.emoji, count: 1, reacted: rx.firebase_uid === firebaseUid });
      }
    }

    const topLevel = raw.filter(m => !m.reply_to_id);
    const replyMap: Record<string, CommunityMessage[]> = {};
    for (const m of raw) {
      if (m.reply_to_id) {
        if (!replyMap[m.reply_to_id]) replyMap[m.reply_to_id] = [];
        replyMap[m.reply_to_id].push({ ...m, reactions: rxMap[m.id] ?? [], replies: [] });
      }
    }

    return topLevel.map(m => ({
      ...m,
      reactions: rxMap[m.id] ?? [],
      replies:   replyMap[m.id] ?? [],
    }));
  }

  // ── Initial load ───────────────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from('community_messages')
        .select('*')
        .eq('is_deleted', false)
        .order('created_at', { ascending: false })
        .limit(PAGE_SIZE);

      const raw = (data ?? []).reverse() as CommunityMessage[];
      if (raw.length > 0) oldestCreatedAt.current = raw[0].created_at;
      if (raw.length < PAGE_SIZE) setHasMore(false);
      const enriched = await attachReactionsAndReplies(raw);
      setMessages(enriched);
      setLoading(false);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'instant' }), 50);
    })();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Load more (older) ──────────────────────────────────────────────────────
  async function loadMore() {
    if (loadingMore || !hasMore || !oldestCreatedAt.current) return;
    setLoadingMore(true);
    const { data } = await supabase
      .from('community_messages')
      .select('*')
      .eq('is_deleted', false)
      .lt('created_at', oldestCreatedAt.current)
      .order('created_at', { ascending: false })
      .limit(PAGE_SIZE);

    const raw = (data ?? []).reverse() as CommunityMessage[];
    if (raw.length > 0) oldestCreatedAt.current = raw[0].created_at;
    if (raw.length < PAGE_SIZE) setHasMore(false);
    const enriched = await attachReactionsAndReplies(raw);

    // Preserve scroll position
    const container = scrollRef.current;
    const prevScrollHeight = container?.scrollHeight ?? 0;
    setMessages(prev => [...enriched, ...prev]);
    requestAnimationFrame(() => {
      if (container) container.scrollTop = container.scrollHeight - prevScrollHeight;
    });
    setLoadingMore(false);
  }

  // ── Realtime subscription ──────────────────────────────────────────────────
  useEffect(() => {
    const ch = supabase.channel('community-feed')
      // New message
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'community_messages' }, async (payload) => {
        const msg = payload.new as CommunityMessage;
        if (msg.is_deleted) return;
        const enriched = await attachReactionsAndReplies([msg]);
        const newMsg = enriched[0];
        if (!newMsg) return;

        setMessages(prev => {
          // If it's a reply, merge into parent
          if (newMsg.reply_to_id) {
            return prev.map(m =>
              m.id === newMsg.reply_to_id
                ? { ...m, replies: [...m.replies, { ...newMsg, replies: [] }] }
                : m
            );
          }
          // Top-level — append
          const exists = prev.some(m => m.id === newMsg.id);
          return exists ? prev : [...prev, newMsg];
        });

        // Auto-scroll if near bottom
        const el = scrollRef.current;
        if (el) {
          const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 180;
          if (nearBottom) setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
        }
      })
      // Update (pin/delete)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'community_messages' }, (payload) => {
        const updated = payload.new as CommunityMessage;
        setMessages(prev =>
          prev
            .filter(m => !updated.is_deleted || m.id !== updated.id)
            .map(m => {
              if (m.id === updated.id) return { ...m, is_pinned: updated.is_pinned, is_deleted: updated.is_deleted };
              // Check inside replies
              return {
                ...m,
                replies: m.replies
                  .filter(r => !updated.is_deleted || r.id !== updated.id)
                  .map(r => r.id === updated.id ? { ...r, is_pinned: updated.is_pinned } : r),
              };
            })
        );
      })
      // Reactions
      .on('postgres_changes', { event: '*', schema: 'public', table: 'community_reactions' }, async () => {
        // Re-fetch reactions for visible messages
        setMessages(prev => {
          const allIds = [
            ...prev.map(m => m.id),
            ...prev.flatMap(m => m.replies.map(r => r.id)),
          ];
          supabase
            .from('community_reactions')
            .select('message_id, emoji, firebase_uid')
            .in('message_id', allIds)
            .then(({ data }) => {
              const rxMap: Record<string, { emoji: string; count: number; reacted: boolean }[]> = {};
              for (const rx of data ?? []) {
                if (!rxMap[rx.message_id]) rxMap[rx.message_id] = [];
                const existing = rxMap[rx.message_id].find(r => r.emoji === rx.emoji);
                if (existing) {
                  existing.count++;
                  if (rx.firebase_uid === firebaseUid) existing.reacted = true;
                } else {
                  rxMap[rx.message_id].push({ emoji: rx.emoji, count: 1, reacted: rx.firebase_uid === firebaseUid });
                }
              }
              setMessages(msgs =>
                msgs.map(m => ({
                  ...m,
                  reactions: rxMap[m.id] ?? m.reactions,
                  replies:   m.replies.map(r => ({ ...r, reactions: rxMap[r.id] ?? r.reactions })),
                }))
              );
            });
          return prev;
        });
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [firebaseUid]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Online presence ────────────────────────────────────────────────────────
  const upsertPresence = useCallback(async () => {
    if (!firebaseUid) return;
    await supabase.from('community_presence').upsert({
      firebase_uid: firebaseUid,
      display_name: displayName,
      photo_url:    photoUrl,
      last_seen_at: new Date().toISOString(),
    }, { onConflict: 'firebase_uid' });
  }, [firebaseUid, displayName, photoUrl]);

  useEffect(() => {
    upsertPresence();
    presenceTimer.current = setInterval(upsertPresence, PRESENCE_INTERVAL);
    return () => {
      if (presenceTimer.current) clearInterval(presenceTimer.current);
    };
  }, [upsertPresence]);

  // Poll online users every 15 s
  useEffect(() => {
    async function fetchOnline() {
      const cutoff = new Date(Date.now() - ONLINE_TTL * 1000).toISOString();
      const { data } = await supabase
        .from('community_presence')
        .select('*')
        .gte('last_seen_at', cutoff)
        .order('last_seen_at', { ascending: false })
        .limit(50);
      setOnlineUsers((data ?? []) as OnlineUser[]);
    }
    fetchOnline();
    const t = setInterval(fetchOnline, 15_000);
    return () => clearInterval(t);
  }, []);

  // ── Auto-resize textarea ───────────────────────────────────────────────────
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 140)}px`;
    }
  }, [input]);

  // ── Image attachment ───────────────────────────────────────────────────────
  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.error('Only images are supported.'); return; }
    if (file.size > 4 * 1024 * 1024)    { toast.error('Image must be under 4 MB.'); return; }
    setPendingImage(file);
    setImagePreview(URL.createObjectURL(file));
  }

  function clearImage() {
    setPendingImage(null);
    setImagePreview(null);
    if (fileRef.current) fileRef.current.value = '';
  }

  // ── Upload image to Supabase Storage ──────────────────────────────────────
  async function uploadImage(file: File): Promise<string | null> {
    setUploadingImg(true);
    try {
      const ext  = file.name.split('.').pop() ?? 'jpg';
      const path = `community/${firebaseUid}/${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from('community-images').upload(path, file, { contentType: file.type });
      if (error) {
        // Bucket may not exist yet — try creating it first
        await supabase.storage.createBucket('community-images', { public: true, fileSizeLimit: 4194304 });
        const { error: e2 } = await supabase.storage.from('community-images').upload(path, file, { contentType: file.type });
        if (e2) throw e2;
      }
      const { data: urlData } = supabase.storage.from('community-images').getPublicUrl(path);
      return urlData.publicUrl;
    } catch (err) {
      console.error('Image upload error:', err);
      toast.error('Failed to upload image. Please try again.');
      return null;
    } finally {
      setUploadingImg(false);
    }
  }

  // ── Send message ───────────────────────────────────────────────────────────
  async function handleSend() {
    const text = input.trim();
    if (!text && !pendingImage) return;
    if (!firebaseUid) { toast.error('Please sign in to post.'); return; }
    setSending(true);

    let imageUrl: string | null = null;
    if (pendingImage) {
      imageUrl = await uploadImage(pendingImage);
      if (!imageUrl) { setSending(false); return; }
    }

    const { error } = await supabase.from('community_messages').insert({
      firebase_uid: firebaseUid,
      display_name: displayName,
      photo_url:    photoUrl,
      content:      text || '',
      image_url:    imageUrl,
      reply_to_id:  replyTo?.id ?? null,
    });

    if (error) {
      toast.error('Failed to send message. Please try again.');
    } else {
      setInput('');
      clearImage();
      setReplyTo(null);
    }
    setSending(false);
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  // ── Reaction toggle ────────────────────────────────────────────────────────
  async function handleReaction(msgId: string, emoji: string, reacted: boolean) {
    if (!firebaseUid) return;
    if (reacted) {
      await supabase.from('community_reactions')
        .delete()
        .eq('message_id', msgId)
        .eq('firebase_uid', firebaseUid)
        .eq('emoji', emoji);
    } else {
      await supabase.from('community_reactions').insert({ message_id: msgId, firebase_uid: firebaseUid, emoji });
    }
  }

  // ── Delete ─────────────────────────────────────────────────────────────────
  async function handleDelete(id: string) {
    const { error } = await supabase.from('community_messages')
      .update({ is_deleted: true })
      .eq('id', id);
    if (error) toast.error('Failed to delete message.');
  }

  // ── Pin ────────────────────────────────────────────────────────────────────
  async function handlePin(id: string, pinned: boolean) {
    const { error } = await supabase.from('community_messages')
      .update({ is_pinned: !pinned })
      .eq('id', id);
    if (error) toast.error('Failed to update pin.');
  }

  const canSend = (input.trim().length > 0 || !!pendingImage) && !sending && !uploadingImg;

  // ── Sort: pinned first, then chronological ─────────────────────────────────
  const sorted = [
    ...messages.filter(m => m.is_pinned),
    ...messages.filter(m => !m.is_pinned),
  ];

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <>
      <PageMeta title="Community" description="AlphaTekx Community — talk, share, and connect" />

      <div className="flex flex-col h-full min-h-0 overflow-hidden">

        {/* ── Header ── */}
        <div className="shrink-0 flex items-center justify-between px-4 md:px-6 py-4 border-b border-border/40 bg-background/80 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 border border-primary/20">
              <MessageSquare className="h-4.5 w-4.5 text-primary" style={{ height: '1.125rem', width: '1.125rem' }} />
            </div>
            <div>
              <h1 className="text-base font-black tracking-tight text-foreground uppercase leading-none">Community</h1>
              <p className="text-[10px] text-muted-foreground/50 font-bold uppercase tracking-widest mt-0.5">
                {onlineUsers.length} online now
              </p>
            </div>
          </div>

          {/* Online users toggle (mobile) */}
          <button
            onClick={() => setShowOnline(v => !v)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-secondary/60 border border-border/40 text-xs font-bold text-muted-foreground hover:text-foreground transition-all"
          >
            <Users className="h-3.5 w-3.5 text-primary/70" />
            <span className="hidden md:inline">Online</span>
            <span className="font-black text-primary">{onlineUsers.length}</span>
          </button>
        </div>

        {/* ── Body: feed + online panel ── */}
        <div className="flex flex-1 min-h-0 overflow-hidden">

          {/* ── Message feed ── */}
          <div ref={scrollRef} className="flex-1 min-w-0 overflow-y-auto custom-scrollbar">
            <div className="max-w-3xl mx-auto px-4 md:px-6 py-4 space-y-4">

              {/* Load more */}
              {hasMore && !loading && (
                <div className="flex justify-center pb-2">
                  <button
                    onClick={loadMore}
                    disabled={loadingMore}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-secondary/60 border border-border/40 text-xs font-bold text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-all"
                  >
                    {loadingMore ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ChevronUp className="h-3.5 w-3.5" />}
                    Load earlier messages
                  </button>
                </div>
              )}

              {/* Loading skeleton */}
              {loading && (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex gap-3 animate-pulse">
                      <div className="h-9 w-9 rounded-xl bg-muted shrink-0" />
                      <div className="flex-1 space-y-2">
                        <div className="h-3 w-24 bg-muted rounded-full" />
                        <div className="h-12 bg-muted rounded-2xl" />
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Empty state */}
              {!loading && messages.length === 0 && (
                <div className="flex flex-col items-center justify-center py-16 gap-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 border border-primary/20">
                    <MessageSquare className="h-8 w-8 text-primary" />
                  </div>
                  <div className="text-center space-y-1">
                    <p className="text-base font-black text-foreground">Start the conversation</p>
                    <p className="text-sm text-muted-foreground">Be the first to post in the AlphaTekx community!</p>
                  </div>
                </div>
              )}

              {/* Messages */}
              {sorted.map(msg => (
                <MessageCard
                  key={msg.id}
                  msg={msg}
                  isAdmin={isAdmin}
                  firebaseUid={firebaseUid}
                  onReply={setReplyTo}
                  onDelete={handleDelete}
                  onPin={handlePin}
                  onReaction={handleReaction}
                />
              ))}

              <div ref={bottomRef} />
            </div>
          </div>

          {/* ── Online users panel ── */}
          {showOnline && (
            <div className="hidden md:flex flex-col w-56 shrink-0 border-l border-border/40 bg-background/50">
              <div className="px-4 py-3 border-b border-border/30">
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60">
                  Online — {onlineUsers.length}
                </p>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar px-3 py-3 space-y-2">
                {onlineUsers.map(u => (
                  <div key={u.firebase_uid} className="flex items-center gap-2.5 min-w-0">
                    <div className="relative shrink-0">
                      <Avatar src={u.photo_url} name={u.display_name} size={7} />
                      <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-green-500 border-2 border-background" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-foreground truncate leading-none">{u.display_name}</p>
                      {u.firebase_uid === firebaseUid && (
                        <p className="text-[9px] text-primary font-bold uppercase tracking-widest mt-0.5">You</p>
                      )}
                    </div>
                  </div>
                ))}
                {onlineUsers.length === 0 && (
                  <p className="text-[11px] text-muted-foreground/40 text-center mt-4">No one online yet</p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* ── Composer ── */}
        <div className="shrink-0 border-t border-border/40 bg-background px-4 md:px-6 py-3">
          <div className="max-w-3xl mx-auto space-y-2">

            {/* Reply banner */}
            {replyTo && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-primary/8 border border-primary/20 animate-in fade-in slide-in-from-bottom-1">
                <Reply className="h-3.5 w-3.5 text-primary shrink-0" />
                <span className="text-xs text-primary font-bold truncate flex-1">
                  Replying to <span className="text-foreground">{replyTo.display_name}</span>
                  {replyTo.content && (
                    <span className="text-muted-foreground font-normal"> — {replyTo.content.slice(0, 60)}{replyTo.content.length > 60 ? '…' : ''}</span>
                  )}
                </span>
                <button onClick={() => setReplyTo(null)} className="shrink-0 text-muted-foreground hover:text-foreground transition-colors">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            {/* Image preview */}
            {imagePreview && (
              <div className="relative inline-flex animate-in fade-in">
                <img src={imagePreview} alt="Preview" className="h-20 w-20 rounded-xl object-cover border border-border/60" />
                <button
                  onClick={clearImage}
                  className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center shadow-lg"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}

            {/* Input row */}
            <div className="flex items-end gap-2 bg-secondary/50 border border-border/60 rounded-2xl p-2 focus-within:border-primary/50 transition-all">
              {/* Image attach */}
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={sending || uploadingImg}
                className="h-10 w-10 shrink-0 rounded-xl flex items-center justify-center text-muted-foreground/60 hover:text-primary hover:bg-primary/10 transition-all"
                aria-label="Attach image"
              >
                <Image className="h-4.5 w-4.5" style={{ height: '1.125rem', width: '1.125rem' }} />
              </button>

              {/* Textarea */}
              <textarea
                ref={textareaRef}
                rows={1}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={replyTo ? `Reply to ${replyTo.display_name}…` : 'Share with the community…'}
                disabled={sending || uploadingImg}
                className="flex-1 bg-transparent outline-none border-none resize-none text-sm text-foreground placeholder:text-muted-foreground/40 py-2 px-1 min-h-[40px] max-h-[140px] custom-scrollbar font-medium leading-relaxed"
              />

              {/* Send */}
              <button
                type="button"
                onClick={handleSend}
                disabled={!canSend}
                aria-label="Send message"
                className="h-10 w-10 shrink-0 rounded-xl flex items-center justify-center bg-primary text-primary-foreground shadow-lg shadow-primary/20 hover:bg-primary/90 active:scale-95 transition-all disabled:opacity-35"
              >
                {(sending || uploadingImg) ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </button>
            </div>

            <p className="text-center text-[9px] text-muted-foreground/25 font-bold uppercase tracking-widest">
              AlphaTekx Community · Be respectful · Press Enter to send
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
