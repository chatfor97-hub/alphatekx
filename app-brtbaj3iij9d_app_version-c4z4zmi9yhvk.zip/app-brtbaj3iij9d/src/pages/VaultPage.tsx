import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import {
  Lock, Plus, Trash2, Copy, Check, Eye, EyeOff,
  FileText, Key, Link2, Code2, StickyNote, Search, X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUserSession } from '@/contexts/UserSessionContext';

// ── Types ───────────────────────────────────────────────────────────────────────
type Category = 'note' | 'credential' | 'link' | 'snippet' | 'other';

interface VaultItem {
  id: string;
  title: string;
  content: string;
  category: Category;
  created_at: string;
}

// ── Category config ─────────────────────────────────────────────────────────────
const CATEGORIES: { id: Category; label: string; icon: React.ElementType; color: string }[] = [
  { id: 'note',       label: 'Note',       icon: StickyNote, color: '#f59e0b' },
  { id: 'credential', label: 'Credential', icon: Key,        color: '#a78bfa' },
  { id: 'link',       label: 'Link',       icon: Link2,      color: '#38bdf8' },
  { id: 'snippet',    label: 'Snippet',    icon: Code2,      color: '#34d399' },
  { id: 'other',      label: 'Other',      icon: FileText,   color: '#94a3b8' },
];

function getCat(id: Category) {
  return CATEGORIES.find(c => c.id === id) ?? CATEGORIES[4];
}

// ── Masked content (for credentials) ───────────────────────────────────────────
function MaskedContent({ content, isCred }: { content: string; isCred: boolean }) {
  const [shown, setShown] = useState(false);
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="flex items-start gap-2 min-w-0">
      <p
        className="flex-1 text-sm leading-relaxed break-all min-w-0"
        style={{
          color: '#94a3b8',
          filter: isCred && !shown ? 'blur(5px)' : 'none',
          userSelect: isCred && !shown ? 'none' : 'text',
          transition: 'filter 0.2s',
        }}
      >
        {content || <span style={{ color: '#334155', fontStyle: 'italic' }}>Empty</span>}
      </p>
      <div className="flex items-center gap-1 shrink-0">
        {isCred && (
          <button
            onClick={() => setShown(v => !v)}
            className="p-1.5 rounded-md transition-colors"
            style={{ color: '#475569' }}
            onMouseEnter={e => (e.currentTarget.style.color = '#94a3b8')}
            onMouseLeave={e => (e.currentTarget.style.color = '#475569')}
            title={shown ? 'Hide' : 'Reveal'}
          >
            {shown ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
          </button>
        )}
        <button
          onClick={copy}
          className="p-1.5 rounded-md transition-colors"
          style={{ color: '#475569' }}
          onMouseEnter={e => (e.currentTarget.style.color = '#94a3b8')}
          onMouseLeave={e => (e.currentTarget.style.color = '#475569')}
          title="Copy"
        >
          {copied
            ? <Check className="h-3.5 w-3.5" style={{ color: '#34d399' }} />
            : <Copy className="h-3.5 w-3.5" />}
        </button>
      </div>
    </div>
  );
}

// ── Add item modal ──────────────────────────────────────────────────────────────
interface AddModalProps {
  onAdd: (title: string, content: string, category: Category) => Promise<void>;
  onClose: () => void;
}

function AddModal({ onAdd, onClose }: AddModalProps) {
  const [title,    setTitle]    = useState('');
  const [content,  setContent]  = useState('');
  const [category, setCategory] = useState<Category>('note');
  const [saving,   setSaving]   = useState(false);
  const titleRef = useRef<HTMLInputElement>(null);

  useEffect(() => { titleRef.current?.focus(); }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) { toast.error('Title is required.'); return; }
    setSaving(true);
    await onAdd(title.trim(), content.trim(), category);
    setSaving(false);
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)' }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        className="w-full max-w-lg rounded-2xl overflow-hidden flex flex-col"
        style={{ background: '#0e0f15', border: '1px solid rgba(255,255,255,0.08)', maxHeight: '90dvh' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'rgba(255,255,255,0.07)' }}>
          <div className="flex items-center gap-2">
            <Lock className="h-4 w-4" style={{ color: '#22d3ee' }} />
            <span className="text-sm font-bold" style={{ color: '#f1f5f9' }}>New Vault Item</span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg" style={{ color: '#475569' }}
            onMouseEnter={e => (e.currentTarget.style.color = '#f1f5f9')}
            onMouseLeave={e => (e.currentTarget.style.color = '#475569')}>
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={submit} className="flex flex-col gap-4 p-6 overflow-y-auto">
          {/* Category */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: '#334155' }}>
              Type
            </label>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map(cat => {
                const Icon = cat.icon;
                const active = category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCategory(cat.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all"
                    style={{
                      background: active ? `${cat.color}18` : 'rgba(255,255,255,0.04)',
                      border: `1px solid ${active ? cat.color + '50' : 'rgba(255,255,255,0.08)'}`,
                      color: active ? cat.color : '#475569',
                    }}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    {cat.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest mb-1.5" style={{ color: '#334155' }}>
              Title
            </label>
            <input
              ref={titleRef}
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="Give it a name…"
              className="w-full h-11 rounded-xl px-4 text-sm font-medium focus:outline-none transition-all"
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)',
                color: '#e2e8f0',
                caretColor: '#22d3ee',
              }}
              onFocus={e => (e.currentTarget.style.borderColor = 'rgba(34,211,238,0.4)')}
              onBlur={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)')}
            />
          </div>

          {/* Content */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest mb-1.5" style={{ color: '#334155' }}>
              Content
            </label>
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder={
                category === 'credential' ? 'Paste your key, token, or password here…'
                : category === 'link'       ? 'https://…'
                : category === 'snippet'    ? 'Paste your code snippet here…'
                : 'Write anything you want to store…'
              }
              rows={5}
              spellCheck={false}
              className="w-full rounded-xl px-4 py-3 text-sm font-mono resize-none focus:outline-none transition-all leading-relaxed"
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(255,255,255,0.08)',
                color: '#e2e8f0',
                caretColor: '#22d3ee',
              }}
              onFocus={e => (e.currentTarget.style.borderColor = 'rgba(34,211,238,0.4)')}
              onBlur={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)')}
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="h-10 px-5 rounded-xl text-sm font-bold transition-colors"
              style={{ color: '#475569', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
              onMouseEnter={e => (e.currentTarget.style.color = '#94a3b8')}
              onMouseLeave={e => (e.currentTarget.style.color = '#475569')}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving || !title.trim()}
              className="h-10 px-6 rounded-xl text-sm font-bold transition-all active:scale-95 disabled:opacity-50"
              style={{ background: '#22d3ee', color: '#0b0c10' }}
              onMouseEnter={e => { if (!saving) e.currentTarget.style.background = '#67e8f9'; }}
              onMouseLeave={e => (e.currentTarget.style.background = '#22d3ee')}
            >
              {saving ? 'Saving…' : 'Save to Vault'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ── Main page ───────────────────────────────────────────────────────────────────
export default function VaultPage() {
  const { appUser } = useUserSession();
  const firebaseUid = appUser?.uid ?? '';

  const [items,       setItems]       = useState<VaultItem[]>([]);
  const [loading,     setLoading]     = useState(true);
  const [showAdd,     setShowAdd]     = useState(false);
  const [search,      setSearch]      = useState('');
  const [filterCat,   setFilterCat]   = useState<Category | 'all'>('all');
  const [deletingId,  setDeletingId]  = useState<string | null>(null);

  // ── Load items — filtered by firebase UID ───────────────────────────────────
  async function fetchItems() {
    if (!firebaseUid) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('vault_items')
      .select('id, title, content, category, created_at')
      .eq('user_id', firebaseUid)
      .order('created_at', { ascending: false });
    if (error) { toast.error('Failed to load vault.'); }
    else { setItems(Array.isArray(data) ? data as VaultItem[] : []); }
    setLoading(false);
  }

  useEffect(() => { fetchItems(); }, [firebaseUid]);  // eslint-disable-line react-hooks/exhaustive-deps

  // ── Add item — explicitly sets user_id to firebase UID ──────────────────────
  async function addItem(title: string, content: string, category: Category) {
    if (!firebaseUid) { toast.error('Not signed in.'); return; }
    const { error } = await supabase
      .from('vault_items')
      .insert({ title, content, category, user_id: firebaseUid });
    if (error) { toast.error('Failed to save item.'); return; }
    toast.success('Item saved to vault.');
    setShowAdd(false);
    await fetchItems();
  }

  // ── Delete item ─────────────────────────────────────────────────────────────
  async function deleteItem(id: string) {
    setDeletingId(id);
    const { error } = await supabase.from('vault_items').delete().eq('id', id).eq('user_id', firebaseUid);
    if (error) { toast.error('Failed to delete item.'); }
    else {
      setItems(prev => prev.filter(i => i.id !== id));
      toast.success('Item removed from vault.');
    }
    setDeletingId(null);
  }

  // ── Filtered items ──────────────────────────────────────────────────────────
  const filtered = items.filter(item => {
    const matchSearch = !search || item.title.toLowerCase().includes(search.toLowerCase()) || item.content.toLowerCase().includes(search.toLowerCase());
    const matchCat    = filterCat === 'all' || item.category === filterCat;
    return matchSearch && matchCat;
  });

  const totalByCategory = (cat: Category) => items.filter(i => i.category === cat).length;

  return (
    <div
      className="flex flex-col h-full w-full overflow-hidden"
      style={{ background: '#0b0c10', fontFamily: 'system-ui, sans-serif' }}
    >
      {/* ── Header ── */}
      <div
        className="shrink-0 flex items-center justify-between px-5 md:px-8 py-5 border-b"
        style={{ borderColor: 'rgba(255,255,255,0.07)', background: '#0e0f15' }}
      >
        <div className="flex items-center gap-3 min-w-0">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-xl shrink-0"
            style={{ background: 'rgba(34,211,238,0.08)', border: '1px solid rgba(34,211,238,0.18)' }}
          >
            <Lock className="h-5 w-5" style={{ color: '#22d3ee' }} />
          </div>
          <div className="min-w-0">
            <h1 className="text-base font-black uppercase tracking-tight text-balance" style={{ color: '#f1f5f9' }}>
              App Vault
            </h1>
            <p className="text-[11px] font-medium" style={{ color: '#334155' }}>
              {items.length} item{items.length !== 1 ? 's' : ''} · visible only to you
            </p>
          </div>
        </div>

        <Button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 h-9 px-4 rounded-xl text-xs font-bold shrink-0"
          style={{ background: '#22d3ee', color: '#0b0c10' }}
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">New Item</span>
        </Button>
      </div>

      {/* ── Filters ── */}
      <div
        className="shrink-0 flex items-center gap-3 px-5 md:px-8 py-3 border-b overflow-x-auto"
        style={{ borderColor: 'rgba(255,255,255,0.05)', background: '#0e0f15' }}
      >
        {/* Search */}
        <div
          className="flex items-center gap-2 flex-1 min-w-[140px] max-w-xs h-8 rounded-lg px-3"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <Search className="h-3.5 w-3.5 shrink-0" style={{ color: '#334155' }} />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search vault…"
            className="flex-1 bg-transparent text-xs focus:outline-none"
            style={{ color: '#94a3b8' }}
          />
          {search && (
            <button onClick={() => setSearch('')} style={{ color: '#475569' }}>
              <X className="h-3 w-3" />
            </button>
          )}
        </div>

        {/* Category pills */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => setFilterCat('all')}
            className="text-[10px] font-bold px-3 py-1 rounded-full transition-all"
            style={{
              background: filterCat === 'all' ? 'rgba(34,211,238,0.12)' : 'rgba(255,255,255,0.04)',
              border: `1px solid ${filterCat === 'all' ? 'rgba(34,211,238,0.3)' : 'rgba(255,255,255,0.07)'}`,
              color: filterCat === 'all' ? '#22d3ee' : '#475569',
            }}
          >
            All {items.length > 0 && `(${items.length})`}
          </button>
          {CATEGORIES.map(cat => {
            const count = totalByCategory(cat.id);
            if (count === 0) return null;
            const active = filterCat === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setFilterCat(active ? 'all' : cat.id)}
                className="text-[10px] font-bold px-3 py-1 rounded-full transition-all whitespace-nowrap"
                style={{
                  background: active ? `${cat.color}18` : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${active ? cat.color + '50' : 'rgba(255,255,255,0.07)'}`,
                  color: active ? cat.color : '#475569',
                }}
              >
                {cat.label} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Items list ── */}
      <div className="flex-1 overflow-y-auto min-h-0 px-5 md:px-8 py-6">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div
                key={i}
                className="h-24 rounded-2xl animate-pulse"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)' }}
              />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-5 py-20">
            <div
              className="flex h-16 w-16 items-center justify-center rounded-2xl"
              style={{ background: 'rgba(34,211,238,0.06)', border: '1px solid rgba(34,211,238,0.12)' }}
            >
              <Lock className="h-8 w-8" style={{ color: '#334155' }} />
            </div>
            <div className="text-center space-y-1.5">
              <p className="text-sm font-bold" style={{ color: '#475569' }}>
                {search || filterCat !== 'all' ? 'No items match your filter' : 'Your vault is empty'}
              </p>
              <p className="text-xs" style={{ color: '#1e3a4a' }}>
                {search || filterCat !== 'all' ? 'Try a different search or category' : 'Click New Item to store something securely'}
              </p>
            </div>
            {!search && filterCat === 'all' && (
              <button
                onClick={() => setShowAdd(true)}
                className="flex items-center gap-2 h-9 px-5 rounded-xl text-sm font-bold transition-all"
                style={{ background: '#22d3ee', color: '#0b0c10' }}
              >
                <Plus className="h-4 w-4" />
                Add First Item
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-3 max-w-3xl">
            {filtered.map(item => {
              const cat  = getCat(item.category as Category);
              const Icon = cat.icon;
              const isCred = item.category === 'credential';
              return (
                <div
                  key={item.id}
                  className="rounded-2xl px-5 py-4 transition-all"
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    border: '1px solid rgba(255,255,255,0.07)',
                  }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)')}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.07)')}
                >
                  {/* Item header */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className="flex h-7 w-7 items-center justify-center rounded-lg shrink-0"
                        style={{ background: `${cat.color}12`, border: `1px solid ${cat.color}30` }}
                      >
                        <Icon className="h-3.5 w-3.5" style={{ color: cat.color }} />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-bold truncate" style={{ color: '#e2e8f0' }}>
                          {item.title}
                        </p>
                        <p className="text-[10px] font-medium" style={{ color: '#1e3a4a' }}>
                          {cat.label} · {new Date(item.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => deleteItem(item.id)}
                      disabled={deletingId === item.id}
                      className="shrink-0 p-1.5 rounded-lg transition-colors"
                      style={{ color: '#334155' }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#f87171')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#334155')}
                      title="Delete"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {/* Content */}
                  {item.content && (
                    <MaskedContent content={item.content} isCred={isCred} />
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ── Add modal ── */}
      {showAdd && <AddModal onAdd={addItem} onClose={() => setShowAdd(false)} />}
    </div>
  );
}
