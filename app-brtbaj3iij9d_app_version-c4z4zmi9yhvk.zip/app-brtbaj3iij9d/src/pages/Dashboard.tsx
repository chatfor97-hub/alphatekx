import { useEffect, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import PageMeta from '@/components/common/PageMeta';
import ChatInterface from '@/components/chat/ChatInterface';
import CreditsExhaustedModal from '@/components/payments/CreditsExhaustedModal';
import { useUserSession } from '@/contexts/UserSessionContext';
import { toast } from 'sonner';
import { Zap, CheckCircle2 } from 'lucide-react';
import { formatCredits } from '@/lib/credits';

export default function Dashboard() {
  const { appUser, refreshBalance } = useUserSession();
  const [searchParams] = useSearchParams();
  const navigate       = useNavigate();
  const toastFired     = useRef(false);

  // Auto-sync credit balance from DB on dashboard load
  useEffect(() => {
    refreshBalance();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Detect post-payment redirect — show live success notification once
  useEffect(() => {
    const isSuccess = searchParams.get('payment_success') === '1';
    if (!isSuccess || toastFired.current) return;
    toastFired.current = true;

    // Give refreshBalance a moment to settle, then fire the toast
    const t = setTimeout(async () => {
      await refreshBalance();
      const balance = appUser?.credits;

      toast.custom(() => (
        <div className="flex items-start gap-4 w-full max-w-sm rounded-2xl border border-green-500/30 bg-card shadow-2xl shadow-green-500/10 p-4 animate-in slide-in-from-bottom-4 fade-in duration-300">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-green-500/15 border border-green-500/30">
            <CheckCircle2 className="h-5 w-5 text-green-400" />
          </div>
          <div className="flex-1 min-w-0 space-y-0.5">
            <p className="text-sm font-black text-foreground">Payment Successful! 🎉</p>
            <p className="text-xs text-muted-foreground">
              Your credits have been added to your account.
            </p>
            {balance != null && (
              <div className="flex items-center gap-1.5 pt-1.5">
                <Zap className="h-3.5 w-3.5 text-yellow-400 shrink-0" />
                <span className="text-xs font-black text-primary tabular-nums">
                  {formatCredits(balance)}
                </span>
                <span className="text-xs text-muted-foreground">credits available</span>
              </div>
            )}
          </div>
        </div>
      ), { duration: 6000, position: 'top-right' });

      // Clean payment_success param from URL without triggering a re-render
      navigate('/dashboard', { replace: true });
    }, 800);

    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const creditsExhausted = appUser !== null && (appUser.credits ?? 0) <= 0;

  return (
    <>
      <PageMeta title="Dashboard" description="AlphaTekx AI Operating System Dashboard" />

      {creditsExhausted && <CreditsExhaustedModal />}

      {/* Full-height chat */}
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
        <ChatInterface />
      </div>
    </>
  );
}

