import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, ShieldAlert, Zap, Ban, AlertTriangle } from 'lucide-react';
import PageMeta from '@/components/common/PageMeta';

const SESSION_KEY = 'atx_onboarding_done';

export default function OnboardingPage() {
  const navigate = useNavigate();

  function handleContinue() {
    sessionStorage.setItem(SESSION_KEY, 'true');
    navigate('/dashboard', { replace: true });
  }

  return (
    <>
      <PageMeta title="Important Notice" description="AlphaTekx OS — please read before continuing" />

      {/* Full-screen dark overlay with pulsing red glow */}
      <div className="relative flex min-h-screen items-center justify-center px-4 py-12 bg-[#0a0a0a] overflow-hidden">

        {/* Animated background — red danger pulse */}
        <div
          className="pointer-events-none fixed inset-0 z-0"
          style={{
            background: 'radial-gradient(ellipse 70% 55% at 50% 0%, rgba(220,38,38,0.12) 0%, transparent 70%)',
          }}
        />
        <div
          className="pointer-events-none fixed inset-0 z-0 animate-pulse"
          style={{
            background: 'radial-gradient(ellipse 40% 30% at 50% 100%, rgba(220,38,38,0.07) 0%, transparent 70%)',
            animationDuration: '3s',
          }}
        />

        <div className="relative z-10 w-full max-w-lg space-y-6">

          {/* ── DANGER HEADER ── */}
          <div className="text-center space-y-4">
            {/* Pulsing alert icon */}
            <div className="mx-auto relative w-fit">
              <div className="absolute inset-0 rounded-2xl bg-red-600/20 animate-ping" style={{ animationDuration: '2s' }} />
              <div className="relative flex h-20 w-20 items-center justify-center rounded-2xl bg-red-600/15 border-2 border-red-600/60 shadow-[0_0_40px_rgba(220,38,38,0.4)]">
                <ShieldAlert className="h-10 w-10 text-red-500" />
              </div>
            </div>

            {/* Headline */}
            <div>
              <p className="text-xs font-bold tracking-[0.25em] text-red-500 uppercase mb-2">
                ⚠ Critical Notice — Read Before Continuing
              </p>
              <h1 className="text-3xl md:text-4xl font-black tracking-tight text-white leading-tight text-balance">
                NO REFUNDS<br />
                <span className="text-red-500">AFTER PAYMENT</span>
              </h1>
            </div>
          </div>

          {/* ── NOTICE CARDS ── */}
          <div className="space-y-3">

            {/* No-Refund card — most prominent */}
            <div className="relative overflow-hidden rounded-2xl border-2 border-red-600/60 bg-red-950/40 p-5 shadow-[0_0_30px_rgba(220,38,38,0.2)]">
              {/* Corner badge */}
              <div className="absolute top-3 right-3 flex items-center gap-1 rounded-full bg-red-600 px-2.5 py-1">
                <Ban className="h-3 w-3 text-white" />
                <span className="text-[10px] font-bold text-white uppercase tracking-wider">No Refunds</span>
              </div>
              <div className="flex gap-3 items-start pr-20">
                <AlertTriangle className="h-5 w-5 text-red-400 shrink-0 mt-0.5" />
                <div className="space-y-1.5">
                  <p className="text-sm font-bold text-red-300">All purchases are final & non-refundable</p>
                  <p className="text-sm text-red-200/70 leading-relaxed">
                    Once a payment is processed, credits are <strong className="text-red-300">immediately added</strong> to your account. No refunds, chargebacks, or reversals will be honoured under any circumstances. Review your balance before purchasing.
                  </p>
                </div>
              </div>
            </div>

            {/* Credits deduction card */}
            <div className="relative overflow-hidden rounded-2xl border border-amber-500/40 bg-amber-950/30 p-5 shadow-[0_0_20px_rgba(245,158,11,0.1)]">
              <div className="absolute top-3 right-3 flex items-center gap-1 rounded-full bg-amber-500/20 border border-amber-500/40 px-2.5 py-1">
                <Zap className="h-3 w-3 text-amber-400" />
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">3–5 Credits / Use</span>
              </div>
              <div className="flex gap-3 items-start pr-24">
                <Zap className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1.5">
                  <p className="text-sm font-bold text-amber-300">Credits deducted per tool use</p>
                  <p className="text-sm text-amber-200/70 leading-relaxed">
                    External tools cost <strong className="text-amber-300">5 credits</strong> per launch. Built-in AI systems cost <strong className="text-amber-300">3–5 credits</strong> per generation. Credits are deducted the moment you execute — use them intentionally.
                  </p>
                </div>
              </div>
            </div>

          </div>

          {/* ── ACKNOWLEDGEMENT CTA ── */}
          <div className="space-y-3 pt-2">
            {/* Pulsing red border button */}
            <div className="relative rounded-xl overflow-hidden">
              <div className="absolute inset-0 rounded-xl border-2 border-red-500/50 animate-pulse" style={{ animationDuration: '2s' }} />
              <Button
                onClick={handleContinue}
                className="relative w-full h-14 py-3.5 font-black text-base gap-2 bg-red-600 hover:bg-red-700 text-white border-0 shadow-[0_0_30px_rgba(220,38,38,0.5)] hover:shadow-[0_0_40px_rgba(220,38,38,0.7)] transition-all"
              >
                I Understand — Enter AlphaTekx
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>

            <p className="text-center text-[11px] text-white/25 leading-relaxed">
              By clicking above, you confirm you have read, understood, and agreed to the no-refund policy and credit deduction terms.
            </p>
          </div>

        </div>
      </div>
    </>
  );
}
