import { useState, useEffect } from 'react';
import { X, RefreshCw, Code2 } from 'lucide-react';

const PREVIEW_KEY = 'alphatekx_preview_code';

export default function LivePreviewPage() {
  const [srcdoc, setSrcdoc] = useState<string | null>(null);

  // Read code from localStorage on mount
  useEffect(() => {
    const code = localStorage.getItem(PREVIEW_KEY) ?? '';
    setSrcdoc(code);
  }, []);

  const handleRefresh = () => {
    const code = localStorage.getItem(PREVIEW_KEY) ?? '';
    setSrcdoc(null);
    // Brief null forces iframe remount → clean re-render
    requestAnimationFrame(() => setSrcdoc(code));
  };

  const handleClose = () => {
    window.close();
  };

  return (
    <div
      className="flex flex-col h-[100dvh] w-full overflow-hidden"
      style={{ background: '#0b0c10' }}
    >
      {/* Minimal toolbar */}
      <header
        className="shrink-0 flex items-center gap-3 px-4 h-[44px] border-b"
        style={{ background: '#0e0f15', borderColor: 'rgba(255,255,255,0.07)' }}
      >
        <div className="flex items-center gap-2 shrink-0">
          <Code2 className="h-4 w-4" style={{ color: '#22d3ee' }} />
          <span className="text-xs font-bold tracking-tight" style={{ color: '#94a3b8' }}>
            AlphaTekx&nbsp;<span style={{ color: '#22d3ee' }}>Preview</span>
          </span>
        </div>

        <div className="flex-1" />

        {/* Refresh */}
        <button
          onClick={handleRefresh}
          title="Refresh preview"
          className="flex items-center gap-1.5 h-7 px-3 rounded-md text-[11px] font-semibold transition-colors"
          style={{ color: '#475569' }}
          onMouseEnter={e => (e.currentTarget.style.color = '#94a3b8')}
          onMouseLeave={e => (e.currentTarget.style.color = '#475569')}
        >
          <RefreshCw className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Refresh</span>
        </button>

        {/* Close tab */}
        <button
          onClick={handleClose}
          title="Close preview"
          className="flex items-center justify-center h-7 w-7 rounded-md transition-colors"
          style={{ color: '#475569' }}
          onMouseEnter={e => (e.currentTarget.style.color = '#f87171')}
          onMouseLeave={e => (e.currentTarget.style.color = '#475569')}
        >
          <X className="h-4 w-4" />
        </button>
      </header>

      {/* Full-screen iframe */}
      <div className="flex-1 min-h-0 w-full bg-white">
        {srcdoc !== null && srcdoc !== '' ? (
          <iframe
            key={srcdoc.length}
            srcDoc={srcdoc}
            title="Live Preview"
            sandbox="allow-scripts allow-modals allow-forms allow-popups allow-same-origin"
            className="w-full h-full border-0 block"
          />
        ) : srcdoc === '' ? (
          <div
            className="w-full h-full flex flex-col items-center justify-center gap-4"
            style={{ background: '#0d0f14' }}
          >
            <Code2 className="h-10 w-10" style={{ color: '#334155' }} />
            <div className="text-center space-y-1">
              <p className="text-sm font-bold" style={{ color: '#475569' }}>Nothing to preview</p>
              <p className="text-xs" style={{ color: '#334155' }}>
                Go back to the editor, write some code, then click Run.
              </p>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
