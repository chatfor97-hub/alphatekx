import { useState, useEffect, useCallback, useRef } from 'react';
import { useUserSession } from '@/contexts/UserSessionContext';
import { useNavigate } from 'react-router-dom';
import PageMeta from '@/components/common/PageMeta';
import { supabase } from '@/db/supabase';
import {
  BarChart3, Users, Eye, TrendingUp, Globe, RefreshCw,
  ExternalLink, Search, AlertCircle, Loader2, Activity,
  UserPlus, Zap, Clock, Monitor, Smartphone, Tablet,
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────────────────────
interface AnalyticsSummary {
  generatedAt: string;
  realtime: {
    activeUsers:       number;
    screenViews30min:  number;
    events30min:       number;
    todaySessions:     number;
    topPagesNow:       { page: string; users: number }[];
  };
  last30Days: {
    sessions:         number;
    uniqueVisitors:   number;
    pageViews:        number;
    bounceRate:       number;
    newSignups:       number;
    creditTopups:     number;
    creditTransfers:  number;
  };
  users: {
    totalRegistered:  number;
    signupsToday:     number;
    signupsYesterday: number;
  };
  devices:    { device: string; views: number; pct: number }[];
  topSources: { source: string; sessions: number }[];
  topPages:   { page: string; views: number }[];
}

const REFRESH_MS = 60_000;

// ── Direct Supabase aggregation (no edge function needed) ─────────────────────
async function fetchAnalytics(): Promise<AnalyticsSummary> {
  const now            = new Date();
  const fiveMinAgo     = new Date(now.getTime() -  5 * 60 * 1000).toISOString();
  const thirtyMinAgo   = new Date(now.getTime() - 30 * 60 * 1000).toISOString();
  const todayStart     = new Date(now.toISOString().slice(0, 10) + 'T00:00:00.000Z').toISOString();
  const thirtyDayAgo   = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();
  const yesterdayStart = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();

  const [
    { count: activeUsers },
    { data: activePagesData },
    { count: screenViews30min },
    { data: todayPVData },
    { data: pv30Data },
    { count: totalRegistered },
    { count: signupsToday },
    { count: signupsYesterday },
    { count: signups30d },
    { count: topups30d },
    { count: transfers30d },
  ] = await Promise.all([
    supabase.from('active_sessions').select('*', { count: 'exact', head: true }).gte('last_seen', fiveMinAgo),
    supabase.from('active_sessions').select('page_path').gte('last_seen', fiveMinAgo),
    supabase.from('page_views').select('*', { count: 'exact', head: true }).gte('created_at', thirtyMinAgo),
    supabase.from('page_views').select('session_id').gte('created_at', todayStart),
    supabase.from('page_views').select('session_id,page_path,device_type,referrer_source').gte('created_at', thirtyDayAgo),
    supabase.from('profiles').select('*', { count: 'exact', head: true }),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).gte('created_at', todayStart),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).gte('created_at', yesterdayStart).lt('created_at', todayStart),
    supabase.from('profiles').select('*', { count: 'exact', head: true }).gte('created_at', thirtyDayAgo),
    supabase.from('credit_topups').select('*', { count: 'exact', head: true }).gte('created_at', thirtyDayAgo),
    supabase.from('credit_transfers').select('*', { count: 'exact', head: true }).gte('created_at', thirtyDayAgo),
  ]);

  // Active pages right now
  const activeCounts: Record<string, number> = {};
  for (const r of (activePagesData ?? [])) {
    const p = (r as { page_path: string }).page_path;
    activeCounts[p] = (activeCounts[p] ?? 0) + 1;
  }
  const topPagesNow = Object.entries(activeCounts)
    .sort((a, b) => b[1] - a[1]).slice(0, 6)
    .map(([page, users]) => ({ page, users }));

  // Today's unique sessions
  const todaySessions = new Set(
    (todayPVData ?? []).map((r: { session_id: string }) => r.session_id)
  ).size;

  // 30-day aggregations
  type PVRow = { session_id: string; page_path: string; device_type: string; referrer_source: string | null };
  const rows = (pv30Data ?? []) as PVRow[];
  const uniqueSessions30d = new Set(rows.map(r => r.session_id)).size;

  const sessionPageCounts: Record<string, number> = {};
  for (const r of rows) sessionPageCounts[r.session_id] = (sessionPageCounts[r.session_id] ?? 0) + 1;
  const singlePage = Object.values(sessionPageCounts).filter(c => c === 1).length;
  const bounceRate = uniqueSessions30d > 0
    ? Math.round((singlePage / uniqueSessions30d) * 1000) / 10 : 0;

  const deviceCounts: Record<string, number> = {};
  for (const r of rows) { const d = r.device_type ?? 'desktop'; deviceCounts[d] = (deviceCounts[d] ?? 0) + 1; }
  const deviceTotal = rows.length || 1;
  const devices = ['desktop', 'mobile', 'tablet'].map(d => ({
    device: d.charAt(0).toUpperCase() + d.slice(1),
    views:  deviceCounts[d] ?? 0,
    pct:    Math.round(((deviceCounts[d] ?? 0) / deviceTotal) * 100),
  }));

  const sourceCounts: Record<string, number> = {};
  for (const r of rows) { const s = r.referrer_source ?? 'Direct'; sourceCounts[s] = (sourceCounts[s] ?? 0) + 1; }
  const topSources = Object.entries(sourceCounts).sort((a, b) => b[1] - a[1]).slice(0, 6)
    .map(([source, sessions]) => ({ source, sessions }));

  const pathCounts: Record<string, number> = {};
  for (const r of rows) pathCounts[r.page_path] = (pathCounts[r.page_path] ?? 0) + 1;
  const topPages = Object.entries(pathCounts).sort((a, b) => b[1] - a[1]).slice(0, 8)
    .map(([page, views]) => ({ page, views }));

  return {
    generatedAt: now.toISOString(),
    realtime: {
      activeUsers:      activeUsers      ?? 0,
      screenViews30min: screenViews30min ?? 0,
      events30min:      screenViews30min ?? 0,
      todaySessions,
      topPagesNow,
    },
    last30Days: {
      sessions:        uniqueSessions30d,
      uniqueVisitors:  uniqueSessions30d,
      pageViews:       rows.length,
      bounceRate,
      newSignups:      signups30d      ?? 0,
      creditTopups:    topups30d       ?? 0,
      creditTransfers: transfers30d    ?? 0,
    },
    users: {
      totalRegistered:  totalRegistered  ?? 0,
      signupsToday:     signupsToday     ?? 0,
      signupsYesterday: signupsYesterday ?? 0,
    },
    devices,
    topSources,
    topPages,
  };
}

// ── Sub-components ─────────────────────────────────────────────────────────────
function MetricCard({ icon: Icon, label, value, sub, accent = false, highlight = false }: {
  icon: React.ElementType; label: string; value: string | number;
  sub?: string; accent?: boolean; highlight?: boolean;
}) {
  return (
    <div className={`rounded-2xl border p-5 flex items-start gap-4 h-full ${
      accent ? 'bg-primary/5 border-primary/20' :
      highlight ? 'bg-green-500/5 border-green-500/20' :
      'bg-card border-border/50'
    }`}>
      <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border ${
        accent ? 'bg-primary/15 border-primary/30' :
        highlight ? 'bg-green-500/15 border-green-500/30' :
        'bg-secondary/60 border-border/40'
      }`}>
        <Icon className={`h-5 w-5 ${accent ? 'text-primary' : highlight ? 'text-green-500' : 'text-muted-foreground'}`} />
      </div>
      <div className="min-w-0">
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
        <p className={`text-2xl font-black mt-1 ${accent ? 'text-primary' : highlight ? 'text-green-500' : 'text-foreground'}`}>{value}</p>
        {sub && <p className="text-xs text-muted-foreground/60 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="text-xs font-black uppercase tracking-[0.2em] text-muted-foreground/60 mb-3">{children}</h2>;
}

function LiveDot() {
  return (
    <span className="relative flex h-2 w-2 shrink-0">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
    </span>
  );
}

const DEVICE_ICONS: Record<string, React.ElementType> = {
  Desktop: Monitor,
  Mobile:  Smartphone,
  Tablet:  Tablet,
};

// ── Main component ─────────────────────────────────────────────────────────────
export default function SEODashboard() {
  const { appUser, sessionReady } = useUserSession();
  const navigate    = useNavigate();
  const isAdmin     = appUser?.role === 'admin';

  const [data,       setData]       = useState<AnalyticsSummary | null>(null);
  const [loading,    setLoading]    = useState(true);
  const [error,      setError]      = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [countdown,  setCountdown]  = useState(REFRESH_MS / 1000);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Live active-users count — updated instantly via Realtime on active_sessions changes
  const [liveActiveUsers, setLiveActiveUsers] = useState<number | null>(null);

  const fetchData = useCallback(async () => {
    setError(null);
    try {
      const result = await fetchAnalytics();
      setData(result);
      setLastUpdate(new Date());
      setCountdown(REFRESH_MS / 1000);
    } catch (err) {
      console.error('[SEODashboard]', err);
      setError(err instanceof Error ? err.message : 'Failed to load analytics');
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch the live active-user count directly (last 5 min)
  const fetchLiveCount = useCallback(async () => {
    const since = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const { count } = await supabase
      .from('active_sessions')
      .select('*', { count: 'exact', head: true })
      .gte('last_seen', since);
    setLiveActiveUsers(count ?? 0);
  }, []);

  useEffect(() => {
    if (!sessionReady) return;
    if (!isAdmin) { navigate('/dashboard', { replace: true }); return; }
    fetchData();
    fetchLiveCount();
    const refresh = setInterval(fetchData, REFRESH_MS);
    tickRef.current = setInterval(() => setCountdown(c => c <= 1 ? REFRESH_MS / 1000 : c - 1), 1000);
    return () => { clearInterval(refresh); if (tickRef.current) clearInterval(tickRef.current); };
  }, [sessionReady, isAdmin, navigate, fetchData, fetchLiveCount]);

  // Realtime subscription: re-fetch live count immediately on any active_sessions change
  useEffect(() => {
    if (!sessionReady || !isAdmin) return;
    const channel = supabase
      .channel('seo-active-sessions-live')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'active_sessions' },
        () => { fetchLiveCount(); }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [sessionReady, isAdmin, fetchLiveCount]);

  if (!sessionReady || !isAdmin) return null;

  const signupDelta = (data?.users.signupsToday ?? 0) - (data?.users.signupsYesterday ?? 0);

  return (
    <>
      <PageMeta title="SEO & Analytics" description="AlphaTekx real-time analytics dashboard" />
      <div className="flex flex-col h-full min-h-0 overflow-hidden">

        {/* ── Header ── */}
        <div className="shrink-0 flex items-center justify-between gap-3 px-4 md:px-6 py-4 border-b border-border/40 bg-background/80 backdrop-blur-sm">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 border border-primary/20 shrink-0">
              <BarChart3 className="h-[1.125rem] w-[1.125rem] text-primary" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-black tracking-tight text-foreground uppercase leading-none">Live Analytics</h1>
              <p className="text-[10px] text-muted-foreground/50 font-bold uppercase tracking-widest mt-0.5">
                {lastUpdate ? `Updated ${lastUpdate.toLocaleTimeString()} · refresh in ${countdown}s` : 'Loading real data…'}
              </p>
            </div>
          </div>
          <button
            onClick={() => { setLoading(true); fetchData(); }}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-secondary/60 border border-border/40 text-muted-foreground hover:text-foreground transition-all disabled:opacity-50"
          >
            {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
            Refresh
          </button>
        </div>

        {/* ── Body ── */}
        <div className="flex-1 overflow-y-auto px-4 md:px-6 py-5 space-y-7">

          {error && (
            <div className="rounded-2xl border border-destructive/20 bg-destructive/5 p-4 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-black text-foreground">Failed to load analytics</p>
                <p className="text-xs text-muted-foreground mt-0.5">{error}</p>
              </div>
            </div>
          )}

          {loading && !data ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[...Array(8)].map((_, i) => <div key={i} className="h-28 rounded-2xl bg-muted animate-pulse" />)}
            </div>
          ) : data ? (
            <>
              {/* ══ REAL-TIME (right now) ══ */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <LiveDot />
                  <SectionTitle>Real-Time (Live)</SectionTitle>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <MetricCard icon={Activity}   label="Active Users"    value={liveActiveUsers !== null ? liveActiveUsers : data.realtime.activeUsers}                          sub="On site right now"    accent />
                  <MetricCard icon={Eye}         label="Screen Views"    value={data.realtime.screenViews30min.toLocaleString()}    sub="Last 30 minutes" />
                  <MetricCard icon={TrendingUp}  label="Events"          value={data.realtime.events30min.toLocaleString()}         sub="Last 30 minutes" />
                </div>
              </div>

              {/* ══ ACTIVE PAGES ══ */}
              <div>
                <SectionTitle>Top Pages (Real-Time)</SectionTitle>
                <div className="rounded-2xl border border-border/50 bg-card overflow-hidden">
                  {data.realtime.topPagesNow.length === 0 ? (
                    <p className="px-4 py-6 text-sm text-muted-foreground text-center">No active visitors right now</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full whitespace-nowrap">
                        <thead>
                          <tr className="border-b border-border/30">
                            <th className="text-left text-xs font-black uppercase tracking-widest text-muted-foreground/60 px-4 py-3">Page</th>
                            <th className="text-right text-xs font-black uppercase tracking-widest text-muted-foreground/60 px-4 py-3">Active Users</th>
                          </tr>
                        </thead>
                        <tbody>
                          {data.realtime.topPagesNow.map((p, i) => (
                            <tr key={p.page} className="border-b border-border/20 last:border-0 hover:bg-secondary/30 transition-colors">
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                  <span className="text-[10px] font-black text-muted-foreground/40 w-4">{i + 1}</span>
                                  <Globe className="h-3 w-3 text-primary/60 shrink-0" />
                                  <span className="text-sm font-bold text-foreground">{p.page}</span>
                                </div>
                              </td>
                              <td className="px-4 py-3 text-right">
                                <span className="inline-flex items-center gap-1.5 text-sm font-black text-green-500">
                                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse inline-block" />
                                  {p.users}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>

              {/* ══ LAST 30 DAYS ══ */}
              <div>
                <SectionTitle>Last 30 Days</SectionTitle>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <MetricCard icon={Users}      label="Sessions"      value={data.last30Days.sessions.toLocaleString()}       sub="Unique browser sessions" />
                  <MetricCard icon={UserPlus}   label="Users"         value={data.last30Days.uniqueVisitors.toLocaleString()} sub="Unique visitors" />
                  <MetricCard icon={Eye}        label="Page Views"    value={data.last30Days.pageViews.toLocaleString()}       sub="Total page visits" />
                  <MetricCard icon={BarChart3}  label="Bounce Rate"   value={`${data.last30Days.bounceRate}%`}                sub="Single-page sessions" />
                </div>
              </div>

              {/* ══ TRAFFIC SOURCES + DEVICES ══ */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

                {/* Traffic Sources */}
                <div>
                  <SectionTitle>Traffic Sources</SectionTitle>
                  <div className="rounded-2xl border border-border/50 bg-card overflow-hidden">
                    {data.topSources.length === 0 ? (
                      <p className="px-4 py-6 text-sm text-muted-foreground text-center">No traffic data yet</p>
                    ) : data.topSources.map((s, i) => {
                      const max = data.topSources[0]?.sessions ?? 1;
                      const pct = Math.round((s.sessions / max) * 100);
                      return (
                        <div key={s.source} className={`px-4 py-3 space-y-1.5 ${i < data.topSources.length - 1 ? 'border-b border-border/20' : ''}`}>
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-sm font-bold text-foreground truncate">{s.source}</span>
                            <span className="text-sm font-black text-primary shrink-0">{s.sessions.toLocaleString()}</span>
                          </div>
                          <div className="h-1 w-full rounded-full bg-secondary/50 overflow-hidden">
                            <div className="h-full rounded-full bg-primary/60 transition-all duration-700" style={{ width: `${pct}%` }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Devices */}
                <div>
                  <SectionTitle>Devices</SectionTitle>
                  <div className="rounded-2xl border border-border/50 bg-card overflow-hidden">
                    {data.devices.map((d, i) => {
                      const DevIcon = DEVICE_ICONS[d.device] ?? Monitor;
                      return (
                        <div key={d.device} className={`px-4 py-3 space-y-1.5 ${i < data.devices.length - 1 ? 'border-b border-border/20' : ''}`}>
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 min-w-0">
                              <DevIcon className="h-3.5 w-3.5 text-muted-foreground/60 shrink-0" />
                              <span className="text-sm font-bold text-foreground">{d.device}</span>
                            </div>
                            <span className="text-sm font-black text-primary">{d.pct}%</span>
                          </div>
                          <div className="h-1 w-full rounded-full bg-secondary/50 overflow-hidden">
                            <div className="h-full rounded-full bg-primary transition-all duration-700" style={{ width: `${d.pct}%` }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* ══ USERS & SIGNUPS ══ */}
              <div>
                <SectionTitle>Users & Signups</SectionTitle>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <MetricCard icon={Users}    label="Total Registered"  value={data.users.totalRegistered.toLocaleString()}   sub="All-time accounts" />
                  <MetricCard icon={UserPlus} label="New Signups Today"  value={data.users.signupsToday}                      sub={signupDelta >= 0 ? `+${signupDelta} vs yesterday` : `${signupDelta} vs yesterday`} highlight={data.users.signupsToday > 0} />
                  <MetricCard icon={Zap}      label="Credit Top-Ups"    value={data.last30Days.creditTopups.toLocaleString()} sub="Last 30 days" accent />
                  <MetricCard icon={TrendingUp} label="Transfers / Grants" value={data.last30Days.creditTransfers.toLocaleString()} sub="Last 30 days" />
                </div>
              </div>

              {/* ══ TOP PAGES (30-day) ══ */}
              <div>
                <SectionTitle>Most Visited Pages (Last 30 Days)</SectionTitle>
                <div className="rounded-2xl border border-border/50 bg-card overflow-hidden">
                  {data.topPages.length === 0 ? (
                    <p className="px-4 py-6 text-sm text-muted-foreground text-center">No page view data yet — visits will appear here automatically</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full whitespace-nowrap">
                        <thead>
                          <tr className="border-b border-border/30">
                            <th className="text-left text-xs font-black uppercase tracking-widest text-muted-foreground/60 px-4 py-3">Page</th>
                            <th className="text-right text-xs font-black uppercase tracking-widest text-muted-foreground/60 px-4 py-3">Views</th>
                          </tr>
                        </thead>
                        <tbody>
                          {data.topPages.map((p, i) => {
                            const maxViews = data.topPages[0]?.views ?? 1;
                            const pct = Math.round((p.views / maxViews) * 100);
                            return (
                              <tr key={p.page} className="border-b border-border/20 last:border-0 hover:bg-secondary/30 transition-colors">
                                <td className="px-4 py-3">
                                  <div className="flex items-center gap-3 min-w-0">
                                    <span className="text-[10px] font-black text-muted-foreground/40 w-4 shrink-0">{i + 1}</span>
                                    <div className="min-w-0 flex-1">
                                      <p className="text-sm font-bold text-foreground truncate">{p.page}</p>
                                      <div className="mt-1 h-1 w-full rounded-full bg-secondary/50 overflow-hidden">
                                        <div className="h-full rounded-full bg-primary/50 transition-all duration-500" style={{ width: `${pct}%` }} />
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-4 py-3 text-right text-sm font-black text-primary shrink-0">{p.views.toLocaleString()}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>

              {/* ══ SEO TOOLS ══ */}
              <div>
                <SectionTitle>SEO Tools</SectionTitle>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {[
                    { label: 'Google Search Console', url: 'https://search.google.com/search-console',              icon: Search     },
                    { label: 'Google Analytics',       url: 'https://analytics.google.com',                         icon: BarChart3  },
                    { label: 'PageSpeed Insights',     url: 'https://pagespeed.web.dev/?url=https://alphatekx.name.ng',  icon: TrendingUp },
                  ].map(({ label, url, icon: Icon }) => (
                    <a key={url} href={url} target="_blank" rel="noopener noreferrer"
                      className="flex items-center justify-between gap-3 px-4 py-3.5 rounded-xl border border-border/50 bg-card hover:border-primary/30 hover:bg-primary/5 transition-all group">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Icon className="h-4 w-4 text-primary/60 shrink-0" />
                        <span className="text-sm font-bold text-foreground truncate">{label}</span>
                      </div>
                      <ExternalLink className="h-3.5 w-3.5 text-muted-foreground/40 group-hover:text-primary shrink-0 transition-colors" />
                    </a>
                  ))}
                </div>
              </div>

              {/* ══ SEO INFRASTRUCTURE ══ */}
              <div>
                <SectionTitle>SEO Infrastructure</SectionTitle>
                <div className="rounded-2xl border border-border/50 bg-card overflow-hidden">
                  {[
                    { label: 'sitemap.xml',              status: 'Ready',  url: '/sitemap.xml' },
                    { label: 'robots.txt',                status: 'Ready',  url: '/robots.txt'  },
                    { label: 'Open Graph Tags',           status: 'Active', url: null           },
                    { label: 'Twitter Card Tags',         status: 'Active', url: null           },
                    { label: 'JSON-LD Structured Data',   status: 'Active', url: null           },
                    { label: 'Page View Tracking',        status: 'Active', url: null           },
                    { label: 'Device Detection',          status: 'Active', url: null           },
                    { label: 'Referrer Attribution',      status: 'Active', url: null           },
                    { label: 'Session Heartbeat (60s)',   status: 'Active', url: null           },
                  ].map((item, i, arr) => (
                    <div key={item.label} className={`flex items-center justify-between px-4 py-3 ${i < arr.length - 1 ? 'border-b border-border/20' : ''}`}>
                      <div className="flex items-center gap-2 min-w-0">
                        {item.url ? (
                          <a href={item.url} target="_blank" rel="noopener noreferrer"
                            className="text-sm font-bold text-primary hover:underline underline-offset-2 truncate">
                            {item.label}
                          </a>
                        ) : (
                          <span className="text-sm font-bold text-foreground truncate">{item.label}</span>
                        )}
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full shrink-0 ml-2 bg-green-500/10 text-green-400 border border-green-500/20">
                        {item.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-center gap-2 pb-4">
                <Clock className="h-3 w-3 text-muted-foreground/25" />
                <p className="text-[10px] text-muted-foreground/25 font-bold uppercase tracking-widest">
                  100% real data from AlphaTekx database · auto-refreshes every 60 seconds
                </p>
              </div>
            </>
          ) : null}
        </div>
      </div>
    </>
  );
}

