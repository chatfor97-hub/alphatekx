import PageMeta from '@/components/common/PageMeta';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function Privacy() {
  return (
    <>
      <PageMeta
        title="Privacy Policy — AlphaTekx AI"
        description="Read the AlphaTekx AI Privacy Policy. Learn how we collect, use, and protect your data on our AI Operating System platform."
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://alphatekx.name.ng/" },
            { "@type": "ListItem", "position": 2, "name": "Privacy Policy", "item": "https://alphatekx.name.ng/privacy" },
          ],
        }) }}
      />
      <div className="mx-auto max-w-3xl px-4 py-8 md:py-12">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>

        <Card className="glass border border-white/10">
          <CardHeader>
            <CardTitle className="text-xl font-bold tracking-tight">Privacy Policy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-sm leading-relaxed text-muted-foreground">
            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">1. Information We Collect</h2>
              <p>
                We collect information you provide directly, such as your email address, phone number,
                and account credentials. We also collect usage data and technical information to improve the Platform.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">2. How We Use Your Information</h2>
              <p>
                We use your information to provide, maintain, and improve AlphaTekx services,
                to authenticate your identity, to communicate with you, and to ensure platform security.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">3. Data Security</h2>
              <p>
                We implement industry-standard security measures to protect your data, including encryption
                in transit and at rest. However, no method of transmission over the Internet is 100% secure.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">4. Data Sharing</h2>
              <p>
                We do not sell your personal information. We may share data with service providers
                who assist in operating the Platform, or when required by law.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">5. Your Rights</h2>
              <p>
                You have the right to access, correct, or delete your personal information.
                You may also request a copy of your data or object to certain processing activities.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">6. Retention</h2>
              <p>
                We retain your information for as long as your account is active or as needed to provide services.
                You may delete your account at any time, and we will remove your data in accordance with applicable laws.
              </p>
            </section>

            <section>
              <h2 className="text-base font-semibold text-foreground mb-2">7. Contact</h2>
              <p>
                For privacy-related inquiries, contact us at privacy@alphatekx.com.
              </p>
            </section>

            <p className="text-xs text-muted-foreground pt-4 border-t border-white/10">
              Last updated: May 20, 2026. Please modify this Privacy Policy to suit your legal requirements.
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
