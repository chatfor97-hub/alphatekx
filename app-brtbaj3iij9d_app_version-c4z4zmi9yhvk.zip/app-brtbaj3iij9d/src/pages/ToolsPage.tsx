import { useState } from 'react';
import PageMeta from '@/components/common/PageMeta';
import ToolsTab from '@/components/workspace/ToolsTab';
import WorkspaceView from '@/components/workspace/WorkspaceView';
import MobileToolModal from '@/components/workspace/MobileToolModal';
import CreditsExhaustedModal from '@/components/payments/CreditsExhaustedModal';
import { useIsMobile } from '@/hooks/use-mobile';
import { useUserSession } from '@/contexts/UserSessionContext';
import { deductCredits, formatCredits } from '@/lib/credits';
import { toast } from 'sonner';

const TOOL_COST = 5;

export default function ToolsPage() {
  const isMobile = useIsMobile();
  const { appUser, refreshBalance } = useUserSession();

  const [workspaceOpen, setWorkspaceOpen] = useState(false);
  const [activeTool,    setActiveTool]    = useState<{ name: string; url: string } | null>(null);
  const [deducting,     setDeducting]     = useState(false);

  const creditsExhausted = appUser !== null && (appUser.credits ?? 0) <= 0;

  async function openTool(name: string, url: string) {
    if (deducting || creditsExhausted) return;
    setDeducting(true);
    const result = await deductCredits(TOOL_COST);
    setDeducting(false);
    if (!result.success) { await refreshBalance(); return; }
    await refreshBalance();
    setActiveTool({ name, url });
    setWorkspaceOpen(true);
    toast.success(`${TOOL_COST} credits used · ${formatCredits(result.newBalance)} remaining`, { duration: 2500 });
  }

  function closeTool() {
    setWorkspaceOpen(false);
  }

  return (
    <>
      <PageMeta title="Tools" description="AlphaTekx AI Tools & Built-In Systems" />

      {creditsExhausted && <CreditsExhaustedModal />}

      {/* Mobile: full-screen overlay */}
      {isMobile && workspaceOpen && activeTool && (
        <MobileToolModal
          toolName={activeTool.name}
          toolUrl={activeTool.url}
          onClose={closeTool}
        />
      )}

      {/* Desktop: tools list + side workspace panel */}
      <div className="flex-1 flex flex-row min-h-0 overflow-hidden">
        {/* Tools list */}
        <div
          className="flex flex-col min-h-0 transition-all duration-300 ease-in-out"
          style={{ flex: !isMobile && workspaceOpen ? '0 0 55%' : '1 1 100%' }}
        >
          <ToolsTab onOpenTool={openTool} deducting={deducting} />
        </div>

        {/* Desktop divider */}
        {!isMobile && workspaceOpen && (
          <div className="w-px bg-white/10 shrink-0" />
        )}

        {/* Desktop workspace panel */}
        {!isMobile && (
          <div
            className={`flex flex-col min-h-0 overflow-hidden transition-all duration-300 ease-in-out ${
              workspaceOpen ? 'w-[45%] opacity-100' : 'w-0 opacity-0 pointer-events-none'
            }`}
          >
            {activeTool && (
              <WorkspaceView
                toolName={activeTool.name}
                toolUrl={activeTool.url}
                onClose={closeTool}
              />
            )}
          </div>
        )}
      </div>
    </>
  );
}
