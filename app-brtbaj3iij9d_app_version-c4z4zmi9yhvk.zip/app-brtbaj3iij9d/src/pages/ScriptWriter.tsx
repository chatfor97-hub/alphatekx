import { useState, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import {
  Zap,
  Play,
  RefreshCw,
  Copy,
  Check,
  ChevronRight,
  Clapperboard,
  Lightbulb,
  TrendingUp,
  Megaphone,
  DollarSign,
  Laptop,
} from 'lucide-react';
import { useUserSession } from '@/contexts/UserSessionContext';
import { deductCredits } from '@/lib/credits';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
interface ScriptSection {
  heading: string;
  content: string;
}

interface SuggestionCard {
  icon: React.ElementType;
  topic: string;
  audience: string;
  tone: string;
  duration: string;
  color: string;
}

// ---------------------------------------------------------------------------
// Template suggestion cards
// ---------------------------------------------------------------------------
const SUGGESTIONS: SuggestionCard[] = [
  {
    icon: DollarSign,
    topic: 'How to make ₦500k/month with AI tools',
    audience: 'Nigerian freelancers & side hustlers aged 20–35',
    tone: 'Energetic, inspiring, motivational',
    duration: '10 minutes',
    color: 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/30',
  },
  {
    icon: Laptop,
    topic: 'Top 5 free tools every Nigerian freelancer needs',
    audience: 'Tech-curious Nigerians aged 18–30 starting online careers',
    tone: 'Practical, conversational, helpful',
    duration: '8 minutes',
    color: 'from-blue-500/20 to-blue-600/10 border-blue-500/30',
  },
  {
    icon: TrendingUp,
    topic: 'Why Nigerian startups fail and how to avoid it',
    audience: 'Nigerian entrepreneurs, founders, and ambitious students',
    tone: 'Bold, thought-provoking, real-talk',
    duration: '12 minutes',
    color: 'from-orange-500/20 to-orange-600/10 border-orange-500/30',
  },
  {
    icon: Lightbulb,
    topic: 'How to build a tech career in Nigeria without a degree',
    audience: 'Young Africans seeking digital and tech careers',
    tone: 'Motivational, honest, street-smart',
    duration: '15 minutes',
    color: 'from-purple-500/20 to-purple-600/10 border-purple-500/30',
  },
  {
    icon: DollarSign,
    topic: 'Side hustles that pay in dollars from Nigeria',
    audience: 'Nigerians seeking forex income and remote work',
    tone: 'Hype, informative, fast-paced',
    duration: '10 minutes',
    color: 'from-yellow-500/20 to-yellow-600/10 border-yellow-500/30',
  },
  {
    icon: Megaphone,
    topic: 'The truth about growing on social media as an African creator',
    audience: 'African content creators aged 16–30',
    tone: 'Honest, relatable, hype energy',
    duration: '12 minutes',
    color: 'from-pink-500/20 to-pink-600/10 border-pink-500/30',
  },
];

const DURATION_OPTIONS = [
  '3 minutes',
  '5 minutes',
  '8 minutes',
  '10 minutes',
  '12 minutes',
  '15 minutes',
  '20 minutes',
  '25 minutes',
  '30 minutes',
];

const SCRIPT_COST = 15;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function parseScriptSections(raw: string): ScriptSection[] {
  // Split on ## headings (preserve heading in each section)
  const parts = raw.split(/(?=^## )/m).filter(Boolean);
  return parts.map((part) => {
    const lines = part.split('\n');
    const heading = lines[0].replace(/^##\s*/, '').trim();
    const content = lines.slice(1).join('\n').trim();
    return { heading, content };
  });
}

function CopyButton({ text, className = '' }: { text: string; className?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }, [text]);

  return (
    <button
      onClick={handleCopy}
      title="Copy section"
      className={`flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded-md hover:bg-white/5 ${className}`}
    >
      {copied ? (
        <Check className="h-3.5 w-3.5 text-emerald-400" />
      ) : (
        <Copy className="h-3.5 w-3.5" />
      )}
      {copied ? 'Copied' : 'Copy'}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------
export default function ScriptWriter() {
  const { appUser, refreshBalance } = useUserSession();

  // Form state
  const [topic, setTopic] = useState('');
  const [audience, setAudience] = useState('');
  const [tone, setTone] = useState('');
  const [duration, setDuration] = useState('');

  // Free-form quick prompt
  const [quickPrompt, setQuickPrompt] = useState('');

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [streamedText, setStreamedText] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const [sections, setSections] = useState<ScriptSection[]>([]);

  const abortRef = useRef<AbortController | null>(null);
  const outputRef = useRef<HTMLDivElement>(null);

  const credits = appUser?.credits ?? 0;
  const hasEnoughCredits = credits >= SCRIPT_COST;
  const isFormBlank = !topic && !audience && !tone && !duration;

  // Apply suggestion card
  const applySuggestion = (card: SuggestionCard) => {
    setTopic(card.topic);
    setAudience(card.audience);
    setTone(card.tone);
    setDuration(card.duration);
    setQuickPrompt('');
    setStreamedText('');
    setIsComplete(false);
    setSections([]);
  };

  // Apply free-form quick prompt → fills topic, defaults for rest
  const applyQuickPrompt = () => {
    const trimmed = quickPrompt.trim();
    if (!trimmed) return;
    // Strip leading intent phrases so the topic is clean
    const cleaned = trimmed
      .replace(/^(make me a script (about|for|on)?|write a script (about|for|on)?|script (about|for|on)?)\s*/i, '')
      .replace(/^(a |an )/, '');
    setTopic(cleaned.charAt(0).toUpperCase() + cleaned.slice(1));
    if (!audience) setAudience('General audience interested in this topic');
    if (!tone) setTone('Engaging, conversational, high-energy');
    if (!duration) setDuration('10 minutes');
    setQuickPrompt('');
    setStreamedText('');
    setIsComplete(false);
    setSections([]);
  };

  // Reset output for regeneration
  const resetOutput = () => {
    setStreamedText('');
    setIsComplete(false);
    setSections([]);
  };

  // Main generation function
  const generateScript = useCallback(async () => {
    if (!topic.trim() || !audience.trim() || !tone.trim() || !duration) {
      toast.error('Please fill in all fields before generating.');
      return;
    }
    if (!hasEnoughCredits) {
      toast.error(`You need ${SCRIPT_COST} credits to generate a script.`);
      return;
    }

    // Deduct credits first
    const result = await deductCredits(SCRIPT_COST);
    if (!result.success) {
      toast.error(result.error ?? 'Failed to deduct credits. Please try again.');
      return;
    }
    await refreshBalance();

    resetOutput();
    setIsGenerating(true);

    abortRef.current = new AbortController();

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const response = await fetch(`${supabaseUrl}/functions/v1/script-writer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${supabaseAnonKey}`,
          apikey: supabaseAnonKey,
        },
        body: JSON.stringify({ topic, audience, tone, duration }),
        signal: abortRef.current.signal,
      });

      if (!response.ok || !response.body) {
        const errText = await response.text().catch(() => '');
        throw new Error(errText || `Request failed: ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let accumulated = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          if (!line.startsWith('data:')) continue;
          const dataStr = line.slice(5).trim();
          if (!dataStr || dataStr === '[DONE]') continue;

          try {
            const frame = JSON.parse(dataStr);
            const chunk = frame?.choices?.[0]?.delta?.content ?? '';
            if (chunk) {
              accumulated += chunk;
              setStreamedText(accumulated);
              // Auto-scroll output panel
              if (outputRef.current) {
                outputRef.current.scrollTop = outputRef.current.scrollHeight;
              }
            }
          } catch {
            // incomplete frame — skip
          }
        }
      }

      // Parse completed output into sections
      const parsed = parseScriptSections(accumulated);
      setSections(parsed);
      setIsComplete(true);
      toast.success('Script generated successfully!');
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') return;
      const msg = err instanceof Error ? err.message : 'Generation failed. Please try again.';
      toast.error(msg);
    } finally {
      setIsGenerating(false);
    }
  }, [topic, audience, tone, duration, hasEnoughCredits, refreshBalance]);

  const handleRegenerate = () => {
    generateScript();
  };

  const copyAll = () => {
    if (!streamedText) return;
    navigator.clipboard.writeText(streamedText).then(() => {
      toast.success('Full script copied to clipboard!');
    });
  };

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------
  return (
    <div className="flex flex-col md:flex-row h-full w-full overflow-hidden">
      {/* ─── LEFT PANEL: Form ─────────────────────────────────────── */}
      <div className="md:w-[38%] shrink-0 flex flex-col border-r border-white/10 overflow-y-auto">
        {/* Header */}
        <div className="px-5 pt-5 pb-4 border-b border-white/10">
          <div className="flex items-center gap-2.5 mb-1">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 border border-primary/20 shrink-0">
              <Clapperboard className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-balance">Script Writer</h1>
              <p className="text-[11px] text-muted-foreground">AlphaTekx Elite Video Producer</p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground text-pretty mt-2 leading-relaxed">
            Generate high-retention YouTube scripts built for the African tech and digital creator
            ecosystem — culturally resonant, conversational, and algorithm-ready.
          </p>
        </div>

        {/* ── Quick Prompt ──────────────────────────────── */}
        <div className="px-5 pt-4 pb-3 border-b border-white/10">
          <p className="text-[10px] font-black text-primary/70 uppercase tracking-[0.18em] mb-2">
            Quick Prompt
          </p>
          <div className="relative">
            <textarea
              rows={2}
              value={quickPrompt}
              onChange={e => setQuickPrompt(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); applyQuickPrompt(); }
              }}
              placeholder='Type it naturally — "Make me a script about how to earn online in Nigeria" — and hit Go'
              className="w-full px-3 py-2.5 pr-16 rounded-xl bg-card border border-border text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/50 resize-none font-medium leading-relaxed transition-all"
            />
            <button
              type="button"
              disabled={!quickPrompt.trim()}
              onClick={applyQuickPrompt}
              className="absolute right-2 bottom-2 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-black uppercase tracking-wider disabled:opacity-30 hover:bg-primary/90 transition-all"
            >
              Go →
            </button>
          </div>
          <p className="text-[10px] text-muted-foreground/40 mt-1.5 font-medium">
            Press Go or Enter — it auto-fills the fields below so you can fine-tune before generating.
          </p>
        </div>

        {/* Suggestion Cards — shown when form is blank */}
        {isFormBlank && (
          <div className="px-5 pt-4 pb-2">
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">
              Quick start — click any idea
            </p>
            <div className="space-y-2">
              {SUGGESTIONS.map((card, i) => {
                const Icon = card.icon;
                return (
                  <button
                    key={i}
                    onClick={() => applySuggestion(card)}
                    className={`w-full text-left px-3 py-2.5 rounded-xl border bg-gradient-to-r ${card.color} hover:opacity-90 transition-all group`}
                  >
                    <div className="flex items-start gap-2.5">
                      <Icon className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-foreground text-pretty leading-snug">
                          {card.topic}
                        </p>
                        <p className="text-[10px] text-muted-foreground mt-0.5 truncate">
                          {card.tone} · {card.duration}
                        </p>
                      </div>
                      <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-foreground shrink-0 ml-auto mt-0.5 transition-colors" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Form */}
        <div className="px-5 py-4 space-y-4 flex-1">
          <div className="space-y-1.5">
            <Label htmlFor="topic" className="text-xs font-medium text-muted-foreground">
              Topic
            </Label>
            <Input
              id="topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. How to make ₦500k/month with AI tools"
              className="text-sm bg-card border-border focus:border-primary/50 h-9"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="audience" className="text-xs font-medium text-muted-foreground">
              Target Audience
            </Label>
            <Input
              id="audience"
              value={audience}
              onChange={(e) => setAudience(e.target.value)}
              placeholder="e.g. Nigerian freelancers aged 20–35"
              className="text-sm bg-card border-border focus:border-primary/50 h-9"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="tone" className="text-xs font-medium text-muted-foreground">
              Video Tone / Style
            </Label>
            <Input
              id="tone"
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              placeholder="e.g. Energetic, motivational, real-talk"
              className="text-sm bg-card border-border focus:border-primary/50 h-9"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="duration" className="text-xs font-medium text-muted-foreground">
              Estimated Duration
            </Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger
                id="duration"
                className="text-sm bg-card border-border focus:border-primary/50 h-9"
              >
                <SelectValue placeholder="Select duration…" />
              </SelectTrigger>
              <SelectContent>
                {DURATION_OPTIONS.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Generate button + credit info */}
        <div className="px-5 pb-5 pt-2 border-t border-white/10 space-y-2.5">
          {/* Credit cost chip */}
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Zap className="h-3.5 w-3.5 text-yellow-400" />
              <span>Cost: <strong className="text-foreground">{SCRIPT_COST} credits</strong></span>
            </div>
            <span
              className={`font-semibold tabular-nums ${
                hasEnoughCredits ? 'text-emerald-400' : 'text-destructive'
              }`}
            >
              Balance: {credits}
            </span>
          </div>

          {!hasEnoughCredits && (
            <p className="text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-lg px-3 py-2">
              Insufficient credits. You need at least {SCRIPT_COST} credits to generate a script.
              Top up from the sidebar.
            </p>
          )}

          <Button
            onClick={generateScript}
            disabled={isGenerating || !hasEnoughCredits}
            className="w-full h-10 font-semibold text-sm gap-2"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                Generating Script…
              </>
            ) : (
              <>
                <Play className="h-4 w-4" />
                Generate Script ({SCRIPT_COST} Credits)
              </>
            )}
          </Button>
        </div>
      </div>

      {/* ─── RIGHT PANEL: Output ──────────────────────────────────── */}
      <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
        {/* Output header bar */}
        {(isGenerating || streamedText) && (
          <div className="px-5 py-3 border-b border-white/10 flex items-center gap-2 shrink-0">
            <span className="text-xs font-semibold text-muted-foreground flex-1">
              {isGenerating ? (
                <span className="flex items-center gap-1.5">
                  <span className="inline-flex gap-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce [animation-delay:0ms]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce [animation-delay:150ms]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce [animation-delay:300ms]" />
                  </span>
                  Writing your script…
                </span>
              ) : (
                'Script ready'
              )}
            </span>
            {isComplete && (
              <>
                <button
                  onClick={copyAll}
                  className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground px-2.5 py-1.5 rounded-lg hover:bg-white/5 transition-colors border border-white/10"
                >
                  <Copy className="h-3.5 w-3.5" />
                  Copy All
                </button>
                <button
                  onClick={handleRegenerate}
                  disabled={isGenerating || !hasEnoughCredits}
                  className="flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 px-2.5 py-1.5 rounded-lg hover:bg-primary/10 transition-colors border border-primary/20 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  Regenerate
                </button>
              </>
            )}
          </div>
        )}

        {/* Output content area */}
        <div ref={outputRef} className="flex-1 overflow-y-auto px-5 py-5">
          {/* Empty state */}
          {!isGenerating && !streamedText && (
            <div className="flex flex-col items-center justify-center h-full text-center gap-4 py-16">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 border border-primary/20">
                <Clapperboard className="h-8 w-8 text-primary/60" />
              </div>
              <div className="space-y-1.5 max-w-xs">
                <h3 className="text-sm font-semibold text-balance">Your script will appear here</h3>
                <p className="text-xs text-muted-foreground text-pretty leading-relaxed">
                  Fill in the details on the left or click a suggestion card to get started. Your
                  fully structured 8-part script streams in real time.
                </p>
              </div>
              <div className="flex flex-wrap justify-center gap-2 mt-2">
                {['Cold Open', 'Promise Lock', 'Core Points', 'Pattern Break', 'Final Payoff', 'CTA'].map(
                  (label) => (
                    <span
                      key={label}
                      className="px-2.5 py-1 rounded-full text-[10px] font-medium bg-primary/8 border border-primary/20 text-primary/80"
                    >
                      {label}
                    </span>
                  )
                )}
              </div>
            </div>
          )}

          {/* Streaming live text (before sections are parsed) */}
          {(isGenerating || (streamedText && !isComplete)) && (
            <div className="prose prose-invert prose-sm max-w-none">
              <pre className="whitespace-pre-wrap font-sans text-sm text-foreground/90 leading-relaxed">
                {streamedText}
                {isGenerating && (
                  <span className="inline-block w-0.5 h-4 bg-primary ml-0.5 animate-pulse align-text-bottom" />
                )}
              </pre>
            </div>
          )}

          {/* Parsed sections (after generation completes) */}
          {isComplete && sections.length > 0 && (
            <div className="space-y-4">
              {sections.map((section, idx) => (
                <div
                  key={idx}
                  className="rounded-xl border border-white/10 bg-card/50 overflow-hidden"
                >
                  {/* Section header */}
                  <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/8 bg-white/3">
                    <h3 className="text-xs font-semibold text-foreground/90 text-balance leading-snug">
                      {section.heading}
                    </h3>
                    <CopyButton
                      text={`## ${section.heading}\n\n${section.content}`}
                    />
                  </div>
                  {/* Section body */}
                  <div className="px-4 py-3">
                    <pre className="whitespace-pre-wrap font-sans text-sm text-foreground/80 leading-relaxed text-pretty">
                      {section.content}
                    </pre>
                  </div>
                </div>
              ))}

              {/* Bottom copy all */}
              <div className="flex justify-center pt-2 pb-4">
                <button
                  onClick={copyAll}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground px-4 py-2 rounded-xl border border-white/10 hover:border-white/20 hover:bg-white/5 transition-all"
                >
                  <Copy className="h-4 w-4" />
                  Copy Full Script
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
