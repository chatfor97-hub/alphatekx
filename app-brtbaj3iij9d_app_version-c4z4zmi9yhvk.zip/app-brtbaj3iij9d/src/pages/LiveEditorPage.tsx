import { useState, useEffect, useRef } from 'react';
import { Play, Trash2, Copy, Check, ChevronLeft, Code2, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

// ── localStorage keys & TTL ──────────────────────────────────────────────────
const STORAGE_KEY = 'alphatekx_live_editor_v2';
const PREVIEW_KEY = 'alphatekx_preview_code';
const TTL_MS      = 24 * 60 * 60 * 1000;

interface Stored { code: string; savedAt: number }

const DEFAULT_CODE = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My Page</title>
  <style>
    body {
      margin: 0;
      font-family: system-ui, sans-serif;
      background: #0b0c10;
      color: #e2e8f0;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }
    h1 { color: #22d3ee; }
    p  { color: #94a3b8; line-height: 1.6; }
  </style>
</head>
<body>
  <div style="text-align:center;padding:3rem 2rem">
    <h1>Hello, World!</h1>
    <p>Edit this code, then click <strong>Run</strong> to preview it.</p>
  </div>
</body>
</html>`;

function loadCode(): string {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_CODE;
    const { code, savedAt }: Stored = JSON.parse(raw);
    if (Date.now() - savedAt > TTL_MS) { localStorage.removeItem(STORAGE_KEY); return DEFAULT_CODE; }
    return code;
  } catch { return DEFAULT_CODE; }
}

function persistCode(code: string) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ code, savedAt: Date.now() } satisfies Stored));
}

// ── Copy button ──────────────────────────────────────────────────────────────
function CopyBtn({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setDone(true); setTimeout(() => setDone(false), 1800); }}
      title="Copy code"
      className="flex items-center gap-1.5 h-8 px-3 rounded-md text-[11px] font-semibold transition-colors"
      style={{ color: '#475569' }}
      onMouseEnter={e => (e.currentTarget.style.color = '#94a3b8')}
      onMouseLeave={e => (e.currentTarget.style.color = '#475569')}
    >
      {done ? <Check className="h-3.5 w-3.5" style={{ color: '#34d399' }} /> : <Copy className="h-3.5 w-3.5" />}
      {done ? 'Copied' : 'Copy'}
    </button>
  );
}

// ── Main ─────────────────────────────────────────────────────────────────────
export default function LiveEditorPage() {
  const [code, setCode]   = useState(loadCode);
  const [hasRun, setHasRun] = useState(false);
  const textareaRef       = useRef<HTMLTextAreaElement>(null);
  const saveTimer         = useRef<ReturnType<typeof setTimeout> | null>(null);

  // True when the editor has real user content (not the default template, not empty)
  const hasContent = code.trim() !== '' && code.trim() !== DEFAULT_CODE.trim();

  // Auto-save only (debounced 600 ms) — no auto-run
  useEffect(() => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => persistCode(code), 600);
    return () => { if (saveTimer.current) clearTimeout(saveTimer.current); };
  }, [code]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = e.currentTarget;
      const s = ta.selectionStart, en = ta.selectionEnd;
      const next = code.substring(0, s) + '  ' + code.substring(en);
      setCode(next);
      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = s + 2;
          textareaRef.current.selectionEnd   = s + 2;
        }
      });
    }
  };

  const handleClear = () => {
    setCode('');
    localStorage.removeItem(STORAGE_KEY);
    textareaRef.current?.focus();
  };

  // Save to preview key then open full-screen preview in a new tab
  const handleRun = () => {
    setHasRun(true);
    localStorage.setItem(PREVIEW_KEY, code);
    window.open('/tools/live-preview', '_blank', 'noopener');
  };

  return (
    <div
      className="flex flex-col h-[100dvh] w-full overflow-hidden"
      style={{ background: '#0b0c10', fontFamily: 'system-ui, sans-serif' }}
    >
      {/* ── Header ── */}
      <header
        className="shrink-0 flex items-center gap-3 px-5 h-[52px] border-b overflow-visible"
        style={{ background: '#0e0f15', borderColor: 'rgba(255,255,255,0.07)' }}
      >
        <Link
          to="/dashboard"
          className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-widest transition-colors shrink-0"
          style={{ color: '#475569' }}
          onMouseEnter={e => (e.currentTarget.style.color = '#94a3b8')}
          onMouseLeave={e => (e.currentTarget.style.color = '#475569')}
        >
          <ChevronLeft className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Back</span>
        </Link>

        <span style={{ width: 1, height: 20, background: 'rgba(255,255,255,0.08)', flexShrink: 0 }} />

        <div className="flex items-center gap-2 shrink-0">
          <Code2 className="h-4 w-4" style={{ color: '#22d3ee' }} />
          <span className="text-sm font-bold tracking-tight" style={{ color: '#f1f5f9' }}>
            AlphaTekx&nbsp;<span style={{ color: '#22d3ee' }}>Code Studio</span>
          </span>
        </div>

        <div className="flex-1" />

        <span className="hidden md:block text-[11px] font-medium mr-1" style={{ color: '#1e3a4a' }}>
          {code.split('\n').length} lines
        </span>

        <CopyBtn text={code} />

        <button
          onClick={handleClear}
          title="Clear editor"
          className="flex items-center justify-center h-8 w-8 rounded-md transition-colors"
          style={{ color: '#475569' }}
          onMouseEnter={e => (e.currentTarget.style.color = '#f87171')}
          onMouseLeave={e => (e.currentTarget.style.color = '#475569')}
        >
          <Trash2 className="h-4 w-4" />
        </button>

        {/* Run button — glows and pulses once real code is pasted */}
        <div className="relative flex flex-col items-center shrink-0">
          {/* Pulsing ring — only when content present and not yet run */}
          {hasContent && !hasRun && (
            <span
              className="pointer-events-none absolute inset-0 rounded-md animate-ping"
              style={{ background: 'rgba(34,211,238,0.25)' }}
            />
          )}
          <button
            onClick={handleRun}
            className="relative flex items-center gap-2 h-10 px-5 rounded-md text-[13px] font-black uppercase tracking-wider transition-all active:scale-95"
            style={{
              background: hasContent ? '#22d3ee' : 'rgba(34,211,238,0.25)',
              color: hasContent ? '#0b0c10' : 'rgba(34,211,238,0.5)',
              boxShadow: hasContent && !hasRun ? '0 0 18px rgba(34,211,238,0.55), 0 0 40px rgba(34,211,238,0.2)' : 'none',
              transition: 'background 0.3s, box-shadow 0.3s, color 0.3s',
            }}
            onMouseEnter={e => { if (hasContent) e.currentTarget.style.background = '#67e8f9'; }}
            onMouseLeave={e => { e.currentTarget.style.background = hasContent ? '#22d3ee' : 'rgba(34,211,238,0.25)'; }}
          >
            <Play className="h-4 w-4 fill-current" />
            <span>Run</span>
            <ExternalLink className="h-3.5 w-3.5 opacity-70" />
          </button>
          {/* "Click to preview" nudge label — only shown when content ready, not yet run */}
          {hasContent && !hasRun && (
            <span
              className="absolute top-full mt-1.5 text-[9px] font-black uppercase tracking-widest whitespace-nowrap animate-bounce"
              style={{ color: '#22d3ee', opacity: 0.8 }}
            >
              ↑ Click to preview
            </span>
          )}
        </div>
      </header>

      {/* ── Full-width editor ── */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* Sub-bar */}
        <div
          className="shrink-0 flex items-center px-5 h-9 border-b"
          style={{ background: '#0e0f15', borderColor: 'rgba(255,255,255,0.05)' }}
        >
          <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: '#334155' }}>
            Editor
          </span>
          <span className="ml-4 text-[10px]" style={{ color: '#1e293b' }}>
            HTML · CSS · JavaScript
          </span>
          <span className="ml-auto text-[10px] flex items-center gap-1.5" style={{ color: '#1e3a4a' }}>
            <span className="h-1.5 w-1.5 rounded-full inline-block" style={{ background: 'rgba(34,211,238,0.4)' }} />
            auto-saved
          </span>
        </div>

        {/* Textarea — full screen */}
        <textarea
          ref={textareaRef}
          value={code}
          onChange={e => setCode(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Paste or type your HTML / CSS / JS here…"
          spellCheck={false}
          autoCorrect="off"
          autoCapitalize="off"
          className="flex-1 resize-none w-full text-[13px] leading-[1.8] font-mono focus:outline-none px-6 py-5"
          style={{
            background: '#0b0c10',
            color: '#cbd5e1',
            caretColor: '#22d3ee',
            tabSize: 2,
          }}
        />
      </div>
    </div>
  );
}
