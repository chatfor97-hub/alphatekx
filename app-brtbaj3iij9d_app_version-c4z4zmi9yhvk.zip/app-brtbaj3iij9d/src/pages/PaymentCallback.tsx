import { useEffect, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { CheckCircle2, XCircle, Loader2, Zap, ArrowRight, RefreshCw } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { auth } from '@/lib/firebase';
import { addFirestoreCredits, getUserDoc } from '@/lib/firestore';
import { useUserSession } from '@/contexts/UserSessionContext';
import { formatCredits } from '@/lib/credits';

type Status = 'verifying' | 'success' | 'error';

// Floating particle for success burst
function Particle({ delay, angle, dist }: { delay: number; angle: number; dist: number }) {
  const colors = ['bg-primary', 'bg-yellow-400', 'bg-green-400', 'bg-violet-400', 'bg-pink-400'];
  const color  = colors[Math.floor(Math.abs(Math.sin(angle * 100)) * colors.length)];
  const x = Math.cos(angle) * dist;
  const y = Math.sin(angle) * dist;
  return (
    <span
      className={`absolute h-2 w-2 rounded-full ${color} pointer-events-none`}
      style={{
        animation: `particle-burst 0.9s cubic-bezier(0.25, 0.46, 0.45, 0.94) ${delay}s both`,
        '--tx': `${x}px`,
        '--ty': `${y}px`,
      } as React.CSSProperties}
    />
  );
}

export default function PaymentCallback() {
  const [searchParams]        = useSearchParams();
  const navigate              = useNavigate();
  const { refreshBalance }    = useUserSession();
  const [status, setStatus]   = useState<Status>('verifying');
  const [credits, setCredits] = useState<number | null>(null);
  const [newBalance, setNewBalance] = useState<number | null>(null);
  const [errorMsg, setErrorMsg]     = useState('');
  const [countdown, setCountdown]   = useState(5);
  const verified                    = useRef(false);

  // particles — 16 evenly spread
  const particles = Array.from({ length: 16 }, (_, i) => ({
    angle: (i / 16) * Math.PI * 2,
    dist: 60 + (i % 4) * 18,
    delay: i * 0.04,
  }));

  // Countdown timer on success
  useEffect(() => {
    if (status !== 'success') return;
    const t = setInterval(() => {
      setCountdown(c => {
        if (c <= 1) {
          clearInterval(t);
          navigate('/dashboard?payment_success=1', { replace: true });
          return 0;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [status, navigate]);

  useEffect(() => {
    if (verified.current) return;
    verified.current = true;

    const reference   = searchParams.get('reference') || searchParams.get('trxref') || '';
    const packId      = searchParams.get('packId') || '';
    const firebaseUid = searchParams.get('uid') || '';

    if (!reference) {
      setStatus('error');
      setErrorMsg('No payment reference found. Please contact support.');
      return;
    }

    async function verify() {
      try {
        const currentUser = auth.currentUser;
        const uid = currentUser?.uid || firebaseUid;

        if (!uid) {
          setStatus('error');
          setErrorMsg('Could not identify your account. Please sign in and contact support.');
          return;
        }

        const { data, error } = await supabase.functions.invoke('verify-paystack', {
          body: { reference, packId, firebaseUid: uid },
        });

        if (error || data?.code !== 'SUCCESS') {
          const msg = error ? await error.context?.text?.() : data?.message;
          throw new Error(msg || 'Verification failed');
        }

        const creditsToAdd: number  = data.data.creditsToAdd;
        const isIdempotent: boolean = data.data.idempotent === true;
        const webhookSource: string | undefined = data.data.webhookSource;
        const needsFirestoreCredit  = !isIdempotent || webhookSource === 'webhook_firestore_pending';

        if (needsFirestoreCredit) {
          await addFirestoreCredits(uid, creditsToAdd);
        }

        // Refresh context so sidebar shows new balance instantly
        await refreshBalance();

        // Read updated balance for display
        const userDoc = await getUserDoc(uid);
        setNewBalance(userDoc?.credits ?? null);

        setCredits(creditsToAdd);
        setStatus('success');
      } catch (err) {
        console.error('Payment callback error:', err);
        setStatus('error');
        setErrorMsg(
          err instanceof Error ? err.message : 'Unexpected error during verification.'
        );
      }
    }

    verify();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const ref = searchParams.get('reference') || searchParams.get('trxref') || '';

  return (
    <>
      {/* Particle burst keyframe — injected once */}
      <style>{`
        @keyframes particle-burst {
          0%   { transform: translate(0,0) scale(1); opacity: 1; }
          100% { transform: translate(var(--tx), var(--ty)) scale(0); opacity: 0; }
        }
        @keyframes scale-in-bounce {
          0%   { transform: scale(0.5); opacity: 0; }
          70%  { transform: scale(1.12); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
        @keyframes credit-count-in {
          0%   { transform: translateY(12px); opacity: 0; }
          100% { transform: translateY(0); opacity: 1; }
        }
        .anim-scale-bounce { animation: scale-in-bounce 0.6s cubic-bezier(0.34,1.56,0.64,1) both; }
        .anim-credit-in    { animation: credit-count-in 0.5s 0.4s ease both; }
        .anim-fade-up      { animation: credit-count-in 0.5s 0.6s ease both; }
      `}</style>

      <div className="min-h-screen bg-background flex items-center justify-center p-4 overflow-hidden">
        {/* Background glow blobs */}
        <div className="pointer-events-none fixed inset-0 overflow-hidden">
          <div className={`absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full blur-[120px] transition-colors duration-700 ${
            status === 'success' ? 'bg-green-500/8' :
            status === 'error'   ? 'bg-red-500/8'   :
            'bg-primary/8'
          }`} />
        </div>

        <div className="relative w-full max-w-sm">
          {/* Card */}
          <div className={`relative overflow-hidden rounded-3xl border shadow-2xl transition-all duration-500 ${
            status === 'success' ? 'border-green-500/30 bg-card shadow-green-500/10' :
            status === 'error'   ? 'border-destructive/30 bg-card shadow-red-500/10' :
            'border-primary/20 bg-card shadow-primary/10'
          }`}>

            {/* Top progress bar */}
            <div className={`h-[3px] w-full transition-colors duration-500 ${
              status === 'success' ? 'bg-gradient-to-r from-green-500 to-emerald-400' :
              status === 'error'   ? 'bg-destructive' :
              'bg-gradient-to-r from-primary via-primary/60 to-transparent animate-shimmer bg-[length:200%_100%]'
            }`} />

            <div className="px-8 py-10 flex flex-col items-center gap-7 text-center">

              {/* ── VERIFYING ── */}
              {status === 'verifying' && (
                <>
                  <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-primary/10 border border-primary/25 shadow-[0_0_40px_hsl(var(--primary)/0.2)]">
                    <Loader2 className="h-10 w-10 text-primary animate-spin" />
                    <span className="absolute inset-0 rounded-full border border-primary/20 animate-ping" />
                  </div>
                  <div className="space-y-2">
                    <h1 className="text-2xl font-black text-foreground">Verifying Payment</h1>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Confirming your transaction with our payment processor…
                    </p>
                  </div>
                  <p className="text-xs text-muted-foreground/40 font-medium animate-pulse">
                    Please keep this tab open
                  </p>
                </>
              )}

              {/* ── SUCCESS ── */}
              {status === 'success' && (
                <>
                  {/* Particle burst origin */}
                  <div className="relative flex h-24 w-24 items-center justify-center">
                    {particles.map((p, i) => (
                      <Particle key={i} angle={p.angle} dist={p.dist} delay={p.delay} />
                    ))}
                    <div className="anim-scale-bounce relative z-10 flex h-24 w-24 items-center justify-center rounded-full bg-green-500/15 border-2 border-green-500/40 shadow-[0_0_50px_rgba(34,197,94,0.3)]">
                      <CheckCircle2 className="h-11 w-11 text-green-400" />
                    </div>
                  </div>

                  {/* Heading */}
                  <div className="space-y-1.5 anim-credit-in">
                    <p className="text-xs font-black uppercase tracking-[0.25em] text-green-400/80">
                      Transaction Complete
                    </p>
                    <h1 className="text-3xl font-black text-foreground text-balance">
                      Credits Loaded! 🚀
                    </h1>
                  </div>

                  {/* Credits badge */}
                  {credits !== null && (
                    <div className="anim-credit-in w-full rounded-2xl bg-gradient-to-br from-green-500/15 to-emerald-500/5 border border-green-500/25 p-5 space-y-3">
                      <div className="flex items-center justify-center gap-3">
                        <Zap className="h-6 w-6 text-yellow-400 shrink-0" />
                        <span className="text-4xl font-black text-foreground tabular-nums">
                          +{credits.toLocaleString()}
                        </span>
                        <span className="text-sm font-bold text-muted-foreground self-end mb-1">credits</span>
                      </div>
                      <p className="text-xs text-muted-foreground/70 font-medium">
                        Successfully added to your account
                      </p>
                      {newBalance !== null && (
                        <div className="flex items-center justify-center gap-2 pt-1 border-t border-green-500/15">
                          <span className="text-xs text-muted-foreground/60">New balance:</span>
                          <span className="text-sm font-black text-primary tabular-nums">
                            {formatCredits(newBalance)} credits
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* CTA + countdown */}
                  <div className="anim-fade-up w-full space-y-3">
                    <button
                      onClick={() => navigate('/dashboard?payment_success=1', { replace: true })}
                      className="w-full flex items-center justify-center gap-2.5 h-14 rounded-2xl bg-primary text-primary-foreground text-sm font-black tracking-wide hover:bg-primary/90 active:scale-[0.98] transition-all shadow-[0_4px_24px_hsl(var(--primary)/0.4)]"
                    >
                      Go to Dashboard
                      <ArrowRight className="h-4 w-4" />
                    </button>
                    <p className="text-xs text-muted-foreground/40">
                      Auto-redirecting in {countdown}s…
                    </p>
                  </div>
                </>
              )}

              {/* ── ERROR ── */}
              {status === 'error' && (
                <>
                  <div className="flex h-24 w-24 items-center justify-center rounded-full bg-destructive/10 border border-destructive/25">
                    <XCircle className="h-11 w-11 text-destructive" />
                  </div>
                  <div className="space-y-2">
                    <h1 className="text-2xl font-black text-foreground text-balance">
                      Verification Failed
                    </h1>
                    <p className="text-sm text-muted-foreground leading-relaxed text-pretty">
                      {errorMsg || 'Something went wrong during verification.'}
                    </p>
                    {ref && (
                      <p className="text-[11px] text-muted-foreground/40 font-mono mt-2 break-all">
                        Ref: {ref}
                      </p>
                    )}
                  </div>
                  <div className="w-full space-y-2.5">
                    <button
                      onClick={() => navigate('/dashboard', { replace: true })}
                      className="w-full flex items-center justify-center gap-2 h-12 rounded-2xl bg-primary text-primary-foreground text-sm font-black hover:bg-primary/90 active:scale-[0.98] transition-all"
                    >
                      Return to Dashboard
                    </button>
                    <button
                      onClick={() => { verified.current = false; window.location.reload(); }}
                      className="w-full flex items-center justify-center gap-2 h-12 rounded-2xl bg-secondary text-secondary-foreground text-sm font-semibold hover:bg-secondary/80 active:scale-[0.98] transition-all border border-border/40"
                    >
                      <RefreshCw className="h-4 w-4" /> Retry Verification
                    </button>
                  </div>
                </>
              )}

            </div>
          </div>

          {/* Branding footer */}
          <p className="text-center text-[10px] text-muted-foreground/30 font-medium mt-5 tracking-wide">
            Secured by Paystack · AlphaTekx AI OS
          </p>
        </div>
      </div>
    </>
  );
}
