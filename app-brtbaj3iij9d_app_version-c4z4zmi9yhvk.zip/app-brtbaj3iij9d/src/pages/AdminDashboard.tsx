import { useEffect, useState } from 'react';
import PageMeta from '@/components/common/PageMeta';
import { useUserSession } from '@/contexts/UserSessionContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { supabase } from '@/db/supabase';
import { Activity, Users, Globe, Server, ShieldAlert, Lock } from 'lucide-react';

export default function AdminDashboard() {
  const { appUser } = useUserSession();
  const [userCount, setUserCount] = useState<number | null>(null);
  const [apiStatus, setApiStatus] = useState<'online' | 'offline' | 'checking'>('checking');
  const [dbLatency, setDbLatency] = useState<number | null>(null);
  const [accessDenied] = useState(false);

  useEffect(() => {
    async function fetchMetrics() {
      const start = performance.now();
      const { error, count } = await supabase
        .from('credit_topups')
        .select('firebase_uid', { count: 'exact', head: true });
      const end = performance.now();

      if (!error) {
        setUserCount(count ?? 0);
        setDbLatency(Math.round(end - start));
        setApiStatus('online');
      } else {
        setApiStatus('offline');
        setDbLatency(null);
      }
    }

    if (!accessDenied) {
      fetchMetrics();
      const interval = setInterval(fetchMetrics, 30000);
      return () => clearInterval(interval);
    }
  }, [accessDenied]);

  if (!appUser) return null;

  // Access Denied fallback
  if (accessDenied) {
    return (
      <>
        <PageMeta title="Access Denied" description="Unauthorized access to AlphaTekx Admin" />
        <div className="flex items-center justify-center min-h-[60vh] px-4">
          <Card className="w-full max-w-md glass-strong border border-destructive/20 text-center">
            <CardHeader className="space-y-3">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-destructive/10 border border-destructive/20">
                <ShieldAlert className="h-7 w-7 text-destructive" />
              </div>
              <CardTitle className="text-xl font-bold tracking-tight">Access Denied</CardTitle>
              <CardDescription className="text-muted-foreground text-sm text-pretty">
                You do not have permission to view this page.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                <Lock className="h-3.5 w-3.5" />
                <span>Admin clearance required</span>
              </div>
              <Button
                variant="outline"
                className="w-full h-11 border-white/10 hover:bg-white/5 hover:border-white/20"
                onClick={() => window.location.href = '/dashboard'}
              >
                Return to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </>
    );
  }

  return (
    <>
      <PageMeta title="Admin" description="AlphaTekx System Health Dashboard" />
      <div className="mx-auto max-w-5xl px-4 py-8 md:py-12">
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-balance">
            System Health
          </h1>
          <p className="mt-2 text-muted-foreground text-sm md:text-base text-pretty max-w-prose">
            Monitor platform telemetry and infrastructure status. Only administrators have access to this view.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <Card className="glass border border-white/10 h-full flex flex-col">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 border border-primary/20">
                  <Activity className="h-4 w-4 text-primary" />
                </div>
                <CardTitle className="text-base font-semibold">API Status</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              {apiStatus === 'checking' && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="h-2.5 w-2.5 rounded-full bg-warning animate-pulse" />
                  Checking...
                </div>
              )}
              {apiStatus === 'online' && (
                <div className="flex items-center gap-2 text-sm">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75" />
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-success" />
                  </span>
                  <span className="text-success font-medium">Online</span>
                </div>
              )}
              {apiStatus === 'offline' && (
                <div className="flex items-center gap-2 text-sm">
                  <span className="h-2.5 w-2.5 rounded-full bg-destructive" />
                  <span className="text-destructive font-medium">Offline</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="glass border border-white/10 h-full flex flex-col">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 border border-primary/20">
                  <Users className="h-4 w-4 text-primary" />
                </div>
                <CardTitle className="text-base font-semibold">Total Users</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="text-2xl font-bold tracking-tight">
                {userCount !== null ? userCount.toLocaleString() : '—'}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Credit top-up records</p>
            </CardContent>
          </Card>

          <Card className="glass border border-white/10 h-full flex flex-col">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 border border-primary/20">
                  <Server className="h-4 w-4 text-primary" />
                </div>
                <CardTitle className="text-base font-semibold">DB Latency</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="text-2xl font-bold tracking-tight">
                {dbLatency !== null ? `${dbLatency}ms` : '—'}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Round-trip time</p>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 glass border border-white/10">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-primary" />
              <CardTitle className="text-base font-semibold">Region & Endpoint</CardTitle>
            </div>
            <CardDescription className="text-pretty">
              Infrastructure endpoint and operational region for this AlphaTekx deployment.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium">
                <span className="h-2 w-2 rounded-full bg-success" />
                us-west-1
              </div>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium">
                <span className="h-2 w-2 rounded-full bg-success" />
                PostgreSQL 15
              </div>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium">
                <span className="h-2 w-2 rounded-full bg-success" />
                Supabase Realtime
              </div>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium">
                <span className="h-2 w-2 rounded-full bg-success" />
                Auth v2
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
