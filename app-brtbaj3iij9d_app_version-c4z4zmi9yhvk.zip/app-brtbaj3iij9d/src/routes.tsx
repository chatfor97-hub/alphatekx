import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';
import AdminDashboard from './pages/AdminDashboard';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Maintenance from './pages/Maintenance';
import LandingPage from './pages/LandingPage';
import type { ReactNode } from 'react';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  public?: boolean;
}

export const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <LandingPage />,
    public: true,
  },
  {
    name: 'Sign In',
    path: '/login',
    element: <LoginPage />,
    public: true,
  },
  {
    name: 'Dashboard',
    path: '/dashboard',
    element: <Dashboard />,
    public: false,
  },
  {
    name: 'Admin',
    path: '/admin',
    element: <AdminDashboard />,
    public: true,
  },
  {
    name: 'Terms of Service',
    path: '/terms',
    element: <Terms />,
    public: true,
  },
  {
    name: 'Privacy Policy',
    path: '/privacy',
    element: <Privacy />,
    public: true,
  },
  {
    name: 'Maintenance',
    path: '/maintenance',
    element: <Maintenance />,
    public: true,
  },
];
