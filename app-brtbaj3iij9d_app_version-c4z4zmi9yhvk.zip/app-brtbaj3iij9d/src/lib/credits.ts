import { auth } from '@/lib/firebase';
import { deductFirestoreCredits } from '@/lib/firestore';

export interface DeductResult {
  success: boolean;
  newBalance: number | null;
  error: string | null;
}

/**
 * Formats a credit balance for display.
 * - Whole numbers shown as integers: 10 → "10"
 * - Decimals shown with up to 1 decimal place: 9.5 → "9.5"
 */
export function formatCredits(amount: number | null | undefined): string {
  if (amount == null) return '—';
  const rounded = Math.round(amount * 10) / 10;
  return Number.isInteger(rounded) ? rounded.toString() : rounded.toFixed(1);
}

/**
 * Atomically deducts `amount` credits from the signed-in user's Firestore document.
 * Supports decimal amounts (e.g. 0.5 per chat message).
 *
 * Returns success=false with an error message if:
 *  - user is not signed in
 *  - balance is insufficient
 *  - any Firestore error occurs
 */
export async function deductCredits(amount: number): Promise<DeductResult> {
  if (amount <= 0) {
    return { success: false, newBalance: null, error: 'Deduction amount must be greater than zero.' };
  }

  const firebaseUser = auth.currentUser;
  if (!firebaseUser) {
    return { success: false, newBalance: null, error: 'Not signed in.' };
  }

  return deductFirestoreCredits(firebaseUser.uid, amount);
}
