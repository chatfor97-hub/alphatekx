import { supabase } from '@/db/supabase';

export interface SystemStatus {
  maintenanceMode: boolean;
}

/**
 * Checks the global system status from the system_settings table.
 * Returns maintenance_mode state. Defaults to false if the table is unreachable.
 */
export async function checkSystemStatus(): Promise<SystemStatus> {
  const { data, error } = await supabase
    .from('system_settings')
    .select('maintenance_mode')
    .order('updated_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error('System status check failed:', error.message);
    return { maintenanceMode: false };
  }

  return { maintenanceMode: data?.maintenance_mode ?? false };
}
