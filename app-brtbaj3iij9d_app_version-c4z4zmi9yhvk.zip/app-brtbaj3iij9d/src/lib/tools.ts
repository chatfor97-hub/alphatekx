// AlphaTekx Tool Registry
// Maps tool names to URLs and trigger keywords for AI routing

export interface Tool {
  name: string;
  url: string;
  keywords: string[];
  description: string;
  icon: string;
}

export const TOOLS: Tool[] = [
  {
    name: 'Website Builder',
    url: 'https://alphatekxwebsite.lovable.app/',
    keywords: ['website', 'build site', 'web page', 'landing page', 'site builder', 'build a website', 'create website', 'web app', 'webpage', 'web design'],
    description: 'Build fully functional websites and landing pages with AI assistance',
    icon: '🌐',
  },
  {
    name: 'Exam Prep',
    url: 'https://pro-exam-prep.lovable.app/',
    keywords: ['exam', 'study', 'test prep', 'quiz', 'prepare for exam', 'revision', 'practice test', 'mock exam', 'study guide', 'flashcard'],
    description: 'AI-powered exam preparation, quizzes, and study guides',
    icon: '📚',
  },
  {
    name: 'Art Generator',
    url: 'https://art-blaze.lovable.app',
    keywords: ['art', 'generate image', 'create art', 'drawing', 'paint', 'illustration', 'artwork', 'digital art', 'image generation', 'create image', 'design image'],
    description: 'Generate stunning artwork and illustrations with AI',
    icon: '🎨',
  },
  {
    name: 'Media Linker',
    url: 'https://media-magic-linker.lovable.app/',
    keywords: ['media', 'link media', 'social media', 'content linker', 'share link', 'media management', 'link sharing', 'content sharing'],
    description: 'Manage and link media content across platforms',
    icon: '🔗',
  },
  {
    name: 'Video Generator',
    url: 'https://text-to-video-and-im-12mg.bolt.host',
    keywords: ['video', 'create video', 'generate video', 'video of', 'make a video', 'video clip', 'video generator', 'animation', 'make clip', 'generate clip'],
    description: 'Create cinematic videos from text prompts',
    icon: '🎬',
  },
  {
    name: 'Contract Guard',
    url: 'https://gold-contract-guard.lovable.app/',
    keywords: ['contract', 'contract guard', 'legal document', 'agreement', 'review contract', 'contract review', 'legal review', 'sign contract', 'contract analysis'],
    description: 'AI-powered contract review and legal document analysis',
    icon: '🛡️',
  },
  {
    name: 'Voice Gen',
    url: 'https://alphatekxvoices.lovable.app/',
    keywords: ['voice', 'voice gen', 'text to speech', 'tts', 'generate voice', 'voiceover', 'narration', 'audio gen', 'speech', 'voice generation'],
    description: 'Generate natural-sounding voices and voiceovers with AI',
    icon: '🎙️',
  },
  {
    name: 'Thumbnail Studio',
    url: 'https://perfect-thumb-studio.lovable.app/',
    keywords: ['thumbnail', 'thumbnail studio', 'youtube thumbnail', 'create thumbnail', 'design thumbnail', 'video thumbnail', 'channel art', 'banner design'],
    description: 'Design eye-catching thumbnails and channel art',
    icon: '🖼️',
  },
];

/**
 * Find matching tool from a prompt using keyword matching (case-insensitive)
 */
export function findToolFromPrompt(prompt: string): Tool | null {
  const lower = prompt.toLowerCase();
  for (const tool of TOOLS) {
    if (tool.keywords.some(kw => lower.includes(kw.toLowerCase()))) {
      return tool;
    }
  }
  return null;
}
