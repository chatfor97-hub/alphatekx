/**
 * AlphaTekx Client-Side Security Library
 * ─────────────────────────────────────────
 * Provides:
 *  1. Input sanitization  — strips XSS vectors from user text
 *  2. Threat detection    — detects SQL/XSS/traversal in form values
 *  3. Rate limiter        — in-memory sliding window per action key
 *  4. Honeypot validation — detects bot form submissions
 *  5. Request signing     — adds anti-CSRF token to Edge Function calls
 *  6. Dev-tools guard     — detects open devtools (production only)
 */

// ── 1. Input Sanitizer ─────────────────────────────────────────────────────────

const XSS_TAG_RE       = /<[^>]*>/g;
const JS_PROTO_RE      = /javascript\s*:/gi;
const DATA_PROTO_RE    = /data\s*:\s*text\/html/gi;
const EVENT_ATTR_RE    = /\bon\w+\s*=/gi;
const SCRIPT_RE        = /<\s*script[\s\S]*?>[\s\S]*?<\s*\/script\s*>/gi;
const NULLBYTE_RE      = /\x00/g;

/**
 * Sanitize a user-provided string for safe display / storage.
 * Strips HTML tags, JS protocols, event handlers, and null bytes.
 */
export function sanitizeInput(raw: string): string {
  return raw
    .replace(NULLBYTE_RE,   "")
    .replace(SCRIPT_RE,     "")
    .replace(XSS_TAG_RE,    "")
    .replace(JS_PROTO_RE,   "")
    .replace(DATA_PROTO_RE, "")
    .replace(EVENT_ATTR_RE, "")
    .trim();
}

/**
 * Sanitize every string field in an object (shallow, 1-level deep).
 */
export function sanitizeObject<T extends Record<string, unknown>>(obj: T): T {
  const result = { ...obj };
  for (const key of Object.keys(result)) {
    if (typeof result[key] === "string") {
      (result as Record<string, unknown>)[key] = sanitizeInput(result[key] as string);
    }
  }
  return result;
}

// ── 2. Threat Detection ────────────────────────────────────────────────────────

const SQL_THREAT_RE = [
  /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|TRUNCATE)\b)/i,
  /(--|;--|\/\*|\*\/)/,
  /(\bOR\b\s+['"]?\d['"]?\s*=\s*['"]?\d)/i,
  /(SLEEP\s*\(|BENCHMARK\s*\(|WAITFOR\s+DELAY)/i,
];

const XSS_THREAT_RE = [
  /<script/i,
  /javascript:/i,
  /on\w+\s*=/i,
  /eval\s*\(/i,
  /document\.cookie/i,
];

const TRAVERSAL_RE = [/\.\.\//, /\.\.%2F/i, /etc\/passwd/i];

export type ThreatType = "sql_injection" | "xss" | "path_traversal" | null;

/** Returns the type of threat detected in a string, or null if clean. */
export function detectThreat(value: string): ThreatType {
  if (!value) return null;
  for (const re of SQL_THREAT_RE)  if (re.test(value)) return "sql_injection";
  for (const re of XSS_THREAT_RE)  if (re.test(value)) return "xss";
  for (const re of TRAVERSAL_RE)   if (re.test(value)) return "path_traversal";
  return null;
}

/** Returns true if any field in the object contains a threat pattern. */
export function hasThreats(fields: Record<string, string>): boolean {
  return Object.values(fields).some(v => detectThreat(v) !== null);
}

// ── 3. Client-Side Rate Limiter ────────────────────────────────────────────────

interface RateBucket {
  timestamps: number[];
}

const rateBuckets = new Map<string, RateBucket>();

/**
 * In-memory sliding window rate limiter.
 * @param key        — unique action identifier (e.g. "waitlist-submit")
 * @param maxCalls   — max calls allowed within the window
 * @param windowMs   — window duration in milliseconds (default: 60_000)
 * @returns true if the call is allowed, false if rate-limited
 */
export function checkClientRateLimit(
  key: string,
  maxCalls: number,
  windowMs = 60_000,
): boolean {
  const now    = Date.now();
  const bucket = rateBuckets.get(key) ?? { timestamps: [] };

  // Evict entries outside the window
  bucket.timestamps = bucket.timestamps.filter(t => now - t < windowMs);

  if (bucket.timestamps.length >= maxCalls) {
    rateBuckets.set(key, bucket);
    return false;
  }

  bucket.timestamps.push(now);
  rateBuckets.set(key, bucket);
  return true;
}

// ── 4. Honeypot Validation ─────────────────────────────────────────────────────

/**
 * Returns true if a honeypot field is filled in (bot detected).
 * Usage: add a hidden <input name="website" /> to your form,
 * then call isBot(formData.website).
 */
export function isBot(honeypotValue: string | undefined): boolean {
  return Boolean(honeypotValue && honeypotValue.trim().length > 0);
}

/**
 * Returns true if the form was submitted suspiciously fast (< 1.5s after load).
 * Bots fill and submit forms near-instantly; humans take at least a second.
 */
export function isTooFast(formLoadedAt: number, minMs = 1500): boolean {
  return Date.now() - formLoadedAt < minMs;
}

// ── 5. Anti-CSRF Token ─────────────────────────────────────────────────────────

let _csrfToken: string | null = null;

/** Generate a cryptographically random CSRF token for the session. */
export function getCsrfToken(): string {
  if (!_csrfToken) {
    const arr    = new Uint8Array(24);
    crypto.getRandomValues(arr);
    _csrfToken = Array.from(arr).map(b => b.toString(16).padStart(2, "0")).join("");
  }
  return _csrfToken;
}

// ── 6. DevTools Guard (production only) ───────────────────────────────────────

let _devtoolsOpen = false;

/**
 * Detects open browser DevTools using a debugger timing attack.
 * In production, logs a warning if DevTools are open.
 * NEVER blocks the user — only fires the callback.
 */
export function startDevToolsGuard(onDetect?: () => void): () => void {
  if (import.meta.env.DEV) return () => {};  // skip in dev

  let last = Date.now();

  function check() {
    const now   = Date.now();
    const delta = now - last;
    last        = now;

    // debugger statement inside a loop takes ~100ms+ when DevTools are open
    // eslint-disable-next-line no-debugger
    debugger;

    const elapsed = Date.now() - now;
    const wasOpen = _devtoolsOpen;
    _devtoolsOpen = elapsed > 100 || delta > 500;

    if (_devtoolsOpen && !wasOpen) {
      console.warn("[AlphaTekx] DevTools detected.");
      onDetect?.();
    }
  }

  const id = setInterval(check, 3000);
  return () => clearInterval(id);
}

/** Returns true if DevTools were last detected as open. */
export function isDevToolsOpen(): boolean {
  return _devtoolsOpen;
}

// ── 7. Email Validator ─────────────────────────────────────────────────────────

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** Returns true if the email address looks syntactically valid. */
export function isValidEmail(email: string): boolean {
  return EMAIL_RE.test(email.trim().toLowerCase());
}

// ── 8. Safe JSON parser ────────────────────────────────────────────────────────

/**
 * Safely parse JSON without throwing. Returns null on error.
 */
export function safeParseJSON<T = unknown>(raw: string): T | null {
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}
