import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
  runTransaction,
  increment,
  collection,
  query,
  where,
  getDocs,
  limit,
} from 'firebase/firestore';
import type { User } from 'firebase/auth';
import { db } from './firebase';

export interface AppUser {
  uid: string;
  display_name: string;
  email: string;
  photo_url: string | null;
  credits: number;
  is_verified: boolean;
  created_at: unknown; // Firestore Timestamp
  role?: 'user' | 'admin';
}

/**
 * The one, ultimate platform admin.
 * This email is ALWAYS granted role:'admin' on every sign-in, regardless of
 * what is currently stored in Firestore.
 */
const PLATFORM_ADMIN_EMAIL = 'iamdan4live@gmail.com';

/** Returns true if the given email is the platform admin. */
function isPlatformAdmin(email: string): boolean {
  return email.trim().toLowerCase() === PLATFORM_ADMIN_EMAIL;
}

/**
 * Called after every successful Google sign-in.
 * - New user      → creates Firestore doc with 30 credits + is_verified: true
 * - Returning     → ensures role:'admin' is set if email is the platform admin
 */
export async function upsertUser(firebaseUser: User): Promise<{ appUser: AppUser; isNew: boolean }> {
  const ref  = doc(db, 'users', firebaseUser.uid);
  const snap = await getDoc(ref);
  const email = (firebaseUser.email ?? '').trim().toLowerCase();

  if (snap.exists()) {
    const existing = snap.data() as AppUser;
    // Always enforce admin role for the platform admin email
    if (isPlatformAdmin(email) && existing.role !== 'admin') {
      await updateDoc(ref, { role: 'admin' });
      return { appUser: { ...existing, role: 'admin' }, isNew: false };
    }
    return { appUser: existing, isNew: false };
  }

  // New user — create document
  const newUser: AppUser = {
    uid:          firebaseUser.uid,
    display_name: firebaseUser.displayName ?? 'AlphaTekx User',
    email:        email,
    photo_url:    firebaseUser.photoURL ?? null,
    credits:      30,
    is_verified:  true,
    created_at:   serverTimestamp(),
    role:         isPlatformAdmin(email) ? 'admin' : 'user',
  };

  await setDoc(ref, newUser);
  return { appUser: newUser, isNew: true };
}

/**
 * Fetches the latest user document from Firestore.
 * Returns null if the document does not exist.
 * Always enforces role:'admin' for the platform admin email.
 */
export async function getUserDoc(uid: string): Promise<AppUser | null> {
  const ref  = doc(db, 'users', uid);
  const snap = await getDoc(ref);
  if (!snap.exists()) return null;

  const user = snap.data() as AppUser;
  if (isPlatformAdmin(user.email) && user.role !== 'admin') {
    await updateDoc(ref, { role: 'admin' });
    return { ...user, role: 'admin' };
  }
  return user;
}

/**
 * Atomically deducts `amount` credits from the user's Firestore document.
 * Supports decimal amounts (e.g. 0.5 credits per chat message).
 * Balance is rounded to 2 decimal places to avoid float drift.
 * Returns { success, newBalance, error }.
 */
export async function deductFirestoreCredits(
  uid: string,
  amount: number,
): Promise<{ success: boolean; newBalance: number | null; error: string | null }> {
  const ref = doc(db, 'users', uid);

  try {
    let newBalance = 0;

    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) throw new Error('User document not found.');

      const current = (snap.data() as AppUser).credits ?? 0;
      if (current < amount) throw new Error('Insufficient credits.');

      // Round to 2 decimal places to prevent floating-point drift
      newBalance = Math.round((current - amount) * 100) / 100;
      tx.update(ref, { credits: newBalance });
    });

    return { success: true, newBalance, error: null };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Deduction failed.';
    return { success: false, newBalance: null, error: message };
  }
}

/**
 * Directly updates a field in the user document (non-transactional).
 * Use for non-critical writes like display_name updates.
 */
export async function updateUserField(
  uid: string,
  fields: Partial<Omit<AppUser, 'uid' | 'created_at'>>,
): Promise<void> {
  const ref = doc(db, 'users', uid);
  await updateDoc(ref, fields as Record<string, unknown>);
}

/**
 * Atomically adds `amount` credits to the user's Firestore document.
 * Uses Firestore's increment() to prevent race conditions.
 */
export async function addFirestoreCredits(
  uid: string,
  amount: number,
): Promise<void> {
  const ref = doc(db, 'users', uid);
  await updateDoc(ref, { credits: increment(amount) });
}

/**
 * Looks up a user document by email address.
 * Returns the AppUser or null if not found.
 */
export async function getUserByEmail(email: string): Promise<AppUser | null> {
  const q = query(collection(db, 'users'), where('email', '==', email.trim().toLowerCase()), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return null;
  return { uid: snap.docs[0].id, ...snap.docs[0].data() } as AppUser;
}

/**
 * Atomically transfers `amount` credits from sender to recipient.
 * Uses a Firestore transaction to guarantee consistency.
 * Returns { success, error }.
 */
export async function transferCredits(
  senderUid:    string,
  recipientUid: string,
  amount:       number,
): Promise<{ success: boolean; senderBalance: number | null; error: string | null }> {
  if (senderUid === recipientUid) {
    return { success: false, senderBalance: null, error: 'Cannot send credits to yourself.' };
  }
  const senderRef    = doc(db, 'users', senderUid);
  const recipientRef = doc(db, 'users', recipientUid);

  try {
    let senderBalance = 0;

    await runTransaction(db, async (tx) => {
      const senderSnap    = await tx.get(senderRef);
      const recipientSnap = await tx.get(recipientRef);

      if (!senderSnap.exists())    throw new Error('Your account was not found.');
      if (!recipientSnap.exists()) throw new Error('Recipient account not found.');

      const senderCredits = (senderSnap.data() as AppUser).credits ?? 0;
      if (senderCredits < amount)  throw new Error('Insufficient credits.');

      senderBalance = Math.round((senderCredits - amount) * 100) / 100;
      tx.update(senderRef,    { credits: senderBalance });
      tx.update(recipientRef, { credits: increment(amount) });
    });

    return { success: true, senderBalance, error: null };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Transfer failed.';
    return { success: false, senderBalance: null, error: message };
  }
}
