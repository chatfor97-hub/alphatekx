import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyDNcwf1pA7s_Y7I8SF8ATsi205AHskdV78',
  authDomain: 'alphatekx-2.firebaseapp.com',
  projectId: 'alphatekx-2',
  storageBucket: 'alphatekx-2.firebasestorage.app',
  messagingSenderId: '654914646254',
  appId: '1:654914646254:web:2e3262b37c140d181e83ff',
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
