/**
 * Direct edge-function caller — bypasses the Supabase JS client entirely.
 *
 * Using supabase.functions.invoke() requires an active Supabase auth session to
 * attach the Authorization header.  This app uses Firebase auth, so the Supabase
 * client never calls setAuth() and the Authorization header is missing → fetch
 * throws a FunctionsFetchError ("Failed to send a request to the Edge Function").
 *
 * This helper builds the URL + headers manually and uses the global fetch API
 * directly, eliminating the auth-state dependency.
 */

const SUPABASE_URL  = import.meta.env.VITE_SUPABASE_URL  as string;
const SUPABASE_ANON = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export class EdgeFunctionError extends Error {
  constructor(
    message: string,
    public readonly status?: number,
    public readonly raw?: unknown,
  ) {
    super(message);
    this.name = 'EdgeFunctionError';
  }
}

/**
 * Calls a Supabase Edge Function via direct fetch.
 * Throws EdgeFunctionError with a human-readable message on any failure.
 */
export async function callEdgeFunction<T = unknown>(
  functionName: string,
  body: Record<string, unknown>,
  timeoutMs = 90_000,
): Promise<T> {
  if (!SUPABASE_URL || !SUPABASE_ANON) {
    throw new EdgeFunctionError(
      'App configuration error: Supabase URL or key is missing. Contact support.',
    );
  }

  const url = `${SUPABASE_URL}/functions/v1/${functionName}`;

  let res: Response;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${SUPABASE_ANON}`,
        'apikey':        SUPABASE_ANON,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('timed out') || msg.includes('AbortError')) {
      throw new EdgeFunctionError('Request timed out. Please try again.');
    }
    throw new EdgeFunctionError(
      `Network error — could not reach the server. Check your connection and try again. (${msg})`,
    );
  }

  // Try to parse the JSON body regardless of status code
  let json: Record<string, unknown> = {};
  try {
    json = await res.json();
  } catch {
    throw new EdgeFunctionError(
      `Server returned an unexpected response (status ${res.status}). Please try again.`,
      res.status,
    );
  }

  if (!res.ok) {
    const errMsg =
      (json.message as string) ||
      (json.error   as string) ||
      `Server error (${res.status}). Please try again.`;
    throw new EdgeFunctionError(errMsg, res.status, json);
  }

  return json as T;
}
