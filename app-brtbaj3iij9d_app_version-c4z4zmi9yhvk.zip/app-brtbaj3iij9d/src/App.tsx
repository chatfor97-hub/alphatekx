import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { UserSessionProvider, useUserSession } from './contexts/UserSessionContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { RouteGuard } from './components/common/RouteGuard';
import DashboardLayout from '@/components/layout/DashboardLayout';
import IntersectObserver from '@/components/common/IntersectObserver';
import { Toaster } from '@/components/ui/sonner';
import { usePageTracking } from '@/hooks/use-page-tracking';

/** Mounts inside Router + UserSessionProvider — logs every real page visit. */
function PageTracker() {
  const { appUser } = useUserSession();
  usePageTracking(appUser?.uid ?? null);
  return null;
}

import LoginPage from './pages/LoginPage';
import OnboardingPage from './pages/OnboardingPage';
import Dashboard from './pages/Dashboard';
import AdminDashboard from './pages/AdminDashboard';
import MembersLounge from './pages/MembersLounge';
import ScriptWriter from './pages/ScriptWriter';
import BuildWithUs from './pages/BuildWithUs';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import Maintenance from './pages/Maintenance';
import PaymentCallback from './pages/PaymentCallback';
import LandingPage from './pages/LandingPage';
import LiveEditorPage from './pages/LiveEditorPage';
import LivePreviewPage from './pages/LivePreviewPage';
import VaultPage from './pages/VaultPage';
import ToolsPage from './pages/ToolsPage';
import CommunityPage from './pages/CommunityPage';
import CreatorBlog from './pages/CreatorBlog';
import SEODashboard from './pages/SEODashboard';

export default function App() {
  return (
    <ThemeProvider>
      <Router>
        <UserSessionProvider>
          <PageTracker />
          <RouteGuard>
            <IntersectObserver />
            <Routes>
              {/* Public Pages */}
              <Route path="/" element={<LandingPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/onboarding" element={<OnboardingPage />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/maintenance" element={<Maintenance />} />
              <Route path="/payment/callback" element={<PaymentCallback />} />

              {/* Protected Pages */}
              <Route path="/dashboard" element={<DashboardLayout><Dashboard /></DashboardLayout>} />
              <Route path="/tools" element={<DashboardLayout><ToolsPage /></DashboardLayout>} />
              <Route path="/vault" element={<DashboardLayout><VaultPage /></DashboardLayout>} />
              <Route path="/community" element={<DashboardLayout><CommunityPage /></DashboardLayout>} />
              <Route path="/tools/creator-blog" element={<DashboardLayout><CreatorBlog /></DashboardLayout>} />
              <Route path="/admin/seo" element={<DashboardLayout><SEODashboard /></DashboardLayout>} />
              <Route path="/members-lounge" element={<DashboardLayout><MembersLounge /></DashboardLayout>} />
              <Route path="/tools/script-writer" element={<DashboardLayout><ScriptWriter /></DashboardLayout>} />
              <Route path="/tools/live-editor" element={<LiveEditorPage />} />
              <Route path="/tools/live-preview" element={<LivePreviewPage />} />
              <Route path="/build-with-us" element={<DashboardLayout><BuildWithUs /></DashboardLayout>} />
              <Route path="/admin" element={<DashboardLayout><AdminDashboard /></DashboardLayout>} />

              {/* Redirects */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
            <Toaster />
          </RouteGuard>
        </UserSessionProvider>
      </Router>
    </ThemeProvider>
  );
}
