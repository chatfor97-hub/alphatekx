import { X } from 'lucide-react';

interface VideoStudioProps {
  open: boolean;
  onClose: () => void;
}

export default function VideoStudio({ open, onClose }: VideoStudioProps) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-6xl h-[85vh] flex flex-col rounded-2xl border border-white/10 bg-card/95 backdrop-blur-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="h-2.5 w-2.5 rounded-full bg-primary animate-pulse" />
            <h2 className="text-base font-semibold text-foreground tracking-wide">
              Video Studio
            </h2>
            <span className="text-[10px] text-muted-foreground uppercase tracking-widest hidden sm:inline">
              AlphaTekx AI OS
            </span>
          </div>
          <button
            onClick={onClose}
            className="flex items-center justify-center h-9 w-9 rounded-full bg-secondary/60 hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Close Video Studio"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Iframe */}
        <div className="flex-1 min-h-0 bg-black/40">
          <iframe
            src="https://text-to-video-and-im-12mg.bolt.host"
            title="Video Studio"
            className="w-full h-full border-0"
            allow="fullscreen; camera; microphone"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads"
          />
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-white/10 shrink-0 flex items-center justify-between">
          <p className="text-[11px] text-muted-foreground/60 tracking-wide">
            Powered by external video generation engine
          </p>
          <button
            onClick={onClose}
            className="text-xs font-medium text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-md hover:bg-secondary/50"
          >
            Close Studio
          </button>
        </div>
      </div>
    </div>
  );
}
