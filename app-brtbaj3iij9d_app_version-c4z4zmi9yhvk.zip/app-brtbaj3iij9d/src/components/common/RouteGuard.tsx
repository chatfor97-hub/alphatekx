import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useUserSession } from '@/contexts/UserSessionContext';

// Routes that are always visible without authentication — rendered instantly, no blocking
const PUBLIC_ROUTES = [
  '/',
  '/login',
  '/maintenance',
  '/403',
  '/404',
  '/terms',
  '/privacy',
  '/onboarding',
  '/payment/callback',
  '/tools/creator-blog',
];

function isPublicRoute(path: string) {
  return PUBLIC_ROUTES.some(p => path === p || path.startsWith(p + '/'));
}

interface RouteGuardProps {
  children: React.ReactNode;
}

export function RouteGuard({ children }: RouteGuardProps) {
  const { appUser, sessionReady } = useUserSession();
  const navigate = useNavigate();
  const location = useLocation();

  const isPublic = isPublicRoute(location.pathname);

  useEffect(() => {
    // Never act until Firebase has resolved auth state
    if (!sessionReady) return;

    // Unauthenticated user on a protected route → send to LANDING PAGE, not login.
    // The landing page is always the entry point. Login is only reachable via CTA.
    if (!appUser && !isPublic) {
      navigate('/', { replace: true });
      return;
    }

    // Authenticated user on the login page → go straight to dashboard
    if (appUser && location.pathname === '/login') {
      navigate('/dashboard', { replace: true });
    }
  }, [appUser, sessionReady, location.pathname, navigate, isPublic]);

  // Public routes render INSTANTLY — no spinner, no Firebase wait.
  // This guarantees the landing page is always the first thing any visitor sees.
  if (isPublic) {
    return <>{children}</>;
  }

  // Protected routes: hold until Firebase confirms the session
  if (!sessionReady) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest animate-pulse">
            Loading AlphaTekx OS…
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}