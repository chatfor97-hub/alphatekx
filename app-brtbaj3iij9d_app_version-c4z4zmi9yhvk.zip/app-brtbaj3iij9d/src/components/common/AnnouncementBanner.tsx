/**
 * AnnouncementBanner — reusable, realtime-powered announcement strip.
 * 
 * AlphaTekx Cyber-Dark V3.0 Refinement.
 */
import { useEffect, useState } from 'react';
import { supabase } from '@/db/supabase';
import { Zap, Pencil, Check, X, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const BANNER_PREFIX = 'ann_dismissed_';

interface Announcement {
  id:              string;
  text:            string;
  is_active:       boolean;
  created_by_name: string;
  created_at:      string;
  updated_at:      string;
}

interface Props {
  isAdmin?:  boolean;
  variant?:  'compact' | 'prominent';
}

export default function AnnouncementBanner({ isAdmin = false, variant = 'compact' }: Props) {
  const [ann,       setAnn]       = useState<Announcement | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const [editing,   setEditing]   = useState(false);
  const [draft,     setDraft]     = useState('');
  const [saving,    setSaving]    = useState(false);

  useEffect(() => {
    supabase
      .from('lounge_announcements')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          setAnn(data as Announcement);
          setDismissed(sessionStorage.getItem(`${BANNER_PREFIX}${data.id}`) === 'true');
        }
      });

    const ch = supabase.channel(`announcements-${variant}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'lounge_announcements' },
        async () => {
          const { data } = await supabase
            .from('lounge_announcements')
            .select('*')
            .eq('is_active', true)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();
          if (data) {
            setAnn(data as Announcement);
            setDismissed(sessionStorage.getItem(`${BANNER_PREFIX}${data.id}`) === 'true');
            setEditing(false);
          } else {
            setAnn(null);
          }
        })
      .subscribe();

    return () => { ch.unsubscribe(); };
  }, [variant]);

  function dismiss() {
    if (!ann) return;
    sessionStorage.setItem(`${BANNER_PREFIX}${ann.id}`, 'true');
    setDismissed(true);
  }

  async function saveEdit() {
    if (!ann || !draft.trim() || saving) return;
    setSaving(true);
    await supabase
      .from('lounge_announcements')
      .update({ text: draft.trim(), updated_at: new Date().toISOString() })
      .eq('id', ann.id);
    setSaving(false);
    setEditing(false);
    toast.success('Announcement updated.');
  }

  if (!ann || dismissed) return null;

  if (variant === 'compact') {
    return (
      <div className="shrink-0 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
        <div className="flex items-center gap-3 px-4 py-2.5 max-w-4xl mx-auto min-h-[44px]">
          <Zap className="h-4 w-4 text-primary shrink-0" />
          <div className="flex-1 min-w-0">
            {editing ? (
              <input
                value={draft}
                onChange={e => setDraft(e.target.value)}
                autoFocus
                className="w-full bg-transparent text-[13px] text-foreground focus:outline-none border-b border-primary/30 pb-0.5"
              />
            ) : (
              <p className="text-[11px] font-bold text-muted-foreground uppercase tracking-widest truncate leading-none">{ann.text}</p>
            )}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {isAdmin && !editing && (
              <button
                onClick={() => { setDraft(ann.text); setEditing(true); }}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary/50 border border-border/60 text-muted-foreground hover:text-primary transition-all"
              >
                <Pencil className="h-3.5 w-3.5" />
              </button>
            )}
            {editing && (
              <>
                <button
                  onClick={saveEdit}
                  disabled={!draft.trim() || saving}
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-green-500/10 border border-green-500/20 text-green-500 hover:text-green-400 transition-all"
                >
                  {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                </button>
                <button
                  onClick={() => setEditing(false)}
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary/50 border border-border/60 text-muted-foreground hover:text-foreground transition-all"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </>
            )}
            {!editing && (
              <button
                onClick={dismiss}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary/50 border border-border/60 text-muted-foreground hover:text-foreground transition-all"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="shrink-0 mx-auto w-full max-w-4xl px-4 mt-3">
      <div className="rounded-2xl border border-border/60 bg-secondary/30 shadow-xl overflow-hidden">
        <div className="flex items-start gap-4 px-5 py-5">
          <div className="relative shrink-0 mt-0.5">
            <div className="absolute inset-0 rounded-xl bg-primary/20 blur-md animate-pulse" />
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 border border-primary/25">
              <Zap className="h-5 w-5 text-primary" />
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-black text-primary/60 uppercase tracking-widest mb-1.5">
              📣 OS Transmission · {ann.created_by_name}
            </p>
            {editing ? (
              <textarea
                value={draft}
                onChange={e => setDraft(e.target.value)}
                rows={3}
                autoFocus
                className="w-full resize-none bg-transparent text-sm text-foreground focus:outline-none leading-relaxed border-b border-primary/30 pb-1 font-bold"
              />
            ) : (
              <p className="text-sm font-bold text-foreground/90 leading-relaxed text-pretty">
                {ann.text}
              </p>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {isAdmin && !editing && (
              <button
                onClick={() => { setDraft(ann.text); setEditing(true); }}
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary border border-border/60 text-muted-foreground hover:text-primary transition-all"
              >
                <Pencil className="h-4 w-4" />
              </button>
            )}
            {editing && (
              <>
                <button
                  onClick={saveEdit}
                  disabled={!draft.trim() || saving}
                  className="flex h-9 w-9 items-center justify-center rounded-xl bg-green-500/10 border border-green-500/20 text-green-500 transition-all disabled:opacity-40"
                >
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                </button>
                <button
                  onClick={() => setEditing(false)}
                  className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary border border-border/60 text-muted-foreground hover:text-foreground transition-all"
                >
                  <X className="h-4 w-4" />
                </button>
              </>
            )}
            {!editing && (
              <button
                onClick={dismiss}
                className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary border border-border/60 text-muted-foreground hover:text-foreground transition-all"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
