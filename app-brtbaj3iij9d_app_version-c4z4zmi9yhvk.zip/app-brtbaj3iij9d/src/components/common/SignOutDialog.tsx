import { useNavigate } from 'react-router-dom';
import { useUserSession } from '@/contexts/UserSessionContext';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from '@/components/ui/alert-dialog';
import { LogOut } from 'lucide-react';

interface SignOutDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function SignOutDialog({ open, onOpenChange }: SignOutDialogProps) {
  const { logout } = useUserSession();
  const navigate = useNavigate();

  async function handleConfirm() {
    await logout();
    navigate('/login', { replace: true });
  }

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-sm border border-white/10 glass-strong text-center">
        <AlertDialogHeader className="items-center">
          <div className="mx-auto mb-2 flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10 border border-destructive/30">
            <LogOut className="h-6 w-6 text-destructive" />
          </div>
          <AlertDialogTitle className="text-lg font-bold text-balance">
            Sign out of AlphaTekx?
          </AlertDialogTitle>
          <AlertDialogDescription className="text-pretty text-sm text-muted-foreground">
            You will be returned to the login screen. Your credits and data are safely stored and will be here when you come back.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex-col-reverse sm:flex-row gap-2 mt-2">
          <AlertDialogCancel className="w-full sm:w-auto">
            Stay
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleConfirm}
            className="w-full sm:w-auto bg-destructive hover:bg-destructive/90 text-destructive-foreground"
          >
            Yes, sign out
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
