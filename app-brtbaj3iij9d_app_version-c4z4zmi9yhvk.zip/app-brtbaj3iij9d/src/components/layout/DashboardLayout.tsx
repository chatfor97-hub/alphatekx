import { useState, useEffect, useRef } from 'react';
import { useUserSession } from '@/contexts/UserSessionContext';
import { useTheme, THEME_OPTIONS } from '@/contexts/ThemeContext';
import { useLocation, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { formatCredits } from '@/lib/credits';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  Shield,
  LayoutDashboard,
  Activity,
  LogOut,
  Menu,
  User,
  Zap,
  Users,
  CreditCard,
  Hammer,
  Palette,
  Lock,
  MessageSquare,
  BookOpen,
  BarChart3,
} from 'lucide-react';
import SignOutDialog from '@/components/common/SignOutDialog';
import AnnouncementBanner from '@/components/common/AnnouncementBanner';
import CreditsExhaustedModal from '@/components/payments/CreditsExhaustedModal';
import { supabase } from '@/db/supabase';
import { useOnlineCount, formatLiveCount } from '@/hooks/use-online-count';

const navItems = [
  { label: 'Dashboard',     path: '/dashboard',            icon: LayoutDashboard },
  { label: 'Tools',         path: '/tools',                icon: Zap },
  { label: 'Community',     path: '/community',            icon: MessageSquare },
  { label: 'Creator Blog',  path: '/tools/creator-blog',   icon: BookOpen },
  { label: 'App Vault',     path: '/vault',                icon: Lock },
  { label: 'Build With Us', path: '/build-with-us',        icon: Hammer },
  { label: 'Team HQ',       path: '/members-lounge',       icon: Users },
  { label: 'System',        path: '/admin',                icon: Activity,  adminOnly: true },
  { label: 'SEO & Analytics', path: '/admin/seo',          icon: BarChart3, adminOnly: true },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { appUser } = useUserSession();
  const { theme, setTheme } = useTheme();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [signOutOpen, setSignOutOpen] = useState(false);
  const [buyCreditsOpen, setBuyCreditsOpen] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [hintDismissed, setHintDismissed] = useState(
    () => localStorage.getItem('alphatekx_sidebar_hint_dismissed') === '1'
  );
  const [visitedPaths] = useState<Set<string>>(
    () => new Set(JSON.parse(localStorage.getItem('alphatekx_visited_paths') || '[]'))
  );

  // ── Community unread badge ──────────────────────────────────────────────────
  const [communityUnread, setCommunityUnread] = useState(0);
  const lastSeenRef = useRef<string>(
    localStorage.getItem('alphatekx_community_last_seen') || new Date(0).toISOString()
  );

  // On mount: count messages newer than last_seen
  useEffect(() => {
    if (location.pathname === '/community') return;
    supabase
      .from('community_messages')
      .select('id', { count: 'exact', head: true })
      .eq('is_deleted', false)
      .gt('created_at', lastSeenRef.current)
      .then(({ count }) => setCommunityUnread(count ?? 0));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Subscribe to new messages so badge auto-increments
  useEffect(() => {
    const channel = supabase
      .channel('community-sidebar-badge')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'community_messages' }, () => {
        if (location.pathname !== '/community') {
          setCommunityUnread(n => n + 1);
        }
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [location.pathname]);

  // Clear badge when entering Community
  useEffect(() => {
    if (location.pathname === '/community') {
      const now = new Date().toISOString();
      localStorage.setItem('alphatekx_community_last_seen', now);
      lastSeenRef.current = now;
      setCommunityUnread(0);
    }
  }, [location.pathname]);

  function markVisited(path: string) {
    visitedPaths.add(path);
    localStorage.setItem('alphatekx_visited_paths', JSON.stringify([...visitedPaths]));
  }

  function dismissHint() {
    localStorage.setItem('alphatekx_sidebar_hint_dismissed', '1');
    setHintDismissed(true);
  }

  // Items that should show a "new" dot until first visit
  const NEW_BADGE_PATHS = ['/tools', '/vault'];

  const displayName = appUser?.display_name || appUser?.email || 'User';
  const credits = formatCredits(appUser?.credits);
  const isAdmin = appUser?.role === 'admin';
  const liveCount = useOnlineCount();

  // Flash the credit balance when it changes (e.g. after payment)
  const prevCreditsRef = useRef<string>(credits);
  const [creditFlash, setCreditFlash] = useState(false);
  useEffect(() => {
    if (prevCreditsRef.current !== credits && prevCreditsRef.current !== '—') {
      setCreditFlash(true);
      const t = setTimeout(() => setCreditFlash(false), 900);
      return () => clearTimeout(t);
    }
    prevCreditsRef.current = credits;
  }, [credits]);
  const activeTheme = THEME_OPTIONS.find(o => o.id === theme) ?? THEME_OPTIONS[0];

  /* ── 4-Colour theme picker — reused in both sidebar and mobile ── */
  const ThemePicker = () => (
    <div className="relative">
      <button
        onClick={() => setPickerOpen(v => !v)}
        title="Switch colour theme"
        className="flex items-center gap-2 w-full px-3 py-2 rounded-lg border border-border/60 bg-secondary/40 hover:bg-secondary/70 text-muted-foreground hover:text-foreground text-xs font-medium transition-all"
      >
        <Palette className="h-3.5 w-3.5 shrink-0 text-primary" />
        <span className="flex-1 text-left">{activeTheme.label}</span>
        {/* Active dot */}
        <span
          className="h-3 w-3 rounded-full shrink-0 border border-white/20"
          style={{ backgroundColor: activeTheme.dot }}
        />
      </button>

      {pickerOpen && (
        <>
          {/* Backdrop */}
          <div className="fixed inset-0 z-40" onClick={() => setPickerOpen(false)} />
          <div className="absolute bottom-full left-0 mb-2 w-full z-50 bg-popover border border-border/60 rounded-xl shadow-xl p-2 space-y-1 animate-in fade-in slide-in-from-bottom-2 duration-150">
            {THEME_OPTIONS.map(opt => (
              <button
                key={opt.id}
                onClick={() => { setTheme(opt.id); setPickerOpen(false); }}
                className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-xs font-bold transition-all ${
                  theme === opt.id
                    ? 'bg-primary/10 text-foreground border border-primary/30'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary/60'
                }`}
              >
                <span
                  className="h-4 w-4 rounded-full shrink-0 border border-white/20 shadow-sm"
                  style={{ backgroundColor: opt.dot }}
                />
                <span className="flex-1 text-left uppercase tracking-tight">{opt.label}</span>
                {theme === opt.id && (
                  <span className="text-[10px] text-primary font-black uppercase tracking-widest">Active</span>
                )}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );

  const sidebarContent = (
    <div className="flex flex-col h-full bg-background">
      {/* Brand */}
      <div className="flex items-center gap-3 px-6 py-8 border-b border-border/40">
        <div className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/10 border border-primary/20 shrink-0">
          <div className="absolute inset-0 rounded-2xl bg-primary/5 blur-sm animate-glow-pulse" />
          <Shield className="h-6 w-6 text-primary relative z-10" />
        </div>
        <div>
          <span className="text-xl font-black tracking-tighter gradient-text leading-none block uppercase">
            AlphaTekx
          </span>
          <span className="text-[10px] text-muted-foreground/50 font-bold uppercase tracking-[0.2em] mt-0.5 block">V3.0 // AI OS</span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-4 py-6 space-y-1.5">
        {navItems
          .filter(item => !item.adminOnly || isAdmin)
          .map(item => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            const isCommunity = item.path === '/community';
            const showUnread  = isCommunity && communityUnread > 0 && !isActive;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => { setMobileOpen(false); markVisited(item.path); }}
                className={`relative flex items-center gap-3.5 rounded-xl px-4 py-3.5 text-sm font-bold tracking-tight transition-all duration-200 min-h-[52px] group ${
                  isActive
                    ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary/80'
                }`}
              >
                <Icon className={`h-5 w-5 shrink-0 transition-transform duration-200 group-hover:scale-110 ${isActive ? 'text-primary-foreground' : 'text-primary/60'}`} />
                <span className="truncate flex-1">{item.label}</span>
                {/* Community unread badge */}
                {showUnread && (
                  <span className="flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-primary text-primary-foreground text-[10px] font-black shrink-0 animate-in fade-in duration-200">
                    {communityUnread > 99 ? '99+' : communityUnread}
                  </span>
                )}
                {/* Pulsing "new" dot — shown until first visit */}
                {NEW_BADGE_PATHS.includes(item.path) && !visitedPaths.has(item.path) && !isActive && (
                  <span className="relative flex h-2.5 w-2.5 shrink-0">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-60" />
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary" />
                  </span>
                )}
                {isActive && (
                  <div className="ml-auto h-1.5 w-1.5 rounded-full bg-primary-foreground/60 shrink-0" />
                )}
              </Link>
            );
          })}
      </nav>

      {/* Footer / User */}
      <div className="px-4 py-6 border-t border-border/40 space-y-3">
        {/* Credit balance card */}
        <div className="relative overflow-hidden flex flex-col gap-3 p-4 rounded-2xl bg-gradient-to-br from-secondary/80 to-secondary/40 border border-border/60">
          <div className="absolute top-0 right-0 w-20 h-20 bg-primary/5 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-2">
              <Zap className="h-3.5 w-3.5 text-yellow-400 shrink-0" />
              <span className="text-[10px] font-black text-muted-foreground/60 uppercase tracking-widest">Reserve</span>
            </div>
            <span className={`text-xl font-black text-primary tabular-nums glow-sm transition-all duration-300 ${creditFlash ? "scale-125 text-green-400 drop-shadow-[0_0_12px_rgba(34,197,94,0.8)]" : ""}`}>{credits}</span>
          </div>
          <Button
            onClick={() => { setBuyCreditsOpen(true); setMobileOpen(false); }}
            className="w-full h-10 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground font-black uppercase tracking-wider text-xs shadow-lg shadow-primary/20 transition-all active:scale-95 relative z-10"
          >
            <CreditCard className="mr-2 h-3.5 w-3.5" />
            Refill Credits
          </Button>
        </div>

        {/* Theme picker */}
        <ThemePicker />

        {/* User profile row */}
        <div className="flex items-center gap-3 px-2 py-1">
          {appUser?.photo_url ? (
            <img
              src={appUser.photo_url}
              alt={displayName}
              className="h-9 w-9 rounded-xl object-cover border border-border/60 shrink-0"
            />
          ) : (
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary/20 to-secondary border border-border/60 shrink-0">
              <User className="h-4 w-4 text-primary" />
            </div>
          )}
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold truncate leading-tight">{displayName}</p>
            <p className="text-[10px] text-muted-foreground/50 font-medium truncate uppercase tracking-tighter">Authorized Operator</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSignOutOpen(true)}
            aria-label="Sign out"
            className="h-8 w-8 rounded-lg hover:bg-destructive/10 hover:text-destructive transition-colors shrink-0"
          >
            <LogOut className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen w-full">
      <SignOutDialog open={signOutOpen} onOpenChange={setSignOutOpen} />
      {/* Desktop sidebar */}
      <aside className="hidden md:flex flex-col w-64 shrink-0 bg-background border-r border-border/40">
        {sidebarContent}
      </aside>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0 h-[100dvh] overflow-hidden">
        {/* One-time sidebar discovery hint — shown until dismissed */}
        {!hintDismissed && (
          <div
            className="shrink-0 flex items-center justify-between gap-3 px-4 py-2.5 border-b"
            style={{ background: 'rgba(34,211,238,0.07)', borderColor: 'rgba(34,211,238,0.18)' }}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="text-base shrink-0">👈</span>
              <p className="text-xs font-bold truncate" style={{ color: 'rgba(34,211,238,0.9)' }}>
                <span className="hidden sm:inline">Everything is in the sidebar — </span>
                <span style={{ color: '#e2e8f0', fontWeight: 500 }}>Tools, App Vault, Build With Us &amp; more. Explore the menu on the left.</span>
              </p>
            </div>
            <button
              onClick={dismissHint}
              className="shrink-0 text-[11px] font-black uppercase tracking-widest px-3 py-1 rounded-full transition-all"
              style={{ color: 'rgba(34,211,238,0.6)', border: '1px solid rgba(34,211,238,0.2)' }}
              onMouseEnter={e => (e.currentTarget.style.color = '#22d3ee')}
              onMouseLeave={e => (e.currentTarget.style.color = 'rgba(34,211,238,0.6)')}
            >
              Got it
            </button>
          </div>
        )}
        {/* Persistent System Status Banner — topmost strip on every app page */}
        <div className="shrink-0 w-full bg-[#080910] border-b border-border/20 px-4 py-1.5 flex items-center justify-between overflow-hidden">
          {/* Left: system status */}
          <div className="flex items-center gap-2.5">
            <div className="relative flex h-2 w-2 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
            </div>
            <span className="text-[10px] font-black tracking-[0.2em] text-green-400/80 uppercase">
              System Online // AlphaTekx OS v3.0
            </span>
          </div>

          {/* Right: live user count — real-time Presence */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-green-500/10 border border-green-500/20 select-none" title="Users on site right now">
              <span className="relative flex h-1.5 w-1.5 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-70" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-green-500" />
              </span>
              <span className="text-[10px] font-black tabular-nums text-green-400 leading-none">
                {formatLiveCount(liveCount)}
              </span>
              <span className="text-[9px] font-bold text-green-500/60 uppercase tracking-[0.15em] leading-none hidden sm:inline">
                live
              </span>
            </div>
            <div className="hidden md:flex items-center gap-4">
              <span className="text-[9px] font-bold text-muted-foreground/30 uppercase tracking-widest">
                Encrypted Neural Link Active
              </span>
              <div className="h-1 w-12 bg-gradient-to-r from-primary/40 to-transparent rounded-full" />
            </div>
          </div>
        </div>

        {/* Mobile header */}
        <header className="md:hidden bg-background border-b border-border/40 px-4 h-16 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 border border-primary/20">
              <Shield className="h-5 w-5 text-primary" />
            </div>
            <span className="text-base font-black tracking-tighter gradient-text uppercase">AlphaTekx</span>
          </div>

          <div className="flex items-center gap-3">
            {/* Credit balance chip — mobile */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-secondary border border-border/60">
              <Zap className="h-3.5 w-3.5 text-yellow-400" />
              <span className={`text-xs font-bold tabular-nums transition-all duration-300 ${creditFlash ? "text-green-400 scale-110" : ""}`}>{credits}</span>
            </div>

            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="Open menu" className="h-10 w-10 rounded-xl bg-secondary/50 border border-border/40">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 bg-background border-r border-border/40 p-0">
                {sidebarContent}
              </SheetContent>
            </Sheet>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 min-w-0 flex flex-col overflow-hidden">
          {children}
        </main>
      </div>

      {/* Buy Credits modal — accessible from anywhere in the layout */}
      {buyCreditsOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/90 backdrop-blur-md"
          onClick={(e) => { if (e.target === e.currentTarget) setBuyCreditsOpen(false); }}
        >
          <div className="w-full max-w-[calc(100%-2rem)] md:max-w-lg">
            <CreditsExhaustedModal onClose={() => setBuyCreditsOpen(false)} />
          </div>
        </div>
      )}
    </div>
  );
}
