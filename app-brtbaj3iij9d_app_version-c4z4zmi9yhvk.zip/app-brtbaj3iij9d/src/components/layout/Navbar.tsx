import { useUserSession } from '@/contexts/UserSessionContext';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Shield, LogOut, LayoutDashboard, Menu, X } from 'lucide-react';
import { useState } from 'react';
import SignOutDialog from '@/components/common/SignOutDialog';
import { useOnlineCount, formatLiveCount } from '@/hooks/use-online-count';

export default function Navbar() {
  const { appUser } = useUserSession();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [signOutOpen, setSignOutOpen] = useState(false);
  const liveCount = useOnlineCount();

  if (!appUser) return null;

  return (
    <nav className="sticky top-0 z-50 glass-strong border-b border-white/10">
      <SignOutDialog open={signOutOpen} onOpenChange={setSignOutOpen} />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/dashboard" className="flex items-center gap-2 shrink-0">
            <Shield className="h-6 w-6 text-primary" />
            <span className="text-lg font-bold tracking-tight gradient-text">AlphaTekx</span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-6">
            <Link
              to="/dashboard"
              className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <LayoutDashboard className="h-4 w-4" />
              Dashboard
            </Link>
          </div>

          {/* Right side: live badge + user + logout */}
          <div className="hidden md:flex items-center gap-4">
            {/* Live users badge */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-500/10 border border-green-500/25 select-none" title="People on site right now">
              <span className="relative flex h-2 w-2 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-70" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-green-500" />
              </span>
              <span className="text-xs font-bold tabular-nums text-green-400 leading-none">
                {formatLiveCount(liveCount)}
              </span>
              <span className="text-[10px] font-medium text-green-500/70 leading-none hidden lg:inline">live</span>
            </div>

            <span className="text-xs text-muted-foreground truncate max-w-[140px]">
              {appUser.email || appUser.display_name || 'User'}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSignOutOpen(true)}
              className="gap-1.5 text-muted-foreground hover:text-foreground hover:bg-white/5"
            >
              <LogOut className="h-4 w-4" />
              Sign Out
            </Button>
          </div>

          {/* Mobile toggle */}
          <div className="md:hidden flex items-center gap-2">
            {/* Live badge — mobile */}
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/25 select-none">
              <span className="relative flex h-1.5 w-1.5 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-70" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-green-500" />
              </span>
              <span className="text-[11px] font-bold tabular-nums text-green-400 leading-none">
                {formatLiveCount(liveCount)}
              </span>
            </div>
            <button
              className="p-2 text-muted-foreground hover:text-foreground"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden border-t border-white/10 px-4 py-4 space-y-3">
          <Link
            to="/dashboard"
            className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground"
            onClick={() => setMobileOpen(false)}
          >
            <LayoutDashboard className="h-4 w-4" />
            Dashboard
          </Link>
          <div className="pt-2 border-t border-white/10">
            <span className="text-xs text-muted-foreground block mb-2">
              {appUser.email || appUser.display_name || 'User'}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => { setMobileOpen(false); setSignOutOpen(true); }}
              className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground hover:bg-white/5"
            >
              <LogOut className="h-4 w-4" />
              Sign Out
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
}