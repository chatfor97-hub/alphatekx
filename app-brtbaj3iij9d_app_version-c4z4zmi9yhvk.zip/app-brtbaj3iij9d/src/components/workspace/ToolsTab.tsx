import { useState } from 'react';
import { Loader2, Zap, Globe, BookOpen, Palette, Link2, Video, Shield, Headphones, Image, Cpu, Wrench, FlaskConical, BriefcaseBusiness, Flame, Code2, FileText, Rocket } from 'lucide-react';
import { TOOLS } from '@/lib/tools';
import { formatCredits } from '@/lib/credits';
import { useUserSession } from '@/contexts/UserSessionContext';
import BusinessPlanGenerator from '@/components/builtin/BusinessPlanGenerator';
import YouTubeScriptArchitect from '@/components/builtin/YouTubeScriptArchitect';
import ResumeStudio from '@/components/builtin/ResumeStudio';
import LaunchForge from '@/components/builtin/LaunchForge';

const TOOL_ICONS: Record<string, React.ElementType> = {
  'Website Builder':  Globe,
  'Exam Prep':        BookOpen,
  'Art Generator':    Palette,
  'Media Linker':     Link2,
  'Video Generator':  Video,
  'Contract Guard':   Shield,
  'Voice Gen':        Headphones,
  'Thumbnail Studio': Image,
};

const BUILT_IN_COST = 3;

// Live Built-In Systems — expand this array as each ships
const BUILT_IN_LIVE: {
  id: string;
  label: string;
  icon: React.ElementType;
  desc: string;
  creditCost: number;
  /** If set, opens this URL in a new tab instead of rendering inline */
  externalUrl?: string;
}[] = [
  {
    id: 'business-plan',
    label: 'Business Plan Generator',
    icon: BriefcaseBusiness,
    desc: 'Generate a complete, investor-ready business plan for any idea in under 60 seconds.',
    creditCost: BUILT_IN_COST,
  },
  {
    id: 'youtube-shock',
    label: 'YouTube Shock-Factor Script',
    icon: Flame,
    desc: 'Generate a 30-second cold open + 3 viral title formulas engineered to stop the scroll.',
    creditCost: BUILT_IN_COST,
  },
  {
    id: 'live-editor',
    label: 'Live Code Editor',
    icon: Code2,
    desc: 'Write HTML, CSS & JS and see your code render live — like CodePen, built into AlphaTekx.',
    creditCost: 0,
    externalUrl: '/tools/live-editor',
  },
  {
    id: 'resume-studio',
    label: 'Resume Studio',
    icon: FileText,
    desc: 'Generate an ATS-optimized resume + tailored cover letter from your background and any job description.',
    creditCost: BUILT_IN_COST,
  },
  {
    id: 'launch-forge',
    label: 'LaunchForge',
    icon: Rocket,
    desc: 'Type your business idea in one sentence — get a full brand identity, landing page copy, tech stack, marketing kit, and 30-day launch roadmap.',
    creditCost: BUILT_IN_COST,
  },
];

// Placeholder slots for upcoming built-in systems
const BUILT_IN_COMING: { label: string; icon: React.ElementType; desc: string }[] = [
  { label: 'AI Workflow Engine', icon: Cpu,         desc: 'Automate multi-step processes end-to-end with an intelligent task pipeline.' },
  { label: 'Data Vault',         icon: FlaskConical, desc: 'Securely store, query, and analyse structured data powered by AlphaTekx.' },
  { label: 'DevKit Pro',         icon: Wrench,       desc: 'In-house code execution, debugging, and deployment tools built natively.' },
];

interface ToolsTabProps {
  onOpenTool: (name: string, url: string) => void;
  deducting?: boolean;
}

export default function ToolsTab({ onOpenTool, deducting = false }: ToolsTabProps) {
  const { appUser } = useUserSession();
  const rawCredits = appUser?.credits ?? 0;
  const credits = formatCredits(appUser?.credits);
  const noCredits = rawCredits < 5;
  const [activeBuiltIn, setActiveBuiltIn] = useState<string | null>(null);

  // If a built-in tool is open, render it full-screen inside the tab
  if (activeBuiltIn === 'business-plan') {
    return <BusinessPlanGenerator onClose={() => setActiveBuiltIn(null)} />;
  }
  if (activeBuiltIn === 'youtube-shock') {
    return <YouTubeScriptArchitect onClose={() => setActiveBuiltIn(null)} />;
  }
  if (activeBuiltIn === 'resume-studio') {
    return <ResumeStudio onClose={() => setActiveBuiltIn(null)} />;
  }
  if (activeBuiltIn === 'launch-forge') {
    return <LaunchForge onClose={() => setActiveBuiltIn(null)} />;
  }

  return (
    <div className="flex-1 overflow-y-auto min-h-0 custom-scrollbar">
      <div className="max-w-5xl mx-auto px-4 md:px-6 py-6 md:py-10 space-y-10">

        {/* ── Section: Integrated Tools ─────────────────── */}
        <div className="space-y-5">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 border border-primary/20">
                  <Zap className="h-5 w-5 text-primary" />
                </div>
                <h2 className="text-lg font-black uppercase tracking-tight text-foreground text-balance">
                  Integrated AI Tools
                </h2>
              </div>
              <p className="text-xs text-muted-foreground/60 font-medium pl-[2.875rem]">
                Each launch deducts <span className="text-primary font-black">5 credits</span> from your reserve.
              </p>
            </div>
            {/* Live credit badge */}
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl border border-border/50 bg-secondary/40 shrink-0 self-start sm:self-auto">
              <Zap className="h-3.5 w-3.5 text-yellow-400 shrink-0" />
              <span className="text-xs font-black tabular-nums text-foreground">{credits}</span>
              <span className="text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest">credits</span>
            </div>
          </div>

          {/* Tools grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {TOOLS.map((tool) => {
              const Icon = TOOL_ICONS[tool.name] ?? Zap;
              const isDisabled = deducting || noCredits;
              return (
                <button
                  key={tool.name}
                  disabled={isDisabled}
                  onClick={() => onOpenTool(tool.name, tool.url)}
                  className="group relative flex flex-col gap-3.5 w-full p-4 md:p-5 rounded-2xl bg-secondary/30 hover:bg-secondary/70 border border-border/40 hover:border-primary/50 transition-all duration-200 text-left disabled:opacity-40 disabled:grayscale disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
                >
                  {/* Icon + launch indicator */}
                  <div className="flex items-start justify-between">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-background border border-border/60 group-hover:border-primary/40 group-hover:bg-primary/5 transition-all duration-200 shrink-0">
                      {deducting
                        ? <Loader2 className="h-5 w-5 text-primary animate-spin" />
                        : <Icon className="h-5 w-5 text-primary" />}
                    </div>
                    <span className="text-[10px] font-black text-muted-foreground/30 group-hover:text-primary/60 uppercase tracking-widest transition-colors">
                      5 cr
                    </span>
                  </div>

                  {/* Name + description */}
                  <div className="space-y-1 min-w-0">
                    <p className="text-xs md:text-sm font-black text-foreground uppercase tracking-tight truncate">
                      {tool.name}
                    </p>
                    <p className="text-[11px] text-muted-foreground/70 line-clamp-2 leading-snug font-medium text-pretty">
                      {tool.description}
                    </p>
                  </div>

                  {/* Hover launch CTA */}
                  <div className="mt-auto pt-2 border-t border-border/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    <span className="text-[10px] font-black text-primary uppercase tracking-widest">
                      Launch →
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {noCredits && (
            <p className="text-center text-xs text-muted-foreground/50 pt-1">
              Refill your credits to launch tools — use the <span className="text-primary font-bold">Refill Credits</span> button in the sidebar.
            </p>
          )}
        </div>

        {/* ── Section: Built-In Systems ─────────────────── */}
        <div className="space-y-5">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 border border-primary/20">
              <Zap className="h-4 w-4 text-primary" />
            </div>
            <div className="min-w-0">
              <h2 className="text-lg font-black uppercase tracking-tight text-foreground text-balance">
                Built-In Systems
              </h2>
              <p className="text-[10px] text-muted-foreground/50 font-bold uppercase tracking-widest">
                Native AlphaTekx infrastructure · {BUILT_IN_COST} credits per use
              </p>
            </div>
          </div>

          {/* Live built-in tools */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            {BUILT_IN_LIVE.map((item) => {
              const Icon = item.icon;
              const isExternal = !!item.externalUrl;
              const cardClass = "group relative flex flex-col gap-3.5 w-full p-4 md:p-5 rounded-2xl bg-secondary/30 hover:bg-secondary/70 border border-primary/20 hover:border-primary/50 transition-all duration-200 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50";

              const cardInner = (
                <>
                  {/* Live badge + cost */}
                  <div className="absolute top-3 right-3 flex items-center gap-1.5">
                    {item.creditCost > 0 && (
                      <span className="text-[9px] font-black text-muted-foreground/40 uppercase tracking-widest">
                        {item.creditCost} cr
                      </span>
                    )}
                    {item.creditCost === 0 && (
                      <span className="text-[9px] font-black text-emerald-400/70 uppercase tracking-widest">
                        Free
                      </span>
                    )}
                    <span className="flex items-center gap-1 text-[9px] font-black uppercase tracking-[0.15em] text-primary bg-primary/10 px-2 py-0.5 rounded-full border border-primary/20">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse inline-block" />
                      Live
                    </span>
                  </div>

                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-background border border-primary/30 group-hover:border-primary/60 group-hover:bg-primary/5 transition-all duration-200 shrink-0">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>

                  <div className="space-y-1 min-w-0 pr-8">
                    <p className="text-xs md:text-sm font-black text-foreground uppercase tracking-tight">
                      {item.label}
                    </p>
                    <p className="text-[11px] text-muted-foreground/70 line-clamp-2 leading-snug font-medium text-pretty">
                      {item.desc}
                    </p>
                  </div>

                  <div className="mt-auto pt-2 border-t border-border/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    <span className="text-[10px] font-black text-primary uppercase tracking-widest">
                      {isExternal ? 'Open in new tab →' : 'Open →'}
                    </span>
                  </div>
                </>
              );

              if (isExternal) {
                return (
                  <a
                    key={item.id}
                    href={item.externalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={cardClass}
                  >
                    {cardInner}
                  </a>
                );
              }

              return (
                <button
                  key={item.id}
                  onClick={() => setActiveBuiltIn(item.id)}
                  className={cardClass}
                >
                  {cardInner}
                </button>
              );
            })}

            {/* Coming-soon placeholders */}
            {BUILT_IN_COMING.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.label}
                  className="relative flex flex-col gap-3 p-4 md:p-5 rounded-2xl bg-secondary/10 border border-dashed border-border/30 opacity-50 cursor-not-allowed select-none overflow-hidden"
                >
                  <div className="absolute top-3 right-3">
                    <span className="text-[9px] font-black uppercase tracking-[0.15em] text-muted-foreground/40 bg-secondary/60 px-2 py-0.5 rounded-full border border-border/30">
                      Soon
                    </span>
                  </div>
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-background/60 border border-border/30 shrink-0">
                    <Icon className="h-5 w-5 text-muted-foreground/40" />
                  </div>
                  <div className="space-y-1 min-w-0 pr-10">
                    <p className="text-xs md:text-sm font-black text-muted-foreground/50 uppercase tracking-tight">
                      {item.label}
                    </p>
                    <p className="text-[11px] text-muted-foreground/35 leading-snug font-medium text-pretty line-clamp-2">
                      {item.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}
