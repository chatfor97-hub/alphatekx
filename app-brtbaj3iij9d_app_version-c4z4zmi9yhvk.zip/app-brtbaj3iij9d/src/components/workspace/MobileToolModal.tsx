import { X } from 'lucide-react';
import { useEffect } from 'react';

interface MobileToolModalProps {
  toolName: string;
  toolUrl: string;
  onClose: () => void;
}

export default function MobileToolModal({ toolName, toolUrl, onClose }: MobileToolModalProps) {
  // Lock body scroll while modal is open
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex flex-col" style={{ background: 'rgba(8,13,26,0.97)' }}>
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 py-3 border-b border-white/10 bg-black/40 backdrop-blur-xl">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="h-2 w-2 rounded-full bg-primary animate-pulse shrink-0" />
          <span className="text-sm font-semibold text-foreground truncate">{toolName}</span>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/10 transition-colors"
            title="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Full-screen iframe */}
      <div className="flex-1 min-h-0">
        <iframe
          key={toolUrl}
          src={toolUrl}
          title={toolName}
          className="w-full h-full border-0"
          allow="fullscreen; camera; microphone; clipboard-write"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals"
        />
      </div>
    </div>
  );
}
