import { X } from 'lucide-react';

interface WorkspaceViewProps {
  toolName: string;
  toolUrl: string;
  onClose: () => void;
}

export default function WorkspaceView({ toolName, toolUrl, onClose }: WorkspaceViewProps) {
  return (
    <div className="flex flex-col h-full w-full min-w-0 workspace-glass relative overflow-hidden">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 py-3 border-b border-white/10 bg-black/20">
        <div className="flex items-center gap-2 min-w-0">
          <span className="h-2 w-2 rounded-full bg-primary animate-pulse shrink-0" />
          <span className="text-sm font-semibold text-foreground truncate">{toolName}</span>
          <span className="text-xs text-muted-foreground/60 hidden sm:inline truncate max-w-[160px]">{toolUrl}</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/10 transition-colors"
            title="Close workspace"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Iframe */}
      <div className="flex-1 min-h-0 relative">
        <iframe
          key={toolUrl}
          src={toolUrl}
          title={toolName}
          className="w-full h-full border-0"
          allow="fullscreen; camera; microphone; clipboard-write"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-downloads allow-modals"
        />
      </div>
    </div>
  );
}
