import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { deductCredits, formatCredits } from '@/lib/credits';
import { useUserSession } from '@/contexts/UserSessionContext';
import { callEdgeFunction } from '@/lib/edgeFunction';
import {
  FileText, Loader2, Copy, Check, RefreshCw,
  Zap, X, Sparkles, Briefcase, ChevronDown, ChevronUp,
  FileCheck2, Mail, LayoutTemplate,
} from 'lucide-react';

// ─── Constants ────────────────────────────────────────────────────────────────
const TOOL_COST = 5;

type Mode = 'resume' | 'cover-letter' | 'both';

interface ModeOption {
  id: Mode;
  label: string;
  icon: React.ElementType;
  desc: string;
  cost: number;
}

const MODE_OPTIONS: ModeOption[] = [
  {
    id:    'both',
    label: 'Resume + Cover Letter',
    icon:  LayoutTemplate,
    desc:  'Full application package — ATS resume & tailored letter',
    cost:  TOOL_COST,
  },
  {
    id:    'resume',
    label: 'Resume Only',
    icon:  FileCheck2,
    desc:  'ATS-optimized resume with quantified bullet points',
    cost:  3,
  },
  {
    id:    'cover-letter',
    label: 'Cover Letter Only',
    icon:  Mail,
    desc:  'Compelling, personalized letter that gets read',
    cost:  3,
  },
];

const EXAMPLE_JOBS = [
  'Senior Product Manager at a Series B fintech startup',
  'Full-Stack Engineer at Google',
  'Marketing Director at a global fashion brand',
  'Data Scientist at a healthcare AI company',
  'Sales Executive at a B2B SaaS company',
];

interface Section { title: string; content: string }

function parseMarkdown(raw: string): Section[] {
  const parts = raw.split(/\n(?=##\s)/);
  return parts
    .map(p => {
      const lines = p.trim().split('\n');
      const title = lines[0].replace(/^#+\s*/, '').trim();
      const content = lines.slice(1).join('\n').trim();
      return { title, content };
    })
    .filter(s => s.title && s.content);
}

// Render markdown content: bold, lists, paragraphs
function MarkdownBlock({ text }: { text: string }) {
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];
  let listItems: string[] = [];

  function flushList(key: string) {
    if (!listItems.length) return;
    elements.push(
      <ul key={key} className="space-y-1 my-1">
        {listItems.map((item, i) => (
          <li key={i} className="flex items-start gap-2 text-xs text-foreground/85 leading-relaxed">
            <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-primary/60 shrink-0" />
            <span dangerouslySetInnerHTML={{ __html: formatInline(item) }} />
          </li>
        ))}
      </ul>
    );
    listItems = [];
  }

  function formatInline(s: string): string {
    return s
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>');
  }

  lines.forEach((line, idx) => {
    const trimmed = line.trim();
    if (/^[-*•]\s/.test(trimmed)) {
      listItems.push(trimmed.replace(/^[-*•]\s*/, ''));
    } else {
      flushList(`list-${idx}`);
      if (trimmed) {
        elements.push(
          <p key={idx} className="text-xs text-foreground/85 leading-relaxed my-0.5"
             dangerouslySetInnerHTML={{ __html: formatInline(trimmed) }} />
        );
      }
    }
  });
  flushList('list-end');
  return <>{elements}</>;
}

interface Props { onClose?: () => void }

// ─── Component ────────────────────────────────────────────────────────────────
export default function ResumeStudio({ onClose }: Props) {
  const { appUser, refreshBalance } = useUserSession();

  const rawCredits = appUser?.credits ?? 0;
  const credits    = formatCredits(appUser?.credits);

  const [mode,            setMode]           = useState<Mode>('both');
  const [name,            setName]           = useState('');
  const [experience,      setExperience]     = useState('');
  const [jobDescription,  setJobDescription] = useState('');
  const [loading,         setLoading]        = useState(false);
  const [copyStates,      setCopyStates]     = useState<Record<string, boolean>>({});

  // Result state
  const [resumeSections,  setResumeSections]  = useState<Section[] | null>(null);
  const [coverLetter,     setCoverLetter]     = useState<string | null>(null);
  const [activeTab,       setActiveTab]       = useState<'resume' | 'cover-letter'>('resume');
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});

  const selectedMode = MODE_OPTIONS.find(m => m.id === mode)!;
  const cost         = selectedMode.cost;
  const hasCredits   = rawCredits >= cost;
  const hasResult    = !!(resumeSections || coverLetter);

  // ── Copy helper ──────────────────────────────────────────────────────────
  async function copyText(text: string, key: string) {
    await navigator.clipboard.writeText(text);
    setCopyStates(prev => ({ ...prev, [key]: true }));
    setTimeout(() => setCopyStates(prev => ({ ...prev, [key]: false })), 2000);
  }

  function copyAllResume() {
    if (!resumeSections) return;
    const full = resumeSections.map(s => `## ${s.title}\n${s.content}`).join('\n\n');
    copyText(full, 'resume-all');
    toast.success('Full resume copied!');
  }

  function copyAllLetter() {
    if (!coverLetter) return;
    copyText(coverLetter, 'letter-all');
    toast.success('Cover letter copied!');
  }

  // ── Generate ─────────────────────────────────────────────────────────────
  async function handleGenerate() {
    if (!experience.trim()) { toast.error('Please enter your experience / background.'); return; }
    if (!jobDescription.trim()) { toast.error('Please paste the job description.'); return; }
    if (!hasCredits) { toast.error(`You need ${cost} credits for this. Top up from the sidebar.`); return; }

    setLoading(true);

    try {
      const data = await callEdgeFunction<{ code: string; data: { resume: string; coverLetter: string }; message?: string }>(
        'resume-studio',
        { experience: experience.trim(), jobDescription: jobDescription.trim(), mode, name: name.trim() },
      );

      if (data?.code !== 'SUCCESS') {
        throw new Error(data?.message || 'Generation failed — please try again.');
      }

      const { resume: rawResume, coverLetter: rawLetter } = data.data as {
        resume: string;
        coverLetter: string;
      };

      if (rawResume)  setResumeSections(parseMarkdown(rawResume));
      if (rawLetter)  setCoverLetter(rawLetter);

      setActiveTab(mode === 'cover-letter' ? 'cover-letter' : 'resume');
      setCollapsedSections({});

      // Deduct credits after success — non-blocking so a Firestore hiccup never breaks generation
      deductCredits(cost)
        .then(d => { if (d.success) refreshBalance(); })
        .catch(e => console.error('Credit deduction failed (non-blocking):', e));

      toast.success(`Done! ${cost} credits used.`, { duration: 3000 });
    } catch (err) {
      console.error('[ResumeStudio] generate error:', err);
      toast.error((err as Error).message || 'Unexpected error — please try again.');
    } finally {
      setLoading(false);
    }
  }

  function handleReset() {
    setResumeSections(null);
    setCoverLetter(null);
    setCollapsedSections({});
  }

  function toggleSection(title: string) {
    setCollapsedSections(prev => ({ ...prev, [title]: !prev[title] }));
  }

  // ── Cover letter section rendering ────────────────────────────────────────
  function renderCoverLetter() {
    if (!coverLetter) return null;
    const sections = parseMarkdown(coverLetter);
    if (sections.length === 0) {
      // no headings — render as plain paragraphs
      return (
        <div className="space-y-3 p-5">
          {coverLetter.split('\n\n').filter(Boolean).map((para, i) => (
            <p key={i} className="text-xs leading-relaxed text-foreground/85"
               dangerouslySetInnerHTML={{ __html: para.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>') }} />
          ))}
        </div>
      );
    }
    return (
      <div className="space-y-3 p-4">
        {sections.map(s => (
          <div key={s.title} className="rounded-xl border border-border/30 bg-secondary/20 overflow-hidden">
            <div className="px-4 py-2.5 border-b border-border/20 flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-widest text-primary">{s.title}</h4>
              <button
                onClick={() => copyText(s.content, `letter-${s.title}`)}
                className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground transition-colors"
              >
                {copyStates[`letter-${s.title}`]
                  ? <><Check className="h-3 w-3 text-green-400" /> Copied</>
                  : <><Copy className="h-3 w-3" /> Copy</>}
              </button>
            </div>
            <div className="px-4 py-3">
              <MarkdownBlock text={s.content} />
            </div>
          </div>
        ))}
      </div>
    );
  }

  // ── RESULTS VIEW ──────────────────────────────────────────────────────────
  if (hasResult) {
    const tabs = [
      ...(resumeSections  ? [{ id: 'resume'        as const, label: 'Resume',       icon: FileCheck2 }] : []),
      ...(coverLetter     ? [{ id: 'cover-letter'  as const, label: 'Cover Letter', icon: Mail       }] : []),
    ];

    return (
      <div className="flex flex-col h-full min-h-0 overflow-hidden">
        {/* Header */}
        <div className="shrink-0 flex items-center justify-between px-4 md:px-6 py-4 border-b border-white/10 bg-black/20">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 border border-primary/25 shrink-0">
              <FileText className="h-5 w-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-black uppercase tracking-tight text-foreground">Resume Studio</p>
              <p className="text-[10px] text-muted-foreground/60 font-bold uppercase tracking-widest">AI-Generated · Review before using</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-muted-foreground hover:text-foreground hover:bg-white/10 transition-all border border-white/10"
            >
              <RefreshCw className="h-3.5 w-3.5" /> New
            </button>
            {onClose && (
              <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/10 transition-all">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        {/* Tabs */}
        {tabs.length > 1 && (
          <div className="shrink-0 flex border-b border-white/10 bg-black/10">
            {tabs.map(t => {
              const Icon = t.icon;
              return (
                <button
                  key={t.id}
                  onClick={() => setActiveTab(t.id)}
                  className={`flex items-center gap-2 px-5 py-3 text-xs font-black uppercase tracking-widest transition-all border-b-2 ${
                    activeTab === t.id
                      ? 'text-primary border-primary bg-primary/5'
                      : 'text-muted-foreground border-transparent hover:text-foreground hover:border-white/20'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {t.label}
                </button>
              );
            })}
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto min-h-0 custom-scrollbar">
          {/* Resume tab */}
          {activeTab === 'resume' && resumeSections && (
            <div>
              {/* Copy-all bar */}
              <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-2.5 bg-card/95 backdrop-blur-sm border-b border-border/30">
                <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground/50">
                  {resumeSections.length} sections generated
                </span>
                <button
                  onClick={copyAllResume}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 border border-primary/20 text-xs font-black text-primary hover:bg-primary/20 transition-all"
                >
                  {copyStates['resume-all']
                    ? <><Check className="h-3.5 w-3.5" /> Copied!</>
                    : <><Copy className="h-3.5 w-3.5" /> Copy Full Resume</>}
                </button>
              </div>

              {/* Sections */}
              <div className="p-4 space-y-3">
                {resumeSections.map(section => (
                  <div key={section.title} className="rounded-xl border border-border/30 bg-secondary/20 overflow-hidden">
                    <button
                      onClick={() => toggleSection(section.title)}
                      className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/5 transition-colors"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="h-2 w-2 rounded-full bg-primary shrink-0" />
                        <h3 className="text-xs font-black uppercase tracking-widest text-foreground text-left">{section.title}</h3>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={(e) => { e.stopPropagation(); copyText(section.content, `resume-${section.title}`); }}
                          className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground transition-colors px-2 py-1 rounded hover:bg-white/10"
                        >
                          {copyStates[`resume-${section.title}`]
                            ? <><Check className="h-3 w-3 text-green-400" /> Copied</>
                            : <><Copy className="h-3 w-3" /> Copy</>}
                        </button>
                        {collapsedSections[section.title]
                          ? <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                          : <ChevronUp className="h-3.5 w-3.5 text-muted-foreground" />}
                      </div>
                    </button>
                    {!collapsedSections[section.title] && (
                      <div className="px-4 pb-4 pt-1 border-t border-border/20">
                        <MarkdownBlock text={section.content} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Cover letter tab */}
          {activeTab === 'cover-letter' && coverLetter && (
            <div>
              <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-2.5 bg-card/95 backdrop-blur-sm border-b border-border/30">
                <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground/50">
                  Tailored to the job description
                </span>
                <button
                  onClick={copyAllLetter}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 border border-primary/20 text-xs font-black text-primary hover:bg-primary/20 transition-all"
                >
                  {copyStates['letter-all']
                    ? <><Check className="h-3.5 w-3.5" /> Copied!</>
                    : <><Copy className="h-3.5 w-3.5" /> Copy Full Letter</>}
                </button>
              </div>
              {renderCoverLetter()}
            </div>
          )}
        </div>

        {/* Footer disclaimer */}
        <div className="shrink-0 px-4 py-3 border-t border-white/10 bg-black/20">
          <p className="text-[10px] text-muted-foreground/40 text-center leading-relaxed font-medium">
            AI-generated content — review for accuracy before submitting applications
          </p>
        </div>
      </div>
    );
  }

  // ── INPUT FORM ────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col h-full min-h-0 overflow-hidden">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 md:px-6 py-4 border-b border-white/10 bg-black/20">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 border border-primary/25 shrink-0">
            <FileText className="h-5 w-5 text-primary" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-black uppercase tracking-tight text-foreground text-balance">Resume Studio</p>
            <p className="text-[10px] text-muted-foreground/60 font-bold uppercase tracking-widest">ATS-Optimized · AI-Powered · Professional Grade</p>
          </div>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-border/50 bg-secondary/40">
            <Zap className="h-3.5 w-3.5 text-yellow-400 shrink-0" />
            <span className="text-xs font-black tabular-nums text-foreground">{credits}</span>
            <span className="text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest hidden sm:inline">credits</span>
          </div>
          {onClose && (
            <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/10 transition-all">
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto min-h-0 custom-scrollbar">
        <div className="max-w-2xl mx-auto px-4 md:px-6 py-6 space-y-6">

          {/* Hero pitch */}
          <div className="rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 to-primary/5 p-5 space-y-2">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary shrink-0" />
              <h2 className="text-sm font-black uppercase tracking-tight text-foreground">
                Land Your Dream Job
              </h2>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Paste your background and the job description. AlphaTekx writes a <strong className="text-foreground">tailored, ATS-beating resume</strong> with quantified bullet points and a <strong className="text-foreground">cover letter hiring managers actually read</strong> — in seconds.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              {['ATS-Optimized', 'Action Verbs', 'Quantified Results', 'Role-Tailored', 'Human-Quality'].map(tag => (
                <span key={tag} className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-primary/10 border border-primary/20 text-primary">{tag}</span>
              ))}
            </div>
          </div>

          {/* Mode selector */}
          <div className="space-y-2.5">
            <label className="text-xs font-black uppercase tracking-widest text-muted-foreground/70">
              What do you need?
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {MODE_OPTIONS.map(m => {
                const Icon = m.icon;
                const isSelected = mode === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => setMode(m.id)}
                    className={`relative flex flex-col gap-2 p-3.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'border-primary/50 bg-primary/10 shadow-[0_0_16px_hsl(var(--primary)/0.15)]'
                        : 'border-border/40 bg-secondary/20 hover:border-primary/30 hover:bg-secondary/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className={`flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${
                        isSelected ? 'bg-primary/20 border border-primary/30' : 'bg-background/60 border border-border/40'
                      }`}>
                        <Icon className={`h-4 w-4 ${isSelected ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                      <span className={`text-[10px] font-black uppercase tracking-widest ${
                        isSelected ? 'text-primary' : 'text-muted-foreground/40'
                      }`}>
                        {m.cost} cr
                      </span>
                    </div>
                    <div>
                      <p className={`text-xs font-black leading-tight ${isSelected ? 'text-foreground' : 'text-foreground/70'}`}>
                        {m.label}
                      </p>
                      <p className="text-[10px] text-muted-foreground/60 leading-snug mt-0.5">{m.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Name (optional) */}
          <div className="space-y-2">
            <label className="text-xs font-black uppercase tracking-widest text-muted-foreground/70">
              Your Name <span className="text-muted-foreground/40 font-medium normal-case tracking-normal">(optional — for the document header)</span>
            </label>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Jordan Williams"
              className="w-full h-10 rounded-xl bg-secondary/30 border border-border/40 px-3 text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/50 transition-all"
            />
          </div>

          {/* Experience textarea */}
          <div className="space-y-2">
            <label className="text-xs font-black uppercase tracking-widest text-muted-foreground/70">
              Your Experience & Background <span className="text-red-400/80">*</span>
            </label>
            <p className="text-[11px] text-muted-foreground/50">
              Dump everything — jobs, titles, dates, responsibilities, projects, skills, education. The more detail, the better the output.
            </p>
            <textarea
              value={experience}
              onChange={e => setExperience(e.target.value)}
              placeholder={`Example:\n\nSoftware Engineer at Paystack (2021–2024)\n- Built payment reconciliation system handling ₦2B/month\n- Led team of 4 engineers, reduced API latency by 40%\n\nJunior Dev at Flutterwave (2019–2021)\n- Maintained mobile SDK used by 10,000+ merchants\n\nEducation: BSc Computer Science, University of Lagos, 2019\nSkills: React, Node.js, Python, PostgreSQL, AWS`}
              rows={10}
              className="w-full rounded-xl bg-secondary/30 border border-border/40 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/50 resize-none transition-all leading-relaxed"
            />
          </div>

          {/* Job description textarea */}
          <div className="space-y-2">
            <label className="text-xs font-black uppercase tracking-widest text-muted-foreground/70">
              Target Job Description <span className="text-red-400/80">*</span>
            </label>
            <p className="text-[11px] text-muted-foreground/50">
              Paste the full job posting. AlphaTekx will tailor every bullet point and keyword to match.
            </p>
            <div className="flex flex-wrap gap-1.5 pb-1">
              {EXAMPLE_JOBS.map(ex => (
                <button
                  key={ex}
                  onClick={() => setJobDescription(prev => prev || `Position: ${ex}\n\nRequirements:\n- `)}
                  className="text-[10px] font-bold px-2 py-1 rounded-full border border-border/30 bg-secondary/20 hover:bg-secondary/60 text-muted-foreground/60 hover:text-foreground transition-all"
                >
                  {ex}
                </button>
              ))}
            </div>
            <textarea
              value={jobDescription}
              onChange={e => setJobDescription(e.target.value)}
              placeholder="Paste the job description here — title, responsibilities, requirements, company info..."
              rows={10}
              className="w-full rounded-xl bg-secondary/30 border border-border/40 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/30 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/50 resize-none transition-all leading-relaxed"
            />
          </div>

          {/* No credits warning */}
          {!hasCredits && (
            <div className="rounded-xl border border-red-500/30 bg-red-500/5 px-4 py-3 flex items-center gap-2.5">
              <Zap className="h-4 w-4 text-red-400 shrink-0" />
              <p className="text-xs text-red-300/80">
                You need <strong className="text-red-300">{cost} credits</strong> to generate. Refill from the sidebar.
              </p>
            </div>
          )}

          {/* Generate button */}
          <Button
            onClick={handleGenerate}
            disabled={loading || !hasCredits || !experience.trim() || !jobDescription.trim()}
            className="w-full h-14 rounded-xl font-black uppercase tracking-widest text-sm bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_4px_20px_hsl(var(--primary)/0.35)] transition-all active:scale-[0.99]"
          >
            {loading ? (
              <><Loader2 className="h-5 w-5 animate-spin mr-2" />Crafting Your Documents…</>
            ) : (
              <><Briefcase className="h-5 w-5 mr-2" />Generate {selectedMode.label} · {cost} Credits</>
            )}
          </Button>

          {/* Loading state message */}
          {loading && (
            <div className="flex flex-col items-center gap-3 py-4">
              <div className="flex gap-1.5">
                {[0,1,2].map(i => (
                  <span key={i} className="h-2 w-2 rounded-full bg-primary/70"
                        style={{ animation: `pulse 1.2s ease-in-out ${i * 0.25}s infinite` }} />
                ))}
              </div>
              <p className="text-xs text-muted-foreground/60 font-medium text-center max-w-[28ch]">
                Analysing the job description and tailoring your documents…
              </p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
