import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { deductCredits, formatCredits } from '@/lib/credits';
import { useUserSession } from '@/contexts/UserSessionContext';
import { callEdgeFunction } from '@/lib/edgeFunction';
import {
  Flame, Loader2, Copy, Check, RefreshCw, Zap, X,
  Tv2, Sparkles, TrendingUp,
} from 'lucide-react';

// ─── Constants ───────────────────────────────────────────────────────────────
const TOOL_COST = 3;

const TONE_OPTIONS = [
  { id: 'tech-mystery',    label: 'Tech Mystery',     emoji: '🔮', desc: 'Secretive, conspiratorial, deep-dive' },
  { id: 'suspense',        label: 'Suspense',          emoji: '😰', desc: 'Edge-of-seat tension, dramatic pacing' },
  { id: 'shocking-truth',  label: 'Shocking Truth',    emoji: '😱', desc: 'Jaw-dropping reveals, counter-narrative' },
  { id: 'hype-energy',     label: 'Hype Energy',       emoji: '🔥', desc: 'High-octane, viral, loud & fast' },
  { id: 'real-talk',       label: 'Real Talk',         emoji: '💯', desc: 'No-filter, raw, street-smart honesty' },
  { id: 'cinematic-drama', label: 'Cinematic Drama',   emoji: '🎬', desc: 'Storytelling-first, emotional arc' },
];

const EXAMPLE_TOPICS = [
  'The Secret History of the iPhone',
  'Why 90% of African Startups Fail in Year 1',
  'The Dark Side of YouTube the Algorithm',
  'How Billionaires Really Make Their First Million',
  'The Technology That Will Replace Your Job by 2027',
];

// ─── Types ────────────────────────────────────────────────────────────────────
interface ShockOutput {
  hook: string;
  titles: string[];
  openingScript: string;
  patternBreak: string;
}

interface Props {
  onClose?: () => void;
}

// ─── Result parsing ───────────────────────────────────────────────────────────
function parseOutput(raw: string): ShockOutput {
  const extract = (tag: string): string => {
    const re = new RegExp(`##\\s*${tag}[\\s\\S]*?\\n([\\s\\S]*?)(?=\\n##|$)`, 'i');
    return raw.match(re)?.[1]?.trim() ?? '';
  };

  const titlesBlock = extract('VIRAL TITLES');
  const titles = titlesBlock
    .split('\n')
    .map(l => l.replace(/^[-*\d.]+\s*/, '').trim())
    .filter(Boolean)
    .slice(0, 3);

  return {
    hook: extract('SHOCK HOOK'),
    titles,
    openingScript: extract('OPENING SCRIPT'),
    patternBreak: extract('PATTERN BREAK'),
  };
}

// ─── Small copy button ───────────────────────────────────────────────────────
function CopyBtn({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 1800);
      }}
      className="flex items-center gap-1 text-[10px] font-black text-muted-foreground/50 hover:text-primary uppercase tracking-widest transition-colors px-1.5 py-1 rounded"
    >
      {copied ? <Check className="h-3 w-3 text-primary" /> : <Copy className="h-3 w-3" />}
      {copied ? 'Copied' : 'Copy'}
    </button>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function YouTubeScriptArchitect({ onClose }: Props) {
  const { appUser, refreshBalance } = useUserSession();
  const [topic, setTopic] = useState('');
  const [selectedTone, setSelectedTone] = useState('');
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState<ShockOutput | null>(null);
  const [rawOutput, setRawOutput] = useState('');

  const rawCredits = appUser?.credits ?? 0;
  const credits = formatCredits(appUser?.credits);
  const hasCredits = rawCredits >= TOOL_COST;
  const canGenerate = topic.trim() && selectedTone && hasCredits && !loading;

  const generate = useCallback(async () => {
    if (!topic.trim()) { toast.error('Enter your video topic first.'); return; }
    if (!selectedTone) { toast.error('Select a tone / style.'); return; }
    if (!hasCredits)   { toast.error(`You need ${TOOL_COST} credits to use this tool.`); return; }

    setLoading(true);
    setOutput(null);

    const toneLabel = TONE_OPTIONS.find(t => t.id === selectedTone)?.label ?? selectedTone;

    const prompt = `You are the AlphaTekx YouTube Shock-Factor Script Architect — an elite video strategist who engineers the most psychologically gripping YouTube openings ever written.

Your job is to engineer a 30-second cold open script and 3 viral title formulas for the following video:

Topic: ${topic}
Tone: ${toneLabel}

Output EXACTLY in this format — use these exact headings:

## SHOCK HOOK
Write a single, punchy 1-2 sentence psychological hook. This is the very first thing the viewer hears. It must create immediate tension, mystery, or shock. No "Hey guys". No intro fluff. Start mid-action.

## VIRAL TITLES
Write exactly 3 viral YouTube title formulas for this topic. Use numbers, brackets, power words, and curiosity gaps. Each on its own line starting with a dash.

## OPENING SCRIPT
Write the full 30-second cold open script (approx 80-100 words spoken aloud). Include:
- The hook line (first 5 seconds)
- A "what you don't know" revelation (seconds 5-15)
- A pattern-interrupt that forces them to stay (seconds 15-25)
- A brutal cliffhanger that makes leaving feel impossible (seconds 25-30)

Format as a speaker script. No stage directions. Just the words the creator speaks — conversational, punchy, natural rhythm. Match the ${toneLabel} energy exactly.

## PATTERN BREAK
One single line: a visual or spoken pattern-break technique the creator can use at exactly 0:25 to prevent scroll-away.

Be specific. Be bold. Make this unforgettable.`;

    try {
      const data = await callEdgeFunction<{ reply: string }>('alphatekx-chat', { message: prompt });

      const text: string = data?.reply || '';
      if (!text) throw new Error('No response received. Please try again.');

      setRawOutput(text);
      setOutput(parseOutput(text));

      // Deduct credits after success — non-blocking so a Firestore hiccup never breaks generation
      deductCredits(TOOL_COST)
        .then(d => { if (d.success) refreshBalance(); })
        .catch(e => console.error('Credit deduction failed (non-blocking):', e));

      toast.success('Script architecture generated — 3 credits used.');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Generation failed. Please try again.';
      console.error('[YouTubeScriptArchitect] generate error:', err);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }, [topic, selectedTone, hasCredits, refreshBalance]);

  return (
    <div className="flex flex-col h-full w-full bg-background overflow-hidden">

      {/* ── Header ── */}
      <div className="shrink-0 flex items-center justify-between px-4 md:px-6 py-4 border-b border-border/40">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 border border-primary/20 shrink-0">
            <Flame className="h-5 w-5 text-primary" />
          </div>
          <div className="min-w-0">
            <h2 className="text-base font-black uppercase tracking-tight text-foreground text-balance">
              YouTube Shock-Factor Script Architect
            </h2>
            <p className="text-[11px] text-muted-foreground/50 font-medium uppercase tracking-widest hidden sm:block">
              Built-In System · {TOOL_COST} credits per generation
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-secondary/60 border border-border/50">
            <Zap className="h-3 w-3 text-yellow-400 shrink-0" />
            <span className="text-xs font-black tabular-nums text-foreground">{credits}</span>
            <span className="text-[10px] text-muted-foreground/50 font-bold uppercase tracking-wider">cr</span>
          </div>
          {onClose && (
            <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close"
              className="h-8 w-8 hover:bg-secondary/60 text-muted-foreground hover:text-foreground">
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto min-h-0 custom-scrollbar">
        <div className="max-w-3xl mx-auto px-4 md:px-6 py-6 space-y-6">

          {/* ── Input section ── */}
          <div className="space-y-5">

            {/* Topic input */}
            <div className="space-y-2">
              <label className="text-xs font-black text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <Tv2 className="h-3.5 w-3.5 text-primary" />
                Video Topic
              </label>
              <input
                type="text"
                value={topic}
                onChange={e => setTopic(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && canGenerate) generate(); }}
                placeholder='e.g. "The Secret History of the iPhone" or "Why 90% of African startups fail"'
                className="w-full h-12 px-4 rounded-xl bg-secondary/50 border border-border/60 text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/50 transition-all font-medium"
              />

              {/* Example topics */}
              <div className="flex flex-wrap gap-2 pt-1">
                {EXAMPLE_TOPICS.map(t => (
                  <button
                    key={t}
                    onClick={() => setTopic(t)}
                    className="text-[10px] font-bold text-muted-foreground/50 hover:text-primary bg-secondary/30 hover:bg-primary/10 border border-border/30 hover:border-primary/30 px-2.5 py-1 rounded-full transition-all uppercase tracking-tight"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Tone selector */}
            <div className="space-y-2">
              <label className="text-xs font-black text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <Sparkles className="h-3.5 w-3.5 text-primary" />
                Tone / Style
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5">
                {TONE_OPTIONS.map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => setSelectedTone(opt.id)}
                    className={`flex flex-col gap-1 p-3 rounded-xl border text-left transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 ${
                      selectedTone === opt.id
                        ? 'bg-primary/10 border-primary/50 shadow-[0_0_12px_rgba(var(--primary),0.1)]'
                        : 'bg-secondary/30 border-border/40 hover:bg-secondary/60 hover:border-border/60'
                    }`}
                  >
                    <span className="text-lg leading-none">{opt.emoji}</span>
                    <span className={`text-xs font-black uppercase tracking-tight ${selectedTone === opt.id ? 'text-primary' : 'text-foreground'}`}>
                      {opt.label}
                    </span>
                    <span className="text-[10px] text-muted-foreground/60 font-medium leading-tight text-pretty">
                      {opt.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Credit warning */}
            {!hasCredits && (
              <p className="text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-4 py-3">
                You need at least <strong>{TOOL_COST} credits</strong> to use this tool. Refill from the sidebar.
              </p>
            )}

            {/* Generate button */}
            <Button
              onClick={generate}
              disabled={!canGenerate}
              className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground font-black uppercase tracking-wider text-sm shadow-lg shadow-primary/20 transition-all active:scale-[0.98] disabled:opacity-50"
            >
              {loading
                ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Architecting Your Hook…</>
                : <><Flame className="h-4 w-4 mr-2" />Generate Shock Script — {TOOL_COST} Credits</>}
            </Button>
          </div>

          {/* ── Loading skeleton ── */}
          {loading && (
            <div className="space-y-3 animate-pulse">
              {[80, 120, 200, 60].map((h, i) => (
                <div key={i} className={`rounded-xl bg-secondary/40 border border-border/30`} style={{ height: h }} />
              ))}
            </div>
          )}

          {/* ── Output ── */}
          {output && !loading && (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">

              {/* Shock Hook */}
              <OutputCard
                icon={<Flame className="h-4 w-4 text-primary" />}
                label="Shock Hook"
                badge="0:00 – 0:05"
                copyText={output.hook}
              >
                <p className="text-sm text-foreground font-bold leading-relaxed">
                  "{output.hook}"
                </p>
              </OutputCard>

              {/* Viral Titles */}
              <OutputCard
                icon={<TrendingUp className="h-4 w-4 text-primary" />}
                label="3 Viral Title Formulas"
                badge="High CTR"
                copyText={output.titles.join('\n')}
              >
                <ol className="space-y-2">
                  {output.titles.map((t, i) => (
                    <li key={i} className="flex items-start gap-2.5">
                      <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/10 border border-primary/20 text-[10px] font-black text-primary shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span className="text-sm text-foreground font-semibold leading-snug text-pretty">{t}</span>
                    </li>
                  ))}
                </ol>
              </OutputCard>

              {/* 30-Second Opening Script */}
              <OutputCard
                icon={<Tv2 className="h-4 w-4 text-primary" />}
                label="30-Second Cold Open Script"
                badge="Speak exactly this"
                copyText={output.openingScript}
              >
                <p className="text-sm text-foreground/90 leading-relaxed whitespace-pre-wrap font-medium text-pretty">
                  {output.openingScript}
                </p>
              </OutputCard>

              {/* Pattern Break */}
              {output.patternBreak && (
                <OutputCard
                  icon={<Sparkles className="h-4 w-4 text-primary" />}
                  label="Pattern Break at 0:25"
                  badge="Stop the scroll"
                  copyText={output.patternBreak}
                >
                  <p className="text-sm text-foreground/90 leading-relaxed font-medium italic text-pretty">
                    "{output.patternBreak}"
                  </p>
                </OutputCard>
              )}

              {/* Copy all + Regenerate */}
              <div className="flex items-center justify-between pt-2 pb-4">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(rawOutput);
                    toast.success('Full output copied!');
                  }}
                  className="flex items-center gap-1.5 text-[11px] font-black text-muted-foreground/50 hover:text-primary uppercase tracking-widest transition-colors"
                >
                  <Copy className="h-3.5 w-3.5" />
                  Copy All
                </button>
                <button
                  onClick={generate}
                  disabled={loading || !hasCredits}
                  className="flex items-center gap-1.5 text-[11px] font-black text-muted-foreground/40 hover:text-primary uppercase tracking-widest transition-colors disabled:opacity-30"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  Regenerate ({TOOL_COST} cr)
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

// ─── Reusable output card ─────────────────────────────────────────────────────
function OutputCard({
  icon, label, badge, copyText, children,
}: {
  icon: React.ReactNode;
  label: string;
  badge: string;
  copyText: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border border-border/50 bg-card/60 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/30 bg-secondary/20">
        <div className="flex items-center gap-2">
          {icon}
          <span className="text-xs font-black text-foreground uppercase tracking-tight">{label}</span>
          <span className="text-[9px] font-black text-muted-foreground/40 bg-secondary/60 px-2 py-0.5 rounded-full border border-border/30 uppercase tracking-widest">
            {badge}
          </span>
        </div>
        <CopyBtn text={copyText} />
      </div>
      <div className="px-4 py-4">
        {children}
      </div>
    </div>
  );
}
