import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { deductCredits, formatCredits } from '@/lib/credits';
import { useUserSession } from '@/contexts/UserSessionContext';
import { callEdgeFunction } from '@/lib/edgeFunction';
import {
  BriefcaseBusiness, Loader2, Copy, Check, RefreshCw,
  ChevronDown, ChevronUp, Sparkles, X, Zap,
} from 'lucide-react';

const TOOL_COST = 3;

interface Section {
  title: string;
  content: string;
}

function parseBusinessPlan(raw: string): Section[] {
  // Split on markdown ## headings
  const parts = raw.split(/\n(?=##\s)/);
  return parts
    .map(p => {
      const lines = p.trim().split('\n');
      const heading = lines[0].replace(/^#+\s*/, '').trim();
      const body = lines.slice(1).join('\n').trim();
      return { title: heading, content: body };
    })
    .filter(s => s.title && s.content);
}

interface BusinessPlanGeneratorProps {
  onClose?: () => void;
}

export default function BusinessPlanGenerator({ onClose }: BusinessPlanGeneratorProps) {
  const { appUser, refreshBalance } = useUserSession();
  const rawCredits = appUser?.credits ?? 0;
  const credits = formatCredits(appUser?.credits);
  const hasCredits = rawCredits >= TOOL_COST;

  const [form, setForm] = useState({
    businessName: '',
    industry: '',
    description: '',
    targetMarket: '',
    revenueModel: '',
    startupBudget: '',
    location: '',
  });
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<Section[]>([]);
  const [rawPlan, setRawPlan] = useState('');
  const [openSections, setOpenSections] = useState<Record<number, boolean>>({});
  const [copied, setCopied] = useState(false);

  function update(field: keyof typeof form, value: string) {
    setForm(prev => ({ ...prev, [field]: value }));
  }

  function toggleSection(idx: number) {
    setOpenSections(prev => ({ ...prev, [idx]: !prev[idx] }));
  }

  async function generate() {
    const required = ['businessName', 'industry', 'description', 'targetMarket'] as const;
    for (const key of required) {
      if (!form[key].trim()) {
        toast.error(`Please fill in: ${key.replace(/([A-Z])/g, ' $1').toLowerCase()}`);
        return;
      }
    }

    if (!hasCredits) {
      toast.error(`You need ${TOOL_COST} credits to generate a business plan.`);
      return;
    }

    setLoading(true);
    setPlan([]);
    setRawPlan('');

    const prompt = `You are an elite business strategist and MBA consultant. Generate a comprehensive, professional business plan for the following business.

Business Details:
- Business Name: ${form.businessName}
- Industry: ${form.industry}
- Description: ${form.description}
- Target Market: ${form.targetMarket}
- Revenue Model: ${form.revenueModel || 'To be determined'}
- Startup Budget: ${form.startupBudget || 'Not specified'}
- Location/Market: ${form.location || 'Global/Online'}

Generate a complete business plan with the following sections using markdown headings:

## Executive Summary
## Problem and Opportunity
## Solution and Value Proposition
## Target Market and Customer Segments
## Business Model and Revenue Streams
## Competitive Analysis
## Marketing and Growth Strategy
## Operations Plan
## Financial Projections and Milestones
## Risk Analysis and Mitigation
## Team Requirements
## Funding Requirements and Use of Funds

Be specific, actionable, and professional. Include realistic numbers and timelines.`;

    try {
      const data = await callEdgeFunction<{ reply: string }>('alphatekx-chat', { message: prompt });

      const text: string = data?.reply || '';
      if (!text) throw new Error('No response received. Please try again.');

      setRawPlan(text);
      const sections = parseBusinessPlan(text);
      if (sections.length === 0) {
        setPlan([{ title: 'Business Plan', content: text }]);
        setOpenSections({ 0: true });
      } else {
        setPlan(sections);
        const allOpen: Record<number, boolean> = {};
        sections.forEach((_, i) => { allOpen[i] = true; });
        setOpenSections(allOpen);
      }

      // Deduct credits after success — non-blocking so a Firestore hiccup never breaks generation
      deductCredits(TOOL_COST)
        .then(d => { if (d.success) refreshBalance(); })
        .catch(e => console.error('Credit deduction failed (non-blocking):', e));

      toast.success('Business plan generated successfully!');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Generation failed. Please try again.';
      console.error('[BusinessPlanGenerator] generate error:', err);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }

  async function copyAll() {
    await navigator.clipboard.writeText(rawPlan);
    setCopied(true);
    toast.success('Business plan copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  }

  const isReady = form.businessName && form.industry && form.description && form.targetMarket;

  return (
    <div className="flex flex-col h-full w-full bg-background overflow-hidden">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 md:px-6 py-4 border-b border-border/40 bg-background">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 border border-primary/20 shrink-0">
            <BriefcaseBusiness className="h-5 w-5 text-primary" />
          </div>
          <div className="min-w-0">
            <h2 className="text-base font-black uppercase tracking-tight text-foreground text-balance">
              AI Business Plan Generator
            </h2>
            <p className="text-[11px] text-muted-foreground/50 font-medium uppercase tracking-widest hidden sm:block">
              Built-In System · AlphaTekx OS
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {plan.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={copyAll}
              className="h-8 gap-1.5 text-xs font-bold text-muted-foreground hover:text-foreground"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-primary" /> : <Copy className="h-3.5 w-3.5" />}
              <span className="hidden sm:inline">{copied ? 'Copied' : 'Copy All'}</span>
            </Button>
          )}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-secondary/60 border border-border/50">
            <Zap className="h-3 w-3 text-yellow-400 shrink-0" />
            <span className="text-xs font-black tabular-nums text-foreground">{credits}</span>
            <span className="text-[10px] text-muted-foreground/50 font-bold uppercase tracking-wider">cr</span>
          </div>
          {onClose && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              aria-label="Close"
              className="h-8 w-8 hover:bg-secondary/60 text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto min-h-0 custom-scrollbar">
        <div className="max-w-4xl mx-auto px-4 md:px-6 py-6 space-y-6">

          {/* Input form */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-4 w-4 text-primary shrink-0" />
              <h3 className="text-sm font-black uppercase tracking-tight text-foreground">
                Tell us about your business
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <InputField
                label="Business Name *"
                placeholder="e.g. NovaTech Solutions"
                value={form.businessName}
                onChange={v => update('businessName', v)}
              />
              <InputField
                label="Industry *"
                placeholder="e.g. FinTech, E-Commerce, SaaS"
                value={form.industry}
                onChange={v => update('industry', v)}
              />
            </div>

            <TextareaField
              label="Business Description *"
              placeholder="Describe what your business does, the product or service you offer, and the core problem you solve..."
              value={form.description}
              onChange={v => update('description', v)}
              rows={3}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <InputField
                label="Target Market *"
                placeholder="e.g. Small businesses in Africa aged 25-45"
                value={form.targetMarket}
                onChange={v => update('targetMarket', v)}
              />
              <InputField
                label="Revenue Model"
                placeholder="e.g. Subscription, Commission, One-time sale"
                value={form.revenueModel}
                onChange={v => update('revenueModel', v)}
              />
              <InputField
                label="Startup Budget"
                placeholder="e.g. $5,000 / $50,000 / Bootstrap"
                value={form.startupBudget}
                onChange={v => update('startupBudget', v)}
              />
              <InputField
                label="Location / Market"
                placeholder="e.g. Nigeria, Global, East Africa"
                value={form.location}
                onChange={v => update('location', v)}
              />
            </div>

            {/* Credit warning */}
            {!hasCredits && (
              <p className="text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-4 py-3">
                You need at least <strong>{TOOL_COST} credits</strong> to generate a business plan. Refill from the sidebar.
              </p>
            )}

            <Button
              onClick={generate}
              disabled={loading || !isReady || !hasCredits}
              className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground font-black uppercase tracking-wider text-sm shadow-lg shadow-primary/20 transition-all active:scale-[0.98] disabled:opacity-50"
            >
              {loading
                ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Generating Your Business Plan…</>
                : <><Sparkles className="h-4 w-4 mr-2" />Generate Business Plan — {TOOL_COST} Credits</>}
            </Button>
          </div>

          {/* Loading skeleton */}
          {loading && (
            <div className="space-y-3 animate-pulse">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-14 rounded-xl bg-secondary/40 border border-border/30" />
              ))}
            </div>
          )}

          {/* Generated plan accordion */}
          {plan.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-sm font-black uppercase tracking-tight text-foreground flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-primary inline-block" />
                  Business Plan — {form.businessName}
                </h3>
                <button
                  onClick={() => {
                    const allOpen = plan.every((_, i) => openSections[i]);
                    const next: Record<number, boolean> = {};
                    plan.forEach((_, i) => { next[i] = !allOpen; });
                    setOpenSections(next);
                  }}
                  className="text-[10px] font-black text-muted-foreground/50 hover:text-primary uppercase tracking-widest transition-colors"
                >
                  {plan.every((_, i) => openSections[i]) ? 'Collapse All' : 'Expand All'}
                </button>
              </div>

              {plan.map((section, idx) => (
                <div
                  key={idx}
                  className="rounded-xl border border-border/40 bg-card/50 overflow-hidden transition-all duration-200"
                >
                  <button
                    onClick={() => toggleSection(idx)}
                    className="w-full flex items-center justify-between px-4 py-3.5 hover:bg-secondary/40 transition-colors text-left gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="text-[10px] font-black text-primary/50 tabular-nums shrink-0 w-5 text-center">
                        {String(idx + 1).padStart(2, '0')}
                      </span>
                      <span className="text-sm font-black text-foreground uppercase tracking-tight truncate">
                        {section.title}
                      </span>
                    </div>
                    {openSections[idx]
                      ? <ChevronUp className="h-4 w-4 text-muted-foreground/50 shrink-0" />
                      : <ChevronDown className="h-4 w-4 text-muted-foreground/50 shrink-0" />}
                  </button>

                  {openSections[idx] && (
                    <div className="px-5 pb-5 pt-1 border-t border-border/30">
                      <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap text-pretty">
                        {section.content}
                      </p>
                    </div>
                  )}
                </div>
              ))}

              <div className="flex items-center justify-between pt-2 pb-4">
                <p className="text-[10px] text-muted-foreground/30 uppercase tracking-widest font-bold">
                  AlphaTekx Business Intelligence · {TOOL_COST} credits used
                </p>
                <button
                  onClick={generate}
                  disabled={loading || !hasCredits}
                  className="flex items-center gap-1.5 text-[10px] font-black text-muted-foreground/40 hover:text-primary uppercase tracking-widest transition-colors disabled:opacity-30"
                >
                  <RefreshCw className="h-3 w-3" />
                  Regenerate ({TOOL_COST} cr)
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

/* ── Small reusable input components ── */
function InputField({
  label, placeholder, value, onChange,
}: { label: string; placeholder: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">{label}</label>
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
        className="w-full h-11 px-3 rounded-xl bg-secondary/50 border border-border/60 text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/50 transition-all font-medium"
      />
    </div>
  );
}

function TextareaField({
  label, placeholder, value, onChange, rows = 3,
}: { label: string; placeholder: string; value: string; onChange: (v: string) => void; rows?: number }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">{label}</label>
      <textarea
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(e.target.value)}
        rows={rows}
        className="w-full px-3 py-3 rounded-xl bg-secondary/50 border border-border/60 text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/50 transition-all resize-none font-medium leading-relaxed"
      />
    </div>
  );
}
