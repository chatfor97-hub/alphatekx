import { useState } from 'react';
import { Zap, Rocket, Star, ShieldCheck, Loader2, X, Lock, CheckCircle2, ExternalLink } from 'lucide-react';
import { auth } from '@/lib/firebase';
import { useUserSession } from '@/contexts/UserSessionContext';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';

// ── Credit packs — Exchange rate: $1 USD = ₦1,373.42 (flat market rate) ────────
// amountNgn and amountKobo MUST stay in sync with CREDIT_PACKS in all Edge Functions.
//
//  Tier 1  $1  →  ₦1,373.42  →      137,342 kobo  →    50 credits
//  Tier 2  $5  →  ₦6,867.10  →      686,710 kobo  →   300 credits
//  Tier 3  $10 →  ₦13,734.20 →    1,373,420 kobo  →   700 credits
//  Tier 4  $50 →  ₦68,671.00 →    6,867,100 kobo  → 3,500 credits
interface CreditPack {
  id: 'starter' | 'popular' | 'pro' | 'elite';
  label: string;
  subtitle: string;
  usd: number;         // USD face value shown as reference
  amountNgn: number;   // exact NGN amount (kobo / 100)
  amountKobo: number;  // hardcoded kobo integer — sent to Paystack
  credits: number;
  perks: string[];
  icon: React.FC<{ className?: string }>;
  highlight: boolean;
  badge?: string;
  gradientFrom: string;
  gradientTo: string;
  iconBg: string;
  iconColor: string;
}

const PACKS: CreditPack[] = [
  {
    id:           'starter',
    label:        'Starter',
    subtitle:     'Perfect to get started',
    usd:          1,
    amountNgn:    1_373.42,
    amountKobo:   137_342,
    credits:      50,
    perks:        ['50 AI credits', 'All tools unlocked', 'Valid forever'],
    icon:         Star,
    highlight:    false,
    gradientFrom: 'from-slate-800/80',
    gradientTo:   'to-slate-900/80',
    iconBg:       'bg-slate-700/60',
    iconColor:    'text-slate-300',
  },
  {
    id:           'popular',
    label:        'Popular',
    subtitle:     'Best value for most users',
    usd:          5,
    amountNgn:    6_867.10,
    amountKobo:   686_710,
    credits:      300,
    perks:        ['300 AI credits', 'All tools unlocked', 'Priority support', 'Valid forever'],
    icon:         Rocket,
    highlight:    true,
    badge:        '⭐ Most Popular',
    gradientFrom: 'from-primary/20',
    gradientTo:   'to-primary/5',
    iconBg:       'bg-primary/25',
    iconColor:    'text-primary',
  },
  {
    id:           'pro',
    label:        'Pro',
    subtitle:     'For power users',
    usd:          10,
    amountNgn:    13_734.20,
    amountKobo:   1_373_420,
    credits:      700,
    perks:        ['700 AI credits', 'All tools unlocked', 'Priority support', 'Valid forever'],
    icon:         ShieldCheck,
    highlight:    false,
    gradientFrom: 'from-violet-900/40',
    gradientTo:   'to-violet-950/40',
    iconBg:       'bg-violet-500/20',
    iconColor:    'text-violet-400',
  },
  {
    id:           'elite',
    label:        'Elite',
    subtitle:     'Maximum power — best per-credit rate',
    usd:          50,
    amountNgn:    68_671.00,
    amountKobo:   6_867_100,
    credits:      3_500,
    perks:        ['3,500 AI credits', 'All tools unlocked', 'Priority support', 'Best value per credit', 'Valid forever'],
    icon:         Zap,
    highlight:    false,
    badge:        '🔥 Best Value',
    gradientFrom: 'from-amber-900/40',
    gradientTo:   'to-yellow-950/40',
    iconBg:       'bg-amber-500/20',
    iconColor:    'text-amber-400',
  },
];

// ── Component ─────────────────────────────────────────────────────────────────
interface ModalProps {
  onClose?: () => void;
}

export default function CreditsExhaustedModal({ onClose }: ModalProps = {}) {
  const { appUser } = useUserSession();
  const [dismissed,   setDismissed]   = useState(false);
  const [loadingPack, setLoadingPack] = useState<string | null>(null);

  if (!onClose && dismissed) return null;

  function handleClose() {
    if (onClose) onClose();
    else setDismissed(true);
  }

  async function handlePurchase(pack: CreditPack) {
    if (loadingPack) return;

    const firebaseUser = auth.currentUser;
    if (!firebaseUser || !appUser) {
      toast.error('Please sign in to purchase credits.');
      return;
    }

    const email = firebaseUser.email ?? appUser.email ?? '';
    if (!email) {
      toast.error('No email address found on your account. Please update your profile.');
      return;
    }

    setLoadingPack(pack.id);

    try {
      // Build the callback URL — Paystack will redirect here after payment
      const callbackUrl = `${window.location.origin}/payment/callback`;

      const { data, error } = await supabase.functions.invoke('initialize-paystack', {
        body: {
          email,
          packId:      pack.id,
          firebaseUid: firebaseUser.uid,
          callbackUrl,
        },
      });

      if (error || data?.code !== 'SUCCESS') {
        const msg = error ? await error.context?.text?.() : data?.message;
        throw new Error(msg || 'Could not initialize payment');
      }

      const { authorization_url } = data.data as { authorization_url: string };

      if (!authorization_url) {
        throw new Error('Paystack did not return a payment URL.');
      }

      // ── Redirect to Paystack hosted checkout ─────────────────────────────
      // Using location.href so the same tab navigates — avoids popup blockers.
      window.location.href = authorization_url;

    } catch (err) {
      console.error('Paystack initialize error:', err);
      const msg = err instanceof Error ? err.message : 'Unexpected error';
      toast.error(`Could not open payment: ${msg}`);
      setLoadingPack(null);
    }
    // Note: setLoadingPack(null) is intentionally NOT called on success
    // because we are navigating away — keeping the spinner shows the user something happened.
  }

  // ── Pack card ──────────────────────────────────────────────────────────────
  function PackCard({ pack }: { pack: CreditPack }) {
    const Icon       = pack.icon;
    const isLoading  = loadingPack === pack.id;
    const anyLoading = !!loadingPack;
    // Cost per credit: e.g. ₦1,373.42 / 50 = ₦27.47/credit
    const rateNgn    = (pack.amountNgn / pack.credits).toFixed(2);
    // Display price with decimals: ₦1,373.42 / ₦6,867.10 / ₦13,734.20
    const displayPrice = `₦${pack.amountNgn.toLocaleString('en-NG', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;

    return (
      <div
        className={`relative w-full rounded-2xl border overflow-hidden
          bg-gradient-to-br ${pack.gradientFrom} ${pack.gradientTo}
          ${pack.highlight
            ? 'border-primary/50 shadow-[0_0_32px_hsl(var(--primary)/0.25)]'
            : 'border-white/10'
          }`}
      >
        {pack.badge && (
          <div className="w-full bg-primary text-primary-foreground text-[11px] font-bold uppercase tracking-widest text-center py-1.5">
            {pack.badge}
          </div>
        )}

        <div className="p-5 flex flex-col gap-4">
          {/* Top row: icon + name + price */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${pack.iconBg}`}>
                <Icon className={`h-5 w-5 ${pack.iconColor}`} />
              </div>
              <div className="min-w-0">
                <p className="text-base font-black text-foreground leading-tight">{pack.label}</p>
                <p className="text-xs text-muted-foreground truncate">{pack.subtitle}</p>
              </div>
            </div>
            <div className="shrink-0 flex flex-col items-end">
              <span className="text-3xl font-black text-foreground leading-none">{displayPrice}</span>
              <span className="text-[10px] text-muted-foreground uppercase tracking-wide">NGN · ~${pack.usd} USD</span>
            </div>
          </div>

          {/* Credits + rate bar */}
          <div className="flex items-center justify-between rounded-xl bg-black/20 border border-white/5 px-4 py-2.5">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-yellow-400 shrink-0" />
              <span className="text-sm font-black text-foreground">{pack.credits.toLocaleString()}</span>
              <span className="text-xs text-muted-foreground">credits</span>
            </div>
            <span className="text-[11px] text-muted-foreground">₦{rateNgn}/credit</span>
          </div>

          {/* Perks list */}
          <ul className="space-y-1.5">
            {pack.perks.map((perk) => (
              <li key={perk} className="flex items-center gap-2">
                <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-green-400" />
                <span className="text-xs text-foreground/80">{perk}</span>
              </li>
            ))}
          </ul>

          {/* Pay button */}
          <button
            disabled={anyLoading}
            onClick={() => handlePurchase(pack)}
            className={`w-full flex items-center justify-center gap-2 h-14 rounded-xl text-sm font-black tracking-wide transition-all duration-200
              disabled:opacity-50 disabled:cursor-not-allowed
              ${pack.highlight
                ? 'bg-primary text-primary-foreground hover:bg-primary/90 active:scale-[0.98] shadow-[0_4px_20px_hsl(var(--primary)/0.4)]'
                : 'bg-secondary hover:bg-secondary/80 active:scale-[0.98] border border-border/60 text-foreground'
              }`}
          >
            {isLoading ? (
              <><Loader2 className="h-4 w-4 animate-spin" />Opening Paystack…</>
            ) : (
              <><Lock className="h-4 w-4 shrink-0" />Pay {displayPrice} securely <ExternalLink className="h-3.5 w-3.5 opacity-60" /></>
            )}
          </button>
        </div>
      </div>
    );
  }

  // ── Inner content ──────────────────────────────────────────────────────────
  const inner = (
    <div className="flex flex-col gap-5">
      {/* Header */}
      <div className="text-center space-y-3 px-1">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-[2rem] bg-background border border-border/60 shadow-[0_0_30px_rgba(var(--primary),0.1)]">
          <Zap className="h-8 w-8 text-primary" />
        </div>
        <div className="space-y-1">
          <h2 className="text-2xl font-black tracking-tighter text-foreground uppercase">
            {onClose ? 'Refill Credits' : 'Access Restricted'}
          </h2>
          <p className="text-[10px] text-muted-foreground/60 font-bold uppercase tracking-[0.2em]">
            Neural Network Power Reserve Low
          </p>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed max-w-[30ch] mx-auto font-medium">
          {onClose
            ? 'Select a high-performance credit package to extend your operational capacity.'
            : "Your credit reserve is depleted. Upgrade your access tier to continue."}
        </p>
      </div>

      {/* Pack cards */}
      <div className="flex flex-col gap-3">
        {PACKS.map((pack) => <PackCard key={pack.id} pack={pack} />)}
      </div>

      {/* Security footer */}
      <div className="flex items-center justify-center gap-2 pt-1">
        <Lock className="h-3 w-3 text-muted-foreground/50 shrink-0" />
        <p className="text-[11px] text-muted-foreground/50 text-center leading-relaxed">
          Secured by Paystack · NGN · Rate: $1 = ₦1,373.42 · No subscription
        </p>
      </div>
    </div>
  );

  // ── Embedded mode ──────────────────────────────────────────────────────────
  if (onClose) {
    return (
      <div className="w-full animate-in fade-in slide-in-from-bottom-4 duration-300 bg-card rounded-2xl border border-white/10 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 pt-4 pb-0">
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground/60">Credits Store</span>
          <button
            onClick={handleClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary/60 border border-white/10 text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="p-5 pt-3">{inner}</div>
      </div>
    );
  }

  // ── Full-screen (credits hit 0) ─────────────────────────────────────────────
  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center md:p-4 bg-background/80 backdrop-blur-md">
      <div className="w-full md:max-w-md animate-in fade-in slide-in-from-bottom-8 md:slide-in-from-bottom-0 md:zoom-in-95 duration-300 bg-card md:rounded-2xl rounded-t-3xl border border-white/10 shadow-2xl max-h-[92dvh] overflow-y-auto">

        <div className="flex justify-center pt-3 pb-1 md:hidden">
          <div className="w-10 h-1 rounded-full bg-white/20" />
        </div>

        <div className="flex items-center justify-between px-5 pt-3 pb-0 md:pt-5">
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground/60">Credits Store</span>
          <button
            onClick={handleClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary/60 border border-white/10 text-muted-foreground hover:text-foreground hover:bg-secondary active:scale-95 transition-all"
            aria-label="Close and return to chat"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5 pt-3">{inner}</div>
      </div>
    </div>
  );
}


