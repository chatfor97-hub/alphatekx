import { useState, useRef, useEffect, useCallback } from 'react';
import { Mic, MicOff, Volume2, X, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface VoiceChatProps {
  onClose: () => void;
}

type VoiceState = 'idle' | 'recording' | 'processing' | 'speaking';

interface VoiceMessage {
  role: 'user' | 'assistant';
  content: string;
}

const SUPABASE_URL  = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
const BAR_COUNT = 24;

// System prompt for voice session — concise answers optimised for TTS
const VOICE_SYSTEM =
  'You are AlphaTekx OS, an elite AI Operating System built by Thompson Daniel. ' +
  'You are in VOICE mode. Keep answers clear, natural, and concise (2–4 sentences max) ' +
  'since they will be spoken aloud. No markdown, no bullet points, no code blocks. ' +
  'Speak like a brilliant colleague — confident, direct, helpful.';

export default function VoiceChat({ onClose }: VoiceChatProps) {
  const [state, setState] = useState<VoiceState>('idle');

  // In-memory voice conversation history — never touches the text chat
  const voiceHistoryRef = useRef<VoiceMessage[]>([]);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef        = useRef<Blob[]>([]);
  const streamRef        = useRef<MediaStream | null>(null);
  const audioRef         = useRef<HTMLAudioElement | null>(null);
  const audioBlobUrlRef  = useRef<string | null>(null);
  const abortRef         = useRef<AbortController | null>(null);

  useEffect(() => () => {
    stopStream();
    stopAudio();
    abortRef.current?.abort();
  }, []);

  function stopStream() {
    streamRef.current?.getTracks().forEach(t => t.stop());
    streamRef.current = null;
  }

  function stopAudio() {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
      audioRef.current = null;
    }
    if (audioBlobUrlRef.current) {
      URL.revokeObjectURL(audioBlobUrlRef.current);
      audioBlobUrlRef.current = null;
    }
  }

  async function startRecording() {
    try {
      stopAudio();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mimeType = getSupportedMimeType();
      const recorder  = new MediaRecorder(stream, { mimeType });
      chunksRef.current = [];
      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      recorder.onstop = handleRecordingStop;
      mediaRecorderRef.current = recorder;
      recorder.start();
      setState('recording');
    } catch {
      toast.error('Microphone access denied.');
    }
  }

  function stopRecording() {
    if (mediaRecorderRef.current?.state === 'recording') {
      mediaRecorderRef.current.stop();
      stopStream();
      setState('processing');
    }
  }

  // ── Transcribe → AI → TTS pipeline (all silent, no text in chat) ──────────
  const handleRecordingStop = useCallback(async () => {
    const mimeType = getSupportedMimeType();
    const blob = new Blob(chunksRef.current, { type: mimeType });
    if (blob.size < 800) {
      setState('idle');
      toast.error('Too short — try again.');
      return;
    }

    try {
      // Step 1: Whisper transcription (silent)
      const formData = new FormData();
      formData.append('file', blob, `audio.${mimeType2ext(mimeType)}`);

      const txRes = await fetch(`${SUPABASE_URL}/functions/v1/voice-transcribe`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${SUPABASE_ANON}` },
        body: formData,
      });

      if (!txRes.ok) throw new Error('Transcription failed');
      const { text } = await txRes.json();
      if (!text?.trim()) throw new Error('no-speech');

      const userText = text.trim();
      voiceHistoryRef.current.push({ role: 'user', content: userText });

      // Step 2: AI response (streamed, collected to string)
      abortRef.current = new AbortController();
      const historyMsgs = voiceHistoryRef.current.slice(-10).map(m => ({
        role: m.role, content: m.content,
      }));

      const aiRes = await fetch(`${SUPABASE_URL}/functions/v1/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${SUPABASE_ANON}`,
        },
        body: JSON.stringify({
          prompt: userText,
          history: historyMsgs.slice(0, -1), // exclude the just-added user turn
          voiceMode: true,                    // hint to edge fn for brevity (optional)
        }),
        signal: abortRef.current.signal,
      });

      if (!aiRes.ok || !aiRes.body) throw new Error('AI response failed');

      const reader  = aiRes.body.getReader();
      const decoder = new TextDecoder();
      let aiText    = '';
      let done      = false;

      while (!done) {
        const { value, done: d } = await reader.read();
        done = d;
        if (!value) continue;
        const chunk = decoder.decode(value);
        for (const line of chunk.split('\n')) {
          if (!line.startsWith('data: ')) continue;
          const js = line.slice(6).trim();
          if (!js || js === '[DONE]') continue;
          try {
            const j = JSON.parse(js);
            if (j.action) continue; // skip tool actions in voice mode
            aiText += j.choices?.[0]?.delta?.content ?? '';
          } catch { /* */ }
        }
      }

      if (!aiText.trim()) throw new Error('Empty AI response');
      voiceHistoryRef.current.push({ role: 'assistant', content: aiText.trim() });

      // Step 3: TTS playback
      await speakText(aiText.trim());

    } catch (e) {
      const msg = (e as Error).message;
      setState('idle');
      if (msg === 'no-speech') toast.error('No speech detected — try again.');
      else if (msg !== 'AbortError') toast.error('Voice error — try again.');
    }
  }, []);

  async function speakText(text: string) {
    setState('processing');
    try {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/voice-speak`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${SUPABASE_ANON}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text, voice: 'nova' }),
      });

      if (!res.ok) {
        console.error('[voice-speak]', res.status, await res.text());
        throw new Error('TTS failed');
      }

      const url = URL.createObjectURL(await res.blob());
      audioBlobUrlRef.current = url;
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onplay  = () => setState('speaking');
      audio.onended = () => { setState('idle'); stopAudio(); };
      audio.onerror = () => { setState('idle'); toast.error('Audio playback failed.'); };
      await audio.play();
    } catch (err) {
      console.error('[speakText]', err);
      setState('idle');
    }
  }

  function handleMicClick() {
    if (state === 'idle')           startRecording();
    else if (state === 'recording') stopRecording();
    else if (state === 'speaking')  { stopAudio(); setState('idle'); }
  }

  function handleClose() {
    stopRecording();
    stopAudio();
    abortRef.current?.abort();
    voiceHistoryRef.current = [];
    onClose();
  }

  function getSupportedMimeType() {
    return (
      ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4']
        .find(t => MediaRecorder.isTypeSupported(t)) ?? 'audio/webm'
    );
  }

  function mimeType2ext(m: string) {
    if (m.includes('webm')) return 'webm';
    if (m.includes('ogg'))  return 'ogg';
    return 'm4a';
  }

  const isWaveActive = state === 'recording' || state === 'speaking';
  const isProcessing = state === 'processing';

  const statusLabel =
    state === 'recording' ? 'Listening…'  :
    isProcessing          ? 'Thinking…'   :
    state === 'speaking'  ? 'Speaking…'   :
    /* idle */              'Tap to speak';

  // Intentionally unused — voice system prompt is a constant for the edge fn
  void VOICE_SYSTEM;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-lg">
      <div className="relative flex flex-col items-center gap-10 w-full max-w-xs px-6 py-14">

        {/* Close */}
        <button
          onClick={handleClose}
          className="absolute top-2 right-4 p-2 rounded-full text-white/30 hover:text-white/80 transition-colors"
          aria-label="Close voice chat"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Title */}
        <div className="flex flex-col items-center gap-1.5">
          <p className="text-xs font-bold text-primary/70 uppercase tracking-[0.2em]">Voice Mode</p>
          <p className="text-[11px] text-white/25 tracking-wide">AlphaTekx is listening</p>
        </div>

        {/* Waveform bars */}
        <div className="flex items-end justify-center gap-[3px] h-14">
          {Array.from({ length: BAR_COUNT }).map((_, i) => (
            <div
              key={i}
              className={`rounded-full transition-colors ${isWaveActive ? 'bg-primary' : 'bg-white/15'}`}
              style={{
                width: '3px',
                animation: isWaveActive
                  ? `voiceBar ${0.35 + (i % 6) * 0.07}s ease-in-out ${i * 0.025}s infinite alternate`
                  : 'none',
                height: isWaveActive ? undefined : '4px',
              }}
            />
          ))}
        </div>

        {/* Mic / status button */}
        <button
          onClick={handleMicClick}
          disabled={isProcessing}
          className={`relative flex h-28 w-28 items-center justify-center rounded-full transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed ${
            state === 'recording'
              ? 'bg-red-500/15 border-2 border-red-500 shadow-[0_0_48px_rgba(239,68,68,0.55)]'
              : state === 'speaking'
              ? 'bg-primary/15 border-2 border-primary shadow-[0_0_48px_hsl(var(--primary)/0.55)]'
              : 'bg-white/5 border-2 border-white/20 hover:border-primary/60 hover:bg-primary/10 hover:shadow-[0_0_32px_hsl(var(--primary)/0.3)]'
          }`}
        >
          {isProcessing ? (
            <Loader2 className="h-10 w-10 text-primary animate-spin" />
          ) : state === 'recording' ? (
            <MicOff className="h-10 w-10 text-red-400" />
          ) : state === 'speaking' ? (
            <Volume2 className="h-10 w-10 text-primary" />
          ) : (
            <Mic className="h-10 w-10 text-white/60" />
          )}

          {/* Pulse rings — recording */}
          {state === 'recording' && (
            <>
              <span className="absolute -inset-2 rounded-full border border-red-500/35 animate-ping" />
              <span className="absolute -inset-5 rounded-full border border-red-500/15 animate-ping [animation-delay:0.25s]" />
            </>
          )}
          {/* Pulse rings — speaking */}
          {state === 'speaking' && (
            <>
              <span className="absolute -inset-2 rounded-full border border-primary/35 animate-ping" />
              <span className="absolute -inset-5 rounded-full border border-primary/15 animate-ping [animation-delay:0.25s]" />
            </>
          )}
        </button>

        {/* Status label */}
        <p className="text-sm font-medium text-white/40 tracking-widest uppercase text-center">
          {statusLabel}
        </p>

        {/* Hint */}
        {state === 'idle' && (
          <p className="text-[11px] text-white/20 text-center leading-relaxed max-w-[200px]">
            Your conversation stays private — nothing appears in the chat
          </p>
        )}
      </div>

      <style>{`
        @keyframes voiceBar {
          from { height: 3px;  }
          to   { height: 44px; }
        }
      `}</style>
    </div>
  );
}
