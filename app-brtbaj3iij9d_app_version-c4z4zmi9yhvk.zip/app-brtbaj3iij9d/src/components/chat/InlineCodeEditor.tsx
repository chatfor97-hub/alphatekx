import { useState, useRef } from 'react';
import { Copy, Check, Play, Code2, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';

export interface CodeBlock {
  language: string;
  code: string;
}

interface InlineCodeEditorProps {
  blocks: CodeBlock[];
}

const LANG_LABELS: Record<string, string> = {
  html: 'HTML',
  css: 'CSS',
  js: 'JavaScript',
  javascript: 'JavaScript',
  jsx: 'JSX',
  ts: 'TypeScript',
  typescript: 'TypeScript',
  tsx: 'TSX',
  python: 'Python',
  py: 'Python',
  bash: 'Bash',
  sh: 'Shell',
  json: 'JSON',
  sql: 'SQL',
  md: 'Markdown',
  markdown: 'Markdown',
};

function normalizeLanguage(lang: string): string {
  return lang.toLowerCase().trim();
}

function buildPreviewSrc(blocks: CodeBlock[]): string {
  const html  = blocks.find(b => ['html'].includes(normalizeLanguage(b.language)))?.code ?? '';
  const css   = blocks.find(b => normalizeLanguage(b.language) === 'css')?.code ?? '';
  const jsLangs = ['js', 'javascript', 'jsx'];
  const js    = blocks.find(b => jsLangs.includes(normalizeLanguage(b.language)))?.code ?? '';

  if (html) {
    // Inject CSS and JS into the HTML document
    let doc = html;
    if (css) {
      doc = doc.includes('</head>')
        ? doc.replace('</head>', `<style>${css}</style></head>`)
        : `<style>${css}</style>${doc}`;
    }
    if (js) {
      doc = doc.includes('</body>')
        ? doc.replace('</body>', `<script>${js}</script></body>`)
        : `${doc}<script>${js}</script>`;
    }
    return doc;
  }

  // No HTML — build a minimal wrapper
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    body { font-family: system-ui, sans-serif; background:#0a0e1a; color:#e2e8f0; padding:16px; margin:0; }
    ${css}
  </style></head><body>${js ? `<script>${js}</script>` : ''}</body></html>`;
}

// Simple syntax colouriser (no external deps)
function highlight(code: string, lang: string): string {
  const escaped = code
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  const n = normalizeLanguage(lang);

  if (['html'].includes(n)) {
    return escaped
      .replace(/(&lt;\/?)([\w-]+)/g, '<span class="ch-tag">$1$2</span>')
      .replace(/([\w-]+)=/g, '<span class="ch-attr">$1</span>=')
      .replace(/(&quot;|&#39;)(.*?)(\1)/g, '<span class="ch-str">$1$2$3</span>');
  }

  if (['css'].includes(n)) {
    return escaped
      .replace(/([\w-]+)\s*:/g, '<span class="ch-prop">$1</span>:')
      .replace(/\/\*[\s\S]*?\*\//g, m => `<span class="ch-comment">${m}</span>`);
  }

  if (['js', 'javascript', 'jsx', 'ts', 'typescript', 'tsx'].includes(n)) {
    return escaped
      .replace(/\b(const|let|var|function|return|if|else|for|while|class|import|export|from|default|async|await|new|typeof|instanceof|null|undefined|true|false)\b/g,
        '<span class="ch-kw">$1</span>')
      .replace(/(["'`])((?:\\.|(?!\1)[\s\S])*?)\1/g, '<span class="ch-str">$1$2$1</span>')
      .replace(/\/\/.*/g, m => `<span class="ch-comment">${m}</span>`)
      .replace(/\/\*[\s\S]*?\*\//g, m => `<span class="ch-comment">${m}</span>`);
  }

  return escaped;
}

export default function InlineCodeEditor({ blocks }: InlineCodeEditorProps) {
  const [activeIdx, setActiveIdx] = useState(0);
  const [editedBlocks, setEditedBlocks] = useState<CodeBlock[]>(blocks);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewSrc, setPreviewSrc] = useState('');
  const [copied, setCopied] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  const isWebPreviewable = editedBlocks.some(b =>
    ['html', 'css', 'js', 'javascript', 'jsx'].includes(normalizeLanguage(b.language))
  );

  const active = editedBlocks[activeIdx] ?? editedBlocks[0];

  function handleEdit(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setEditedBlocks(prev =>
      prev.map((b, i) => i === activeIdx ? { ...b, code: e.target.value } : b)
    );
  }

  function handlePreview() {
    const src = buildPreviewSrc(editedBlocks);
    setPreviewSrc(src);
    setPreviewOpen(v => !v);
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(active.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast.success('Copied to clipboard');
    } catch {
      toast.error('Copy failed — please select manually');
    }
  }

  return (
    <div className="mt-3 rounded-xl border border-white/10 overflow-hidden bg-[#0d1117] text-sm w-full max-w-full">
      {/* Tab bar */}
      <div className="flex items-center justify-between gap-2 px-2 py-1.5 bg-[#161b22] border-b border-white/8">
        {/* Language tabs */}
        <div className="flex items-center gap-1 min-w-0 overflow-x-auto">
          <Code2 className="h-3.5 w-3.5 text-primary/60 shrink-0 ml-1 mr-0.5" />
          {editedBlocks.map((b, i) => (
            <button
              key={i}
              onClick={() => setActiveIdx(i)}
              className={`px-3 py-1 rounded-md text-[11px] font-semibold whitespace-nowrap transition-colors ${
                i === activeIdx
                  ? 'bg-primary/15 text-primary border border-primary/25'
                  : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
              }`}
            >
              {LANG_LABELS[normalizeLanguage(b.language)] ?? b.language.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium text-muted-foreground hover:text-foreground hover:bg-white/8 border border-transparent hover:border-white/10 transition-all"
          >
            {copied ? <Check className="h-3 w-3 text-green-400" /> : <Copy className="h-3 w-3" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
          {isWebPreviewable && (
            <button
              onClick={handlePreview}
              className="flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-semibold text-primary bg-primary/10 hover:bg-primary/20 border border-primary/25 hover:border-primary/40 transition-all"
            >
              {previewOpen
                ? <><EyeOff className="h-3 w-3" />Hide Preview</>
                : <><Eye className="h-3 w-3" /><Play className="h-2.5 w-2.5" />Preview</>
              }
            </button>
          )}
        </div>
      </div>

      {/* Code editor area */}
      <div className="relative">
        {/* Highlighted display */}
        <pre
          className="absolute inset-0 pointer-events-none overflow-hidden px-4 py-3 text-[13px] font-mono leading-[1.65] whitespace-pre-wrap break-words text-[#e2e8f0] select-none"
          aria-hidden
          dangerouslySetInnerHTML={{ __html: highlight(active.code, active.language) }}
        />
        {/* Editable textarea (transparent, on top) */}
        <textarea
          value={active.code}
          onChange={handleEdit}
          spellCheck={false}
          className="relative z-10 w-full min-h-[120px] max-h-[400px] bg-transparent text-transparent caret-primary px-4 py-3 text-[13px] font-mono leading-[1.65] resize-y outline-none border-none focus:ring-0 selection:bg-primary/30"
          style={{ colorScheme: 'dark' }}
        />
      </div>

      {/* Live preview iframe */}
      {previewOpen && previewSrc && (
        <div className="border-t border-white/10">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-[#161b22] border-b border-white/8">
            <div className="flex gap-1">
              <span className="h-2.5 w-2.5 rounded-full bg-red-500/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-green-500/70" />
            </div>
            <span className="text-[10px] text-muted-foreground/60 font-mono flex-1 text-center">
              Live Preview
            </span>
          </div>
          <iframe
            ref={iframeRef}
            srcDoc={previewSrc}
            sandbox="allow-scripts allow-same-origin"
            className="w-full min-h-[300px] max-h-[500px] bg-white border-0"
            title="Code Preview"
            style={{ height: '360px' }}
          />
        </div>
      )}

      {/* Syntax colour tokens (injected inline) */}
      <style>{`
        .ch-tag     { color: #7ee787; }
        .ch-attr    { color: #79c0ff; }
        .ch-str     { color: #a5d6ff; }
        .ch-kw      { color: #ff7b72; }
        .ch-prop    { color: #79c0ff; }
        .ch-comment { color: #8b949e; font-style: italic; }
      `}</style>
    </div>
  );
}
