import {
  useState, useRef, useEffect, useCallback,
  type KeyboardEvent, type ClipboardEvent,
} from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import {
  Send, User, Loader2,
  Shield, Image, X as XIcon, Copy, Check, MessageCircle,
} from 'lucide-react';
import InlineCodeEditor, { CodeBlock } from '@/components/chat/InlineCodeEditor';
import { useUserSession } from '@/contexts/UserSessionContext';
import { supabase } from '@/db/supabase';
import SignOutDialog from '@/components/common/SignOutDialog';
import { deductCredits } from '@/lib/credits';

const CHAT_COST = 0.5; // 0.5 credits per AI message (free-tier rate)

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  toolName?: string;
  toolUrl?: string;
  imageUrl?: string;
}

function generateId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

interface ChatInterfaceProps {
  onOpenTool?: (name: string, url: string) => void;
}

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const ALLOWED_TYPES   = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

function parseCodeBlocks(content: string): CodeBlock[] {
  if (!content) return [];
  const regex = /```(\w+)?\s*\n([\s\S]*?)```/g;
  const blocks: CodeBlock[] = [];
  let m: RegExpExecArray | null;
  while ((m = regex.exec(content)) !== null) {
    const lang = (m[1] ?? 'text').toLowerCase();
    const code = m[2].trimEnd();
    if (code.trim()) blocks.push({ language: lang, code });
  }
  return blocks;
}

function stripCodeFences(content: string): string {
  return content.replace(/```(\w+)?\s*\n[\s\S]*?```/g, '').trim();
}

function relativeTime(date: Date): string {
  const secs = Math.floor((Date.now() - date.getTime()) / 1000);
  if (secs < 5)   return 'just now';
  if (secs < 60)  return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60)  return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24)   return `${hrs}h ago`;
  return date.toLocaleDateString();
}

const SUGGESTION_CHIPS = [
  'How can AlphaTekx help me automate my business workflow?',
];

const WELCOME_MESSAGE: ChatMessage = {
  id: 'welcome',
  role: 'assistant',
  content: 'System Ready. AlphaTekx AI Operating System is online. How may I assist you today?',
  timestamp: new Date(),
};

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Copy failed — select manually.');
    }
  }
  return (
    <button
      onClick={handleCopy}
      className="opacity-0 group-hover:opacity-100 ml-1 shrink-0 p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-white/8 transition-all duration-150"
      title="Copy message"
    >
      {copied ? <Check className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5" />}
    </button>
  );
}

function Timestamp({ date }: { date: Date }) {
  const [label, setLabel] = useState(() => relativeTime(date));
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!visible) return;
    const id = setInterval(() => setLabel(relativeTime(date)), 30_000);
    return () => clearInterval(id);
  }, [visible, date]);
  return (
    <span
      className="relative cursor-default select-none"
      onMouseEnter={() => { setLabel(relativeTime(date)); setVisible(true); }}
      onMouseLeave={() => setVisible(false)}
    >
      {visible && (
        <span className="absolute -top-7 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-md bg-background/90 border border-white/10 text-[10px] text-muted-foreground whitespace-nowrap shadow-lg z-10">
          {label}
        </span>
      )}
    </span>
  );
}

function ThinkingDots({ label }: { label: string }) {
  return (
    <div className="flex gap-4 msg-enter-left">
      <div className="shrink-0 mt-1 flex h-9 w-9 items-center justify-center rounded-xl bg-background border border-border/60 shadow-sm">
        <Shield className="h-5 w-5 text-primary" />
      </div>
      <div className="flex items-center gap-2.5 text-sm text-primary font-medium">
        <span className="text-muted-foreground/80">{label}</span>
        <span className="flex gap-1.5">
          {[0, 1, 2].map(i => (
            <span
              key={i}
              className="h-1.5 w-1.5 rounded-full bg-primary/70"
              style={{ animation: `pulse 1.2s ease-in-out ${i * 0.25}s infinite` }}
            />
          ))}
        </span>
      </div>
    </div>
  );
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export default function ChatInterface({ onOpenTool }: ChatInterfaceProps) {
  const [messages, setMessages]     = useState<ChatMessage[]>([WELCOME_MESSAGE]);
  const [input, setInput]           = useState('');
  const [sending, setSending]       = useState(false);
  const [thinking, setThinking]     = useState<string | null>(null);
  const [signOutOpen, setSignOutOpen] = useState(false);

  const [pendingImage, setPendingImage]           = useState<File | null>(null);
  const [pendingImagePreview, setPendingPreview]  = useState<string | null>(null);
  const [uploadingImage, setUploadingImage]       = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const scrollRef   = useRef<HTMLDivElement>(null);
  const abortRef    = useRef<AbortController | null>(null);
  const { appUser, refreshBalance } = useUserSession();

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const isNearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 200;
    if (isNearBottom) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [messages, thinking]);

  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    const lineH = 24;
    const maxH  = lineH * 4 + 24;
    ta.style.height = `${Math.min(ta.scrollHeight, maxH)}px`;
    ta.style.overflowY = ta.scrollHeight > maxH ? 'auto' : 'hidden';
  }, [input]);

  useEffect(() => {
    function onPaste(e: globalThis.ClipboardEvent) {
      const items = Array.from(e.clipboardData?.items ?? []);
      const imageItem = items.find(it => it.type.startsWith('image/'));
      if (!imageItem) return;
      
      const file = imageItem.getAsFile();
      if (file) {
        // Prevent default paste of image if we're handling it
        e.preventDefault();
        attachImage(file);
      }
    }
    window.addEventListener('paste', onPaste as EventListener);
    return () => window.removeEventListener('paste', onPaste as EventListener);
  }, []);

  function attachImage(file: File) {
    if (!ALLOWED_TYPES.includes(file.type)) {
      toast.error('Unsupported format. Use JPG, PNG, GIF, or WebP.');
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      toast.error('Image too large. Max 5 MB.');
      return;
    }
    setPendingImage(file);
    const reader = new FileReader();
    reader.onload = () => setPendingPreview(reader.result as string);
    reader.readAsDataURL(file);
  }

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) attachImage(file);
    e.target.value = '';
  }

  function clearPendingImage() {
    setPendingImage(null);
    setPendingPreview(null);
  }

  async function uploadImage(file: File): Promise<string> {
    const ext  = file.name.split('.').pop() ?? 'jpg';
    const path = `chat/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error } = await supabase.storage.from('chat-images').upload(path, file, { contentType: file.type });
    if (error) throw new Error(`Upload failed: ${error.message}`);
    return supabase.storage.from('chat-images').getPublicUrl(path).data.publicUrl;
  }

  function newConversation() {
    abortRef.current?.abort();
    setMessages([WELCOME_MESSAGE]);
    setInput('');
    clearPendingImage();
    setSending(false);
    setThinking(null);
  }

  const sendMessage = useCallback(async (prompt: string, imageOverride?: string) => {
    if (!prompt.trim() && !pendingImage && !imageOverride) return;
    abortRef.current?.abort();
    abortRef.current = new AbortController();
    let imageUrl: string | undefined = imageOverride;
    if (pendingImage && !imageUrl) {
      setUploadingImage(true);
      try {
        imageUrl = await uploadImage(pendingImage);
      } catch (e) {
        toast.error((e as Error).message || 'Image upload failed.');
        setUploadingImage(false);
        return;
      } finally {
        setUploadingImage(false);
        clearPendingImage();
      }
    }
    const userMsg: ChatMessage = {
      id: generateId(),
      role: 'user',
      content: prompt.trim(),
      timestamp: new Date(),
      imageUrl,
    };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setSending(true);
    setThinking('Analysing…');
    const aiId = generateId();
    const aiMsg: ChatMessage = { id: aiId, role: 'assistant', content: '', timestamp: new Date() };
    try {
      // ── Deduct 1 credit per message ──────────────────────────────────────
      const creditResult = await deductCredits(CHAT_COST);
      if (!creditResult.success) {
        toast.error(creditResult.error ?? 'Not enough credits. Top up to continue chatting.', { duration: 4000 });
        setSending(false);
        setThinking(null);
        setMessages(prev => prev.filter(m => m.id !== userMsg.id));
        await refreshBalance();
        return;
      }
      await refreshBalance();
      // ─────────────────────────────────────────────────────────────────────
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          prompt: prompt.trim() || (imageUrl ? 'Analyse this image in detail.' : ''),
          history: messages.filter(m => m.id !== 'welcome').slice(-12).map(m => ({ role: m.role, content: m.content })),
          ...(imageUrl ? { imageUrl } : {}),
        }),
        signal: abortRef.current.signal,
      });
      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || `Status ${response.status}`);
      }
      if (!response.body) throw new Error('No response body');
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let done = false;
      let full = '';
      let aiAdded = false;
      while (!done) {
        const { value, done: d } = await reader.read();
        done = d;
        if (!value) continue;
        for (const line of decoder.decode(value).split('\n')) {
          if (!line.startsWith('data: ')) continue;
          const js = line.slice(6).trim();
          if (!js || js === '[DONE]') continue;
          try {
            const j = JSON.parse(js);
            if (j.status) { setThinking(j.status); continue; }
            const delta = j.choices?.[0]?.delta?.content ?? '';
            if (delta) {
              if (!aiAdded) { setMessages(prev => [...prev, aiMsg]); aiAdded = true; setThinking(null); }
              full += delta;
              setMessages(prev => prev.map(m => m.id === aiId ? { ...m, content: full } : m));
            }
          } catch { /* partial */ }
        }
      }
    } catch (e) {
      if ((e as Error).name === 'AbortError') return;
      toast.error((e as Error).message || 'AI error — try again.');
      setMessages(prev => prev.filter(m => m.id !== aiId));
    } finally {
      setSending(false);
      setThinking(null);
      abortRef.current = null;
    }
  }, [messages, pendingImage]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    sendMessage(input);
  }

  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  }

  function handlePaste(e: ClipboardEvent<HTMLTextAreaElement>) {
    const items = Array.from(e.clipboardData.items);
    const img = items.find(it => it.type.startsWith('image/'));
    if (img) {
      e.preventDefault();
      const file = img.getAsFile();
      if (file) attachImage(file);
    }
  }

  const canSend = !sending && !uploadingImage && (input.trim().length > 0 || !!pendingImage);
  const isWelcome = messages.length === 1 && messages[0].id === 'welcome';

  return (
    <div className="flex flex-col h-full w-full bg-background chat-container">
      <SignOutDialog open={signOutOpen} onOpenChange={setSignOutOpen} />

      {/* ── Messages ── */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto min-h-0 pt-8 pb-4">
        <div className="max-w-3xl mx-auto w-full px-4 md:px-6 space-y-8 pb-6">

          {/* Welcome hero */}
          {isWelcome && (
            <div className="flex flex-col items-center pt-10 pb-4 gap-6">
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-[2rem] bg-background border border-border/60 shadow-[0_12px_40px_-12px_rgba(var(--primary),0.35)]">
                <Shield className="h-10 w-10 text-primary" />
              </div>
              <div className="text-center space-y-2">
                <h1 className="text-3xl md:text-4xl font-black tracking-tighter leading-tight uppercase">
                  <span className="gradient-text">AlphaTekx</span>
                </h1>
                <p className="text-xs font-bold text-muted-foreground/50 uppercase tracking-[0.25em]">
                  AI Operating System — Online
                </p>
              </div>
            </div>
          )}

          {/* Messages */}
          {messages.map((msg) => {
            const codeBlocks = msg.role === 'assistant' ? parseCodeBlocks(msg.content) : [];
            const hasCode    = codeBlocks.length > 0;
            const displayText = hasCode ? stripCodeFences(msg.content) : msg.content;
            const animClass   = msg.role === 'user' ? 'msg-enter-right' : 'msg-enter-left';

            return (
              <div
                key={msg.id}
                className={`flex w-full gap-3 md:gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'} ${animClass}`}
              >
                {/* Avatar */}
                <div className="shrink-0 mt-1">
                  {msg.role === 'user' ? (
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary shadow-lg shadow-primary/25">
                      <User className="h-5 w-5 text-primary-foreground" />
                    </div>
                  ) : (
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-background border border-border/60 shadow-sm">
                      <Shield className="h-5 w-5 text-primary" />
                    </div>
                  )}
                </div>

                {/* Bubble */}
                <div className={`group relative max-w-[88%] md:max-w-[80%] rounded-2xl px-5 py-4 text-base leading-[1.75] min-w-0 shadow-sm ${
                  msg.role === 'user'
                    ? 'bg-primary/10 text-foreground border border-primary/20'
                    : 'bg-card border border-border/50'
                }`}>
                  {msg.imageUrl && (
                    <div className="mb-3">
                      <img
                        src={msg.imageUrl}
                        alt="Attached"
                        className="max-w-full max-h-72 rounded-xl object-contain border border-white/10"
                      />
                    </div>
                  )}
                  {displayText && (
                    <div className="flex items-start gap-2">
                      <p className="flex-1 text-pretty whitespace-pre-wrap break-words text-base">
                        {displayText}
                      </p>
                      {msg.role === 'assistant' && msg.content && (
                        <CopyButton text={msg.content} />
                      )}
                    </div>
                  )}
                  <div className={`absolute -bottom-4 ${msg.role === 'user' ? 'right-2' : 'left-2'}`}>
                    <Timestamp date={msg.timestamp} />
                  </div>
                  {hasCode && <InlineCodeEditor blocks={codeBlocks} />}
                </div>
              </div>
            );
          })}

          {/* Thinking / typing indicator */}
          {(thinking || (sending && !thinking)) && (
            <ThinkingDots label={thinking ?? 'AlphaTekx is typing'} />
          )}
        </div>
      </div>

      {/* ── Input Bar ── */}
      <div className="shrink-0 bg-background border-t border-border/40 pt-4 pb-5">
        <div className="max-w-3xl mx-auto w-full px-4 md:px-6">

          {/* Suggestion chip (welcome state) */}
          {isWelcome && (
            <div className="flex flex-col items-center mb-5 animate-in fade-in slide-in-from-bottom-2 duration-700 delay-300">
              <span className="text-[10px] text-muted-foreground/40 uppercase tracking-[0.2em] mb-3 font-bold">
                Try asking
              </span>
              {SUGGESTION_CHIPS.map((chip) => (
                <button
                  key={chip}
                  type="button"
                  onClick={() => { setInput(chip); textareaRef.current?.focus(); }}
                  className="group flex items-center gap-3 text-sm text-muted-foreground hover:text-primary border border-border/40 hover:border-primary/40 bg-card hover:bg-primary/5 rounded-2xl px-5 py-4 transition-all duration-200 shadow-sm hover:shadow-md w-full max-w-lg text-left"
                >
                  <MessageCircle className="h-4 w-4 text-primary/40 group-hover:text-primary transition-colors shrink-0" />
                  <span className="font-medium text-pretty">{chip}</span>
                </button>
              ))}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            {/* Image attachment preview */}
            {pendingImagePreview && (
              <div className="mb-3 animate-in fade-in slide-in-from-bottom-2">
                <div className="bg-secondary border border-border/60 p-3 rounded-2xl flex items-center gap-3 shadow-lg max-w-xs">
                  <div className="relative h-14 w-14 shrink-0">
                    <img
                      src={pendingImagePreview}
                      alt="Preview"
                      className="h-14 w-14 rounded-xl object-cover border border-white/10"
                    />
                    <Button
                      type="button"
                      size="icon"
                      variant="destructive"
                      onClick={clearPendingImage}
                      className="absolute -top-2 -right-2 h-5 w-5 rounded-full shadow-lg"
                    >
                      <XIcon className="h-3 w-3" />
                    </Button>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-foreground truncate">{pendingImage?.name}</p>
                    <p className="text-[10px] text-muted-foreground uppercase font-black tracking-widest mt-0.5">
                      Ready for Analysis
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Input field */}
            <div className="flex items-end gap-2 bg-secondary/60 border border-border/60 rounded-[1.5rem] p-2 pr-2.5 focus-within:border-primary/50 focus-within:bg-secondary/80 transition-all duration-200 shadow-md">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                accept={ALLOWED_TYPES.join(',')}
                className="hidden"
              />
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={() => fileInputRef.current?.click()}
                disabled={sending || uploadingImage}
                aria-label="Attach image"
                className="h-12 w-12 shrink-0 rounded-full hover:bg-primary/10 hover:text-primary text-muted-foreground/60"
              >
                <Image className="h-5 w-5" />
              </Button>

              <textarea
                ref={textareaRef}
                rows={1}
                placeholder="Ask AlphaTekx anything…"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                onPaste={handlePaste}
                disabled={sending || uploadingImage}
                className="flex-1 bg-transparent outline-none border-none focus:outline-none focus:ring-0 text-[15px] md:text-base text-foreground font-medium py-3 px-2 resize-none overflow-y-auto max-h-36 custom-scrollbar placeholder:text-muted-foreground/40 min-h-[48px] leading-relaxed"
              />

              <Button
                type="submit"
                size="icon"
                disabled={!canSend}
                aria-label="Send message"
                className="h-12 w-12 shrink-0 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20 transition-all active:scale-95 disabled:opacity-35"
              >
                {sending || uploadingImage
                  ? <Loader2 className="h-5 w-5 animate-spin" />
                  : <Send className="h-5 w-5" />}
              </Button>
            </div>
          </form>

          <p className="text-center text-[10px] text-muted-foreground/20 mt-3 tracking-widest uppercase font-bold">
            AlphaTekx AI OS · Precision Infrastructure
          </p>
        </div>
      </div>

      <style>{`
        @media (max-width: 640px) {
          .chat-container { height: 100%; height: -webkit-fill-available; }
        }
      `}</style>
    </div>
  );
}
