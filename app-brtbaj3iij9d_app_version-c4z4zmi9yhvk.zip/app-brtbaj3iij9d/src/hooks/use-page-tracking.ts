/**
 * usePageTracking
 *
 * Logs every route change to `page_views` (with device_type + referrer_source)
 * and upserts a heartbeat row in `active_sessions` every 60 seconds.
 *
 * This powers ALL real metrics in the admin SEO/Analytics dashboard:
 *  - active users, sessions today, page views, bounce rate
 *  - device breakdown (desktop / mobile / tablet)
 *  - traffic sources (Google Organic, Direct, YouTube, etc.)
 *  - top pages now + top pages 30-day
 *
 * Session ID is stable per browser tab (sessionStorage). No PII sent.
 */

import { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { supabase } from '@/db/supabase';

// ── Session ID ─────────────────────────────────────────────────────────────────
function getSessionId(): string {
  const KEY = 'atx_sid';
  let sid = sessionStorage.getItem(KEY);
  if (!sid) { sid = crypto.randomUUID(); sessionStorage.setItem(KEY, sid); }
  return sid;
}

// ── Device detection ──────────────────────────────────────────────────────────
function getDeviceType(): 'mobile' | 'tablet' | 'desktop' {
  const ua = navigator.userAgent;
  if (/iPad|Tablet|(android(?!.*mobile))/i.test(ua)) return 'tablet';
  if (/Mobi|Android|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua)) return 'mobile';
  return 'desktop';
}

// ── Referrer → named traffic source ──────────────────────────────────────────
function getReferrerSource(): string {
  const ref = document.referrer;
  if (!ref) return 'Direct';
  try {
    const host = new URL(ref).hostname.replace(/^www\./, '');
    if (/google\./i.test(host))    return 'Google Organic';
    if (/bing\./i.test(host))      return 'Bing';
    if (/yahoo\./i.test(host))     return 'Yahoo';
    if (/youtube\.com/i.test(host))return 'YouTube';
    if (/t\.co|twitter\.com|x\.com/i.test(host)) return 'Twitter / X';
    if (/facebook\.com|fb\.com/i.test(host))      return 'Facebook';
    if (/instagram\.com/i.test(host)) return 'Instagram';
    if (/linkedin\.com/i.test(host))  return 'LinkedIn';
    if (/tiktok\.com/i.test(host))    return 'TikTok';
    if (/reddit\.com/i.test(host))    return 'Reddit';
    // Same-site navigation or known internal origin → not an external referrer
    const appOrigin = window.location.hostname.replace(/^www\./, '');
    if (host === appOrigin) return 'Direct';
    return host; // any other external domain — show its hostname
  } catch {
    return 'Direct';
  }
}

const HEARTBEAT_MS = 60_000;

export function usePageTracking(firebaseUid?: string | null) {
  const location     = useLocation();
  const sessionId    = getSessionId();
  const lastPath     = useRef<string>('');
  const heartbeatRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const currentPath  = useRef<string>(location.pathname);

  // ── Log page view + upsert active session on every route change ──────────
  useEffect(() => {
    const path = location.pathname;
    currentPath.current = path;
    if (path === lastPath.current) return; // skip duplicate re-renders
    lastPath.current = path;

    const uid            = firebaseUid ?? null;
    const device_type    = getDeviceType();
    const referrer_source = getReferrerSource();

    // Fire-and-forget — never block the UI
    supabase.from('page_views').insert({
      session_id:      sessionId,
      firebase_uid:    uid,
      page_path:       path,
      referrer:        document.referrer || null,
      device_type,
      referrer_source,
    }).then(() => {/* silent */});

    supabase.from('active_sessions').upsert({
      session_id:   sessionId,
      firebase_uid: uid,
      page_path:    path,
      last_seen:    new Date().toISOString(),
    }, { onConflict: 'session_id' }).then(() => {/* silent */});
  }, [location.pathname, sessionId, firebaseUid]);

  // ── Heartbeat: keep active_sessions alive every 60s ──────────────────────
  useEffect(() => {
    heartbeatRef.current = setInterval(() => {
      supabase.from('active_sessions').upsert({
        session_id:   sessionId,
        firebase_uid: firebaseUid ?? null,
        page_path:    currentPath.current,
        last_seen:    new Date().toISOString(),
      }, { onConflict: 'session_id' }).then(() => {/* silent */});
    }, HEARTBEAT_MS);

    return () => {
      if (heartbeatRef.current) clearInterval(heartbeatRef.current);
    };
  }, [sessionId, firebaseUid]);
}
