import { useEffect, useState } from 'react';
import { supabase } from '@/db/supabase';

/**
 * Tracks live online count inside the Members Lounge using
 * Supabase Realtime Presence on a dedicated 'lounge-presence' channel.
 */
export function useLoungePresence(displayName: string, enabled: boolean) {
  const [onlineCount, setOnlineCount] = useState<number>(1);

  useEffect(() => {
    if (!enabled) return;

    const channel = supabase.channel('lounge-presence', {
      config: { presence: { key: crypto.randomUUID() } },
    });

    channel
      .on('presence', { event: 'sync' }, () => {
        const state = channel.presenceState();
        setOnlineCount(Object.keys(state).length);
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await channel.track({
            display_name: displayName,
            online_at:    new Date().toISOString(),
          });
        }
      });

    return () => { channel.unsubscribe(); };
  }, [enabled, displayName]);

  return onlineCount;
}
