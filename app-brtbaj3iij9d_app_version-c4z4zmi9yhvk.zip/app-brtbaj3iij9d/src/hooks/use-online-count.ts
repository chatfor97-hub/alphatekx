import { useEffect, useState } from 'react';
import { supabase } from '@/db/supabase';

/**
 * Format a raw count into a compact display string.
 * 0–999 → "1", "42", "999"
 * 1 000–999 999 → "1k", "12.3k"
 * 1 000 000+ → "1m", "2.4m"
 */
export function formatLiveCount(n: number): string {
  if (n >= 1_000_000) return `${+(n / 1_000_000).toFixed(1)}m`;
  if (n >= 1_000)     return `${+(n / 1_000).toFixed(1)}k`;
  return String(n);
}

/**
 * Tracks live online user count using Supabase Realtime Presence.
 * Every browser tab joins the shared 'global-online' channel.
 * The count is ALWAYS set from presence state on every sync event —
 * including when it drops to zero — so it stays perfectly accurate.
 * Falls back to active_sessions REST count if Presence hasn't fired yet.
 */
export function useOnlineCount() {
  // Start at 0 — will be updated immediately on first presence sync
  const [count, setCount] = useState<number>(0);

  useEffect(() => {
    let fallbackTimer: ReturnType<typeof setInterval> | null = null;
    let presenceReady = false;

    // ── Realtime Presence ───────────────────────────────────────────────────
    const channel = supabase.channel('global-online', {
      config: { presence: { key: crypto.randomUUID() } },
    });

    channel
      .on('presence', { event: 'sync' }, () => {
        // Always reflect the true presence count — including drops to 0
        const n = Object.keys(channel.presenceState()).length;
        presenceReady = true;
        setCount(n);
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await channel.track({ online_at: new Date().toISOString() });
        }
      });

    // ── Active-sessions fallback (REST, every 30 s) ─────────────────────────
    // Only used until the first presence sync fires
    const fetchFallback = async () => {
      if (presenceReady) return;
      const since = new Date(Date.now() - 5 * 60 * 1000).toISOString();
      const { count: n } = await supabase
        .from('active_sessions')
        .select('*', { count: 'exact', head: true })
        .gte('last_seen', since);
      if (!presenceReady) setCount(n ?? 0);
    };

    fetchFallback();
    fallbackTimer = setInterval(fetchFallback, 30_000);

    return () => {
      channel.unsubscribe();
      if (fallbackTimer) clearInterval(fallbackTimer);
    };
  }, []);

  return count;
}
