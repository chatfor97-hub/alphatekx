declare module '@paystack/inline-js' {
  interface NewTransactionOptions {
    key: string;
    email: string;
    amount: number;        // in smallest currency unit (cents for USD, kobo for NGN)
    currency?: string;
    ref?: string;
    channels?: string[];
    metadata?: Record<string, unknown>;
    onSuccess?: (transaction: { reference: string; message: string; status: string }) => void;
    onCancel?: () => void;
    onError?: (error: Error) => void;
  }

  class PaystackPop {
    newTransaction(options: NewTransactionOptions): void;
    resumeTransaction(accessCode: string): void;
    cancelTransaction(): void;
  }

  export default PaystackPop;
}
