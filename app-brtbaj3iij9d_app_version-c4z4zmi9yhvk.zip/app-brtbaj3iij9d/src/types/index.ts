export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export type UserRole = 'user' | 'admin';

export interface Profile {
  id: string;
  email: string | null;
  phone: string | null;
  full_name: string | null;
  role: UserRole;
  credit_balance: number;
  created_at: string;
}

export interface CreditRecord {
  id: string;
  user_id: string;
  amount: number;
  transaction_type: string;
  created_at: string;
}
