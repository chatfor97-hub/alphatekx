import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

export type ColorTheme = 'cyber' | 'purple' | 'emerald' | 'light';

export interface ThemeOption {
  id: ColorTheme;
  label: string;
  /** Dot colour shown in the picker (Tailwind arbitrary bg) */
  dot: string;
  isDark: boolean;
}

export const THEME_OPTIONS: ThemeOption[] = [
  { id: 'cyber',   label: 'Cyber Dark',     dot: '#00E5FF', isDark: true  },
  { id: 'purple',  label: 'Deep Purple',    dot: '#A855F7', isDark: true  },
  { id: 'emerald', label: 'Midnight Green', dot: '#10B981', isDark: true  },
  { id: 'light',   label: 'Light Pro',      dot: '#0EA5E9', isDark: false },
];

const STORAGE_KEY = 'alphatekx_theme';

interface ThemeContextType {
  theme: ColorTheme;
  setTheme: (t: ColorTheme) => void;
  /** @deprecated use setTheme — kept for backward compat */
  toggleTheme: () => void;
  isDark: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

function applyTheme(theme: ColorTheme) {
  const root = document.documentElement;
  // Remove all theme data attrs + light class first
  root.removeAttribute('data-theme');
  root.classList.remove('light');
  // Apply new theme
  root.setAttribute('data-theme', theme);
  if (theme === 'light') {
    root.classList.add('light');
  }
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ColorTheme>(() => {
    const stored = localStorage.getItem(STORAGE_KEY) as ColorTheme | null;
    const valid: ColorTheme[] = ['cyber', 'purple', 'emerald', 'light'];
    return stored && valid.includes(stored) ? stored : 'cyber';
  });

  useEffect(() => {
    applyTheme(theme);
    localStorage.setItem(STORAGE_KEY, theme);
  }, [theme]);

  function setTheme(t: ColorTheme) {
    setThemeState(t);
  }

  /** Cycles through all 4 themes for backward compat */
  function toggleTheme() {
    const idx = THEME_OPTIONS.findIndex(o => o.id === theme);
    setThemeState(THEME_OPTIONS[(idx + 1) % THEME_OPTIONS.length].id);
  }

  const isDark = THEME_OPTIONS.find(o => o.id === theme)?.isDark ?? true;

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, isDark }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used inside ThemeProvider');
  return ctx;
}
