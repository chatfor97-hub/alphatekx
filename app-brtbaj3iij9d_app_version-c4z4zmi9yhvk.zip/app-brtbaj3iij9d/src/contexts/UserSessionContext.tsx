import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { onAuthStateChanged, signOut as firebaseSignOut } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { getUserDoc, upsertUser, type AppUser } from '@/lib/firestore';

// Re-export AppUser so existing imports remain valid
export type { AppUser };

export interface UserSessionContextType {
  appUser: AppUser | null;
  sessionReady: boolean;
  logout: () => Promise<void>;
  refreshBalance: () => Promise<void>;
}

export const UserSessionContext = createContext<UserSessionContextType | undefined>(undefined);

export function UserSessionProvider({ children }: { children: ReactNode }) {
  const [appUser, setAppUser] = useState<AppUser | null>(null);
  const [sessionReady, setSessionReady] = useState(false);

  useEffect(() => {
    // Subscribe to Firebase auth state changes — single source of truth
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // Ensure user doc exists in Firestore (handles new + returning users)
        const { appUser: user } = await upsertUser(firebaseUser);
        setAppUser(user);
      } else {
        setAppUser(null);
      }
      setSessionReady(true);
    });

    return unsubscribe;
  }, []);

  async function logout() {
    await firebaseSignOut(auth);
    setAppUser(null);
  }

  async function refreshBalance() {
    const firebaseUser = auth.currentUser;
    if (!firebaseUser) return;
    const fresh = await getUserDoc(firebaseUser.uid);
    if (fresh) setAppUser(fresh);
  }

  return (
    <UserSessionContext.Provider value={{ appUser, sessionReady, logout, refreshBalance }}>
      {children}
    </UserSessionContext.Provider>
  );
}

export function useUserSession(): UserSessionContextType {
  const ctx = useContext(UserSessionContext);
  // During React Fast Refresh (HMR), the context object identity can change briefly,
  // causing consumers to see `undefined` even though the provider exists in the tree.
  // Return a safe no-op fallback so the app recovers gracefully instead of white-screening.
  if (!ctx) {
    return {
      appUser: null,
      sessionReady: false,
      logout: async () => {},
      refreshBalance: async () => {},
    };
  }
  return ctx;
}
